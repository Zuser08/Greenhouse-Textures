// Pre-ship check for bundle.js. Run it before every build:
//
//   node check.mjs
//
// node --check only parses. It says nothing about a name that is referenced
// but never declared, which is exactly how a build went out with a deleted
// `const peaTypeInUse` still being read twelve times a second, throwing on
// every shot. That took a whole test round to find and the error was sitting
// in the log the whole time.
//
// This runs ESLint's no-undef over the bundle instead, which catches it
// statically in about a second. Needs eslint available: `npm i -D eslint`, or
// `npx eslint` will fetch it.
import { ESLint } from "eslint";

// The engine's own globals. Anything else that is undeclared is a bug.
const GAME_GLOBALS = [
  `globalThis`, `console`, `Math`, `Date`, `Object`, `Array`, `Map`, `Set`,
  `WeakSet`, `WeakMap`, `JSON`, `Number`, `String`, `Boolean`, `Promise`,
  `Error`, `RegExp`, `Symbol`, `Infinity`, `NaN`, `isNaN`,
  `setTimeout`, `clearTimeout`, `setInterval`, `clearInterval`,
  // The game is Cocos inside Electron, so the browser is there too. The
  // texture system uses it: a file picker to bring a PNG in, localStorage to
  // keep it, a canvas to write the original back out.
  `document`, `window`, `navigator`, `localStorage`, `Image`, `URL`,
  `FileReader`, `Blob`, `HTMLImageElement`, `HTMLCanvasElement`,
  `TextEncoder`, `TextDecoder`, `atob`, `btoa`,
];

const globals = Object.fromEntries(GAME_GLOBALS.map((name) => [name, `readonly`]));

const eslint = new ESLint({
  overrideConfigFile: true,
  overrideConfig: {
    files: [`**/*.js`],
    languageOptions: { ecmaVersion: 2022, sourceType: `module`, globals },
    // An unused `err` in a catch is deliberate all over this file, so only
    // undefined names are worth failing over.
    rules: { "no-undef": `error`, "no-unused-vars": [`warn`, { args: `none`, caughtErrors: `none` }] },
  },
});

const results = await eslint.lintFiles([`bundle.js`]);
const errors = results.reduce((n, r) => n + r.errorCount, 0);
const warnings = results.reduce((n, r) => n + r.warningCount, 0);

for (const result of results) {
  for (const m of result.messages) {
    console.log(`${m.severity === 2 ? `ERROR` : `warn `} ${result.filePath}:${m.line}:${m.column}  ${m.message}  (${m.ruleId})`);
  }
}

console.log(`${errors} error(s), ${warnings} warning(s)`);
process.exit(errors ? 1 : 0);
