// Runs the mod against a fake browser, a fake plant pool and a fake asset
// cache. What it proves: plants are found through their armature rather than
// by name, dressing one plant leaves the shared sheet (and therefore the
// vanilla plant) untouched, the whole-sheet route does change it, overrides
// persist, and a plant that spawns later gets dressed on the next pass.
import { readFileSync, writeFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const file = join(mkdtempSync(join(tmpdir(), "gt-")), "bundle.mjs");
writeFileSync(file, readFileSync(join(here, "bundle.js"), "utf8"));

// ---- fake browser ----
const listeners = [];
const made = [];
globalThis.document = {
  createElement(tag) {
    const node = {
      tag, style: {}, children: [], files: [], innerHTML: "",
      appendChild(c) { this.children.push(c); return c; },
      remove() {}, click() { this.clicked = true; }, querySelector: () => null,
      // Two opaque squares, so a sheet scan finds two pieces.
      getContext: () => ({
        drawImage() {},
        getImageData: (x, y, w, h) => {
          const data = new Uint8ClampedArray(w * h * 4);
          for (const [bx, by, side] of [[8, 8, 40], [64, 64, 24]]) {
            for (let yy = by; yy < by + side; yy++) for (let xx = bx; xx < bx + side; xx++) data[(yy * w + xx) * 4 + 3] = 255;
          }
          return { data };
        },
      }),
      toDataURL: () => "data:image/png;base64,THUMB",
      setSelectionRange() {}, focus() {},
    };
    made.push(node);
    return node;
  },
  body: { appendChild() {} },
  addEventListener: (n, fn) => listeners.push([n, fn]),
};
globalThis.Image = class {
  set src(v) { this._src = v; this.width = 128; this.height = 128; setTimeout(() => this.onload?.(), 0); }
};
const store = new Map();
globalThis.localStorage = {
  get length() { return store.size; },
  key: (i) => [...store.keys()][i],
  getItem: (k) => store.get(k) ?? null,
  setItem: (k, v) => store.set(k, v),
  removeItem: (k) => store.delete(k),
};
globalThis.URL = { createObjectURL: () => "blob:x", revokeObjectURL() {} };

// ---- fake Tauri file plugin, rooted at the app data folder ----
const files = new Map();
const dirs = new Set();
const addDir = (path) => {
  for (let p = path; p; p = p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "") dirs.add(p);
};
const putFile = (path, bytes) => {
  files.set(path, bytes);
  addDir(path.slice(0, path.lastIndexOf("/")));
};
const text = (value) => new TextEncoder().encode(typeof value === "string" ? value : JSON.stringify(value));
const fsCalls = [];
globalThis.__TAURI_INTERNALS__ = {
  invoke: async (cmd, args, opts) => {
    const name = cmd.split("|")[1];
    fsCalls.push(name);
    if (opts?.headers?.options && JSON.parse(opts.headers.options).baseDir !== 14) throw new Error("wrong base dir");
    if (args?.options?.baseDir !== undefined && args.options.baseDir !== 14) throw new Error("wrong base dir");
    if (name === "read_dir") {
      if (!dirs.has(args.path)) throw new Error(`no such dir ${args.path}`);
      const kids = new Map();
      for (const p of [...files.keys(), ...dirs]) {
        if (!p.startsWith(`${args.path}/`)) continue;
        const first = p.slice(args.path.length + 1).split("/")[0];
        kids.set(first, dirs.has(`${args.path}/${first}`));
      }
      return [...kids].map(([n, d]) => ({ name: n, isDirectory: d, isFile: !d }));
    }
    if (name === "read_file") {
      const b = files.get(args.path);
      if (!b) throw new Error(`no file ${args.path}`);
      return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
    }
    if (name === "write_file") {
      const path = decodeURIComponent(opts.headers.path);
      if (!dirs.has(path.slice(0, path.lastIndexOf("/")))) throw new Error("no such dir");
      files.set(path, new Uint8Array(args));
      return null;
    }
    if (name === "mkdir") {
      addDir(args.path);
      return null;
    }
    if (name === "rename") {
      const b = files.get(args.oldPath);
      if (!b || !dirs.has(args.newPath.slice(0, args.newPath.lastIndexOf("/")))) throw new Error("rename failed");
      files.delete(args.oldPath);
      files.set(args.newPath, b);
      return null;
    }
    throw new Error(`not allowed: ${cmd}`);
  },
};
// Another pack ships art for a plant: a still image and its size.
putFile("gp-next/packs/PlantPack/pack.json", text({ uuid: "plantpack-1", name: "Plant Pack" }));
// This pack's own folder picked as home, so the early checks write there.
store.set("greenhousetextures.option:homepack", "0ebee2cb-a35f-406f-ae13-6297940d59a0");
putFile("gp-next/packs/PlantPack/textures/Peashooter.still.png", new Uint8Array([137, 80, 78, 71]));
putFile("gp-next/packs/PlantPack/textures/looks.json", text({ peashooter: { stillScale: 2, stillOffset: [4, -6] } }));
putFile("gp-next/packs/PlantPack/textures/notes.txt", text("not art"));
globalThis.FileReader = class { readAsDataURL() {} };

// ---- fake engine ----
class Texture2D {
  constructor(w = 512, h = 512) {
    this.width = w;
    this.height = h;
    // A real ImageAsset carries its own size, which is what the texture
    // resizes itself from when one is assigned.
    this.image = { width: w, height: h, data: { width: w, height: h } };
  }
  // Cocos rebuilds the texture around whatever image it is handed, so the
  // fake has to resize too or the checks below measure nothing.
  set image(v) {
    this._image = v;
    if (typeof v?.width === "number") {
      this.width = v.width;
      this.height = v.height;
    }
  }
  get image() { return this._image; }
}
// Gatling Pea and Heliconia Gunner share one sheet, which is the whole point.
const gatlingSheet = new Texture2D();
const sunflowerSheet = new Texture2D(256, 256);
const assets = new Map([
  ["uuid-gatling", gatlingSheet],
  ["uuid-sunflower", sunflowerSheet],
]);

// Pack plants sit above the vanilla id range, which is how the mod tells
// modded art apart from the vanilla art it borrows.
const FEATURES = {
  900002: { CODENAME: "heliconiagunner", NAME: { en: "Heliconia Gunner" }, _CARDSPRITENAME: "gatlingpea" },
  8: { CODENAME: "gatlingpea", NAME: { en: "Gatling Pea" } },
  9: { CODENAME: "sunflower", NAME: { en: "Sunflower" } },
  10: { CODENAME: "peashooter", NAME: { en: "Peashooter" } },
  11: { CODENAME: "laserbean", NAME: { en: "Laser Bean" } },
  12: { CODENAME: "chomper", NAME: { en: "Chomper" } },
};
// The controller the game drives animations through, so clip remapping can
// Just enough of the scene graph for the still-image route.
class Node {
  constructor(name) { this.name = name; this.children = []; this.isValid = true; this.active = true; }
  addComponent(Type) {
    const c = new Type();
    c.node = this;
    (this.comps ??= []).push(c);
    if (!this.comp) this.comp = c;
    return c;
  }
  getComponent(Type) { return (this.comps ?? []).find((c) => c instanceof Type) ?? null; }
  set parent(p) { this._parent = p; p?.children?.push(this); }
  get parent() { return this._parent; }
  getSiblingIndex() { return this._parent ? this._parent.children.indexOf(this) : 0; }
  getChildByName(n) { return this.children.find((c) => c.name === n && c.isValid !== false) ?? null; }
  setSiblingIndex(i) { this.sibling = i; }
  setPosition(x, y, z) { this.position = { x, y, z }; }
  setScale(x) { this.scaleX = x; }
  destroy() { this.isValid = false; this.destroyed = true; }
}
// be checked rather than assumed.
const played = [];
class AnimationController {
  playAnimation(name) { played.push(name); }
  readCostume(id) { this.ID = id; }
  update() {}
}
// The card's look, which runs every frame and sets the packet art's colour.
class CardSelectAlmanac {
  update() {}
}

// Plants are pooled, so the mod hooks die and characterOnDisable to take its
// art back off. The fakes inherit from a Plant prototype so those wraps land.
class Plant {
  // The game's shape: a plant with a death clip plays it and waits for
  // COMPLETE before destroying its node; one without is destroyed at once.
  die(kill = true) {
    if (this.dead) return;
    this.dead = true;
    if (kill && this.deathAnm === "") this.node.destroy();
  }
  characterOnDisable() { this.disabled = true; }
}
class CardFeature {
  cardGrouperPlant() { this.built = true; }
}
const makePlant = (id, sheet) => {
  const atlas = { _uuid: `atlas-${id}`, texture: sheet };
  const armature = { animation: { _animations: { Idle: 1, Shoot: 1, Death: 1 }, animationNames: ["Idle", "Shoot", "Death"], lastAnimationState: null } };
  const node = new Node(`plant-${id}`);
  node.layer = 1;
  const body = new Node(`Body`);
  Object.assign(body, { position: { x: 0, y: 0, z: 0 }, scale: { x: 1, y: 1, z: 1 }, angle: 0, layer: 1 });
  body.parent = node;
  const plant = Object.assign(Object.create(Plant.prototype), {
    ID: id,
    dead: false,
    db: {
      dragonAtlasAsset: atlas,
      dragonAsset: { _uuid: `ske-${id}`, clips: ["Idle", "Shoot", "Death"] },
      armatureName: `plant`,
      armature: () => armature,
      node: body,
      timeScale: 1,
      color: { r: 255, g: 255, b: 255, a: 255 },
      _refresh() { this.refreshed = true; },
    },
    anmControl: new AnimationController(),
    material: { props: {}, setProperty(k, v) { this.props[k] = v; } },
    node,
  });
  plant.anmControl.db = plant.db;
  plant.anmControl._db = plant.db;
  plant.__armature = armature;
  return plant;
};
const gunner = makePlant(900002, gatlingSheet);
const gatling = makePlant(8, gatlingSheet);
const sunflower = makePlant(9, sunflowerSheet);
const pool = [gunner, gatling, sunflower];

// A level is running when the board has tiles, which is the gate the mod
// uses before it touches anything.
let levelRunning = true;
const modules = {
  Plants: { plants: { getPlantFeature: (id) => FEATURES[id] } },
  CharacterManager: { PlantPool: { pool: () => pool } },
  AnimationController: { AnimationController },
  Plant: { Plant },
  CardFeature: { CardFeature },
  CardSelectAlmanac: { CardSelectAlmanac },
  Square: { Square: { getLnC: () => (levelRunning ? { lIndex: 0, cIndex: 0 } : null) } },
};
class DragonBonesAsset { }
class DragonBonesAtlasAsset { }
// The stand-in display. Builds from whatever skeleton it's handed, and
// records which clip it was told to follow.
class ArmatureDisplay {
  constructor() { this.timeScale = 1; this.color = { r: 255, g: 255, b: 255, a: 255 }; this._arm = null; this.builds = 0; this._cacheMode = 0; this.matSets = 0; }
  setAnimationCacheMode(mode) { this._cacheMode = mode; this._refresh(); }
  // Baked playback: a clip name and this display's own clock.
  playAnimation(name) { this.animationName = name; this._accTime = 0; this.plays = (this.plays ?? 0) + 1; this._frameCache = { totalTime: 1 }; }
  isAnimationCached() { return this._cacheMode !== 0; }
  // Reading a material back gives a fresh wrapper, like the engine's instances.
  set customMaterial(m) { this._mat = m; this.matSets++; }
  get customMaterial() { return this._mat ? { of: this._mat } : null; }
  _refresh() {
    this._arm = null;
    if (!this.dragonAsset || !this.dragonAtlasAsset) return;
    let json = this.dragonAsset._dragonBonesJson ?? this.dragonAsset.dragonBonesJson;
    try {
      if (typeof json === "string") json = JSON.parse(json);
    } catch (err) {
      json = null;
    }
    const arm = json?.armature?.find((a) => a.name === this.armatureName) ?? json?.armature?.[0];
    if (json?.armature && !arm) return;
    const names = arm ? (arm.animation ?? []).map((a) => a.name) : (this.dragonAsset.clips ?? ["Idle"]);
    this.builds++;
    const animation = {
      _animations: Object.fromEntries(names.map((n) => [n, 1])),
      animationNames: names,
      lastAnimationState: null,
      isPlaying: true,
      plays: 0,
      gotoAndPlayByTime(name, time) { this.plays++; this.lastAnimationState = { name, currentTime: time, totalTime: 1 }; },
    };
    this._arm = { animation, getBones: () => arm?.bone ?? [] };
  }
  armature() { return this._arm; }
}
class Sprite { static SizeMode = { RAW: 1 }; }
class UIOpacity {
  constructor() { this.opacity = 255; }
  destroy() { this.node.comps = this.node.comps.filter((c) => c !== this); }
}
// Visible: switched on and above the mod's near-zero opacity.
const seen = (node) => node.active !== false && (node.getComponent?.(UIOpacity)?.opacity ?? 255) > 1;
// Still drawn by the renderer, so bone-riding points keep moving.
const drawn = (node) => node.active !== false && (node.getComponent?.(UIOpacity)?.opacity ?? 255) > 0;
class SpriteFrame { }
const cc = {
  Texture2D,
  Node,
  Sprite,
  SpriteFrame,
  UIOpacity,
  Vec3: class { constructor(x, y, z) { this.x = x; this.y = y; this.z = z; } },
  tween: () => ({ repeatForever: () => ({ start() {} }), to() { return this; } }),
  dragonBones: { DragonBonesAsset, DragonBonesAtlasAsset, ArmatureDisplay },
  ImageAsset: class { constructor(img) { this.data = img; this.width = img.width; this.height = img.height; } },
  assetManager: { assets: { forEach: (fn) => assets.forEach((v, k) => fn(v, k)) } },
};

const logs = [];
const e = {
  events: { on: (n, fn) => { if (n === "engine:ready") fn(); } },
  log: {
    info: (m) => logs.push(["info", m]),
    error: (m) => logs.push(["error", m]),
    warn: (m) => logs.push(["warn", m]),
  },
  unsafe: {
    engine: {
      getSystemModule: (path) => modules[path.replace("chunks:///_virtual/", "").replace(".ts", "")] ?? null,
      getClassByName: () => null,
      getCc: () => cc,
    },
    hooks: {
      // A real wrap, so the clip remapping is exercised rather than skipped.
      wrapMethod: ({ target, methodName, handler }) => {
        const original = target[methodName];
        target[methodName] = function (...args) {
          return handler({
            args,
            thisArg: this,
            callNext: (...next) => original.apply(this, next),
          });
        };
      },
    },
  },
};

const mod = await import(`file://${file}`);
(mod.default ?? mod.setup ?? globalThis.setup)(e);

const api = globalThis.GreenhouseTextures;
const fails = [];
const check = (what, ok) => {
  console.log(`${ok ? "ok  " : "FAIL"} ${what}`);
  if (!ok) fails.push(what);
};

check("api is exposed", !!api);
const codenames = api.plants();
check("finds plants through their armature", codenames.includes("heliconiagunner"));
check("groups by kind, not by instance", codenames.length === 3);
check("lists loaded textures", api.textures() === 2);
const modded = api.modded();
check("knows which plants are modded", modded.length === 1 && modded[0] === "heliconiagunner");
check("and which are not", !modded.includes("gatlingpea"));

// ---- dressing one plant ----
const png = "data:image/png;base64,AAAA";
const dressed = await api.apply("plant:heliconiagunner", png);
check("dressed the gunner", dressed === 1);
// The game's own way: the plant's one armature takes the new sheet. No second
// display, which cost 0.13 and 0.14 most of the frame rate.
check("the gunner has her own atlas now", gunner.db.dragonAtlasAsset.texture !== gatlingSheet);
check("her new texture is the imported one", gunner.db.dragonAtlasAsset.texture?.width === 128);
check("on her own skeleton, so her attack events stay", gunner.db.dragonAsset?._uuid === "ske-900002");
check("one armature, rebuilt in place", gunner.db.refreshed === true && !gunner.node.children.some((c) => c.name === "gtLook"));
check("Gatling Pea was left alone", gatling.db.dragonAtlasAsset.texture === gatlingSheet);
check("the shared sheet was not repainted", gatlingSheet.image.data.width === 512);
check("the override was saved", api.saved().includes("plant:heliconiagunner"));
check("it reports which route worked", api.routes()["plant:heliconiagunner"] === "atlas");

// ---- nothing happens outside a level ----
levelRunning = false;
const menuGunner = makePlant(900002, gatlingSheet);
pool.push(menuGunner);
await new Promise((r) => setTimeout(r, 2400));
check("nothing is touched outside a level", menuGunner.db.dragonAtlasAsset.texture === gatlingSheet);

// ---- and does once one is running ----
levelRunning = true;
await new Promise((r) => setTimeout(r, 2400));
check("a gunner planted later gets dressed too", menuGunner.db.dragonAtlasAsset.texture?.width === 128);
const secondGunner = menuGunner;

// The bug behind most of this: the engine's _refresh() builds a new armature
// but only its setters and onEnable put one on the world clock. A rebuilt
// armature nothing advances stands frozen and fires no events, so the plant
// never attacks. Faked here the way the engine behaves.
const worldClock = { list: new Set(), add(a) { this.list.add(a); a.clock = this; }, contains(a) { return this.list.has(a); } };
class ClockedDisplay {
  constructor(withFactory) {
    if (withFactory) this._factory = { _dragonBones: { clock: worldClock } };
    this.node = null;
    this._on = true;
    this._build();
    worldClock.add(this._armature);
  }
  _build() {
    this._armature = { clock: null, animation: { _animations: { Idle: 1, Shoot: 1 }, animationNames: ["Idle", "Shoot"], isPlaying: true }, getBones: () => [] };
  }
  _refresh() { this.__builds = (this.__builds ?? 0) + 1; this._build(); }
  armature() { return this._armature; }
  get enabled() { return this._on; }
  set enabled(v) {
    if (v && !this._on && !this._armature.clock) worldClock.add(this._armature);
    this._on = v;
  }
}
for (const [withFactory, how] of [[true, "through the display's factory"], [false, "by switching the display off and on"]]) {
  const frozen = makePlant(900002, gatlingSheet);
  const real = Object.assign(new ClockedDisplay(withFactory), { dragonAtlasAsset: frozen.db.dragonAtlasAsset, dragonAsset: frozen.db.dragonAsset, node: frozen.db.node, armatureName: "plant" });
  frozen.db = real;
  frozen.anmControl.db = real;
  frozen.anmControl._db = real;
  frozen.node.getComponent = (Cls) => (frozen instanceof Cls ? frozen : null);
  frozen.anmControl.node = frozen.node;
  pool.push(frozen);
  frozen.anmControl.readCostume(900002);
  check(`the plant is rebuilt with its new sheet (${how})`, real.__builds >= 1 && real.dragonAtlasAsset?._uuid !== "atlas-900002");
  check(`a rebuilt armature is put back on the clock, ${how}`, real._armature.clock === worldClock && worldClock.contains(real._armature));
  frozen.characterOnDisable();
  check(`and so is the plant's own one when it comes off`, real._armature.clock === worldClock);
  pool.splice(pool.indexOf(frozen), 1);
}

// ---- the whole-sheet route ----
const sheetCount = await api.apply("sheet:uuid-sunflower", png);
check("repainted a shared sheet", sheetCount === 1);
check("everything drawing from it changed", sunflowerSheet.image.data.width === 128);

// A sheet no plant is drawing from is the one that breaks a menu, so it is
// refused rather than repainted.
const orphan = new Texture2D(64, 64);
assets.set("uuid-orphan", orphan);
const refused = await api.apply("sheet:uuid-orphan", png);
check("a sheet nobody is using is refused", refused === 0);
check("the orphan sheet was left alone", orphan.image.data.width === 64);

// ---- undo, and the way out ----
api.undo("plant:heliconiagunner");
check("undo forgets the override", !api.saved().includes("plant:heliconiagunner"));
check("undo gives the gunner her own atlas back", gunner.db.dragonAtlasAsset.texture === gatlingSheet);

// A repainted sheet gets its original image back, not just a forgotten note.
const before = sunflowerSheet.image;
api.undo("sheet:uuid-sunflower");
check("undo repaints a sheet back to what it was", sunflowerSheet.image !== before);
check("and to the right size", sunflowerSheet.width === 256);
await api.apply("plant:sunflower", png);
check("something to clear", api.saved().length > 0);
api.clear();
check("clear forgets every override, but not the settings", api.saved().every((k) => k.startsWith("option:")) && api.saved().includes("option:homepack"));

// ---- a whole armature ----
gunner.__armature.animation._animations = { idle_bzzz: 1, zap: 1 };
const worn = await api.wear("heliconiagunner", {
  skeleton: '{"armature":[{"name":"bzzz","animation":[{"name":"idle_bzzz"},{"name":"zap"}]}]}',
  atlasJson: '{"SubTexture":[],"imagePath":"bzzz.png"}',
  dataUrl: png,
});
// Both gunners are on the lawn by this point, and both should get it.
check("the armature went on every gunner", worn === 2);
check("it carries its own skeleton", gunner.db.dragonAsset instanceof DragonBonesAsset);
check("and its own atlas", gunner.db.dragonAtlasAsset instanceof DragonBonesAtlasAsset);
check("Gatling Pea still has the old one", !(gatling.db.dragonAsset instanceof DragonBonesAsset));
check("the clips it can play were read", api.clips("heliconiagunner").includes("idle_bzzz"));

played.length = 0;
gunner.anmControl.playAnimation("Idle");
check("a clip name the new armature lacks is mapped", played[0] === "idle_bzzz");
gatling.anmControl.playAnimation("Idle");
check("an untouched plant plays what it was asked for", played[1] === "Idle");

const scaled = logs.some(([k, m]) => k === "info" && m.includes("scaled to fit"));
check("an import the wrong size is scaled to the sheet", scaled);

// The refusal above is the only error worth having.
// ---- a still image, for art that isn't a repaint ----
const stills = await api.apply("still:sunflower", png);
check("hung a still image", stills === 1);
check("the picture is on the plant", !!sunflower.__gtStill);
check("the armature is hidden behind it", !seen(sunflower.db.node));
check("it is drawn at a sane size, not 128 tiles tall", sunflower.__gtStill.scaleX < 2);
api.undo("still:sunflower");
check("undo takes the picture away", !sunflower.__gtStill);
check("and brings the armature back", seen(sunflower.db.node));

// ---- fitting art to a rig ----
// Three separate lumps on a 40x40 sheet, at quarter scale like the real scan.
const W = 10;
const H = 10;
const mask = new Uint8Array(W * H);
const blob = (x0, y0, w, h) => {
  for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) mask[y * W + x] = 1;
};
blob(0, 0, 4, 4);   // big
blob(6, 1, 3, 2);   // medium
blob(1, 6, 2, 2);   // small
const found = api.boxesIn(mask, W, H, { step: 4, minSide: 1 });
check("finds every separate lump", found.length === 3);
check("biggest first", found[0].width === 16 && found[0].height === 16);
check("boxes are in sheet pixels, not mask pixels", found[1].x === 24 && found[1].y === 4);
check("touching pixels are one lump, not many", found.every((b) => b.width >= 8));

const rigList = [
  { name: "head", x: 0, y: 0, width: 100, height: 100 },
  { name: "arm", x: 0, y: 0, width: 40, height: 20 },
  { name: "eye", x: 0, y: 0, width: 10, height: 10 },
];
const guess = api.pairUp(rigList, found);
check("auto pair puts the biggest piece on the biggest lump", guess.head === 0);
check("and the smallest on the smallest", guess.eye === 2);

const rigAtlas = { imagePath: "old.png", width: 512, height: 512, SubTexture: [
  { name: "head", x: 5, y: 5, width: 100, height: 100, frameX: -3, frameY: -4 },
  { name: "arm", x: 200, y: 5, width: 40, height: 20 },
  { name: "eye", x: 300, y: 5, width: 10, height: 10 },
  { name: "spare", x: 400, y: 5, width: 8, height: 8 },
]};
const { json: fitted, moved } = api.rewrite(rigAtlas, guess, found, { width: 40, height: 40 });
check("every paired piece was repointed", moved === 3);
const head = fitted.SubTexture.find((t) => t.name === "head");
check("a piece now points at its new box", head.x === 0 && head.width === 16);
check("stale trim offsets are dropped", head.frameX === undefined);
const spare = fitted.SubTexture.find((t) => t.name === "spare");
check("an unpaired piece is left alone", spare.x === 400);
check("the atlas records the new sheet size", fitted.width === 40);
check("the original atlas wasn't modified", rigAtlas.SubTexture[0].x === 5);

// ---- the fit landing on a plant ----
const fitJson = { name: "currant_atlas", imagePath: "old.png", SubTexture: [
  { name: "head", x: 11, y: 22, width: 30, height: 30 },
]};
sunflower.db.dragonAtlasAsset = { _uuid: "atlas-9", texture: sunflowerSheet, atlasJson: JSON.stringify(fitJson) };
const landed = await api.applyFit("sunflower", fitJson, png);
check("the fit went on", landed === 1);
const fittedAtlas = sunflower.db.dragonAtlasAsset;
check("the plant carries the fitted atlas", JSON.parse(fittedAtlas._atlasJson).SubTexture[0].x === 11);
check("on its own skeleton", sunflower.db.dragonAsset?._uuid === "ske-9");
// DragonBones caches parsed atlases by name, so reusing the old name is how a
// fit silently does nothing.
check("the atlas was renamed so it can't be served from cache", JSON.parse(fittedAtlas._atlasJson).name !== "currant_atlas");
check("and it points at the new sheet", fittedAtlas.texture.width === 128);


// ---- a rig of its own ----
const layout = [
  { key: "piece0", box: { x: 0, y: 0, width: 40, height: 40 }, x: 0, y: -20, rotation: 0, scale: 1 },
  { key: "piece1", box: { x: 40, y: 0, width: 20, height: 20 }, x: 6, y: -50, rotation: 10, scale: 0.5 },
];
const ske = api.rigJson(layout, { name: "gt_test" });
const arm = ske.armature[0];
check("a bone and a slot per piece", arm.bone.length === 3 && arm.slot.length === 2);

// ---- keyed by hand, per clip (the Animate step) ----
const keyTemplate = { fps: 24, clips: [
  { name: "Idle", duration: 20, playTimes: 0, frame: null },
  { name: "Attack", duration: 30, playTimes: 1, frame: [{ duration: 12 }, { duration: 18, events: [{ name: "chomp" }] }] },
] };
const keyedLayout = layout.map((piece, i) => ({ ...piece, id: `k${i}` }));
const withKeys = (keys, extra = {}) => api.rigJson(keyedLayout, { name: "gt_keys", template: keyTemplate, anim: { Idle: { tracks: { k1: keys } }, ...extra } }).armature[0];
// A value off a DragonBones timeline, the way the runtime reads it: a
// straight line between frames, or held where a frame has no tweenEasing.
const sampleFrames = (frames, frame, pick) => {
  let at = 0;
  for (let i = 0; i < (frames?.length ?? 0); i++) {
    const f = frames[i];
    const next = frames[i + 1];
    if (!next || frame < at + f.duration) {
      if (!next || at === frame || f.tweenEasing === undefined) return pick(f);
      return pick(f) + ((pick(next) - pick(f)) * (frame - at)) / f.duration;
    }
    at += f.duration;
  }
  return null;
};
const boneIn = (armature, clip, name = "piece1") => armature.animation.find((a) => a.name === clip).bone.find((b) => b.name === name);
const turnAt = (armature, clip, frame, name) => sampleFrames(boneIn(armature, clip, name)?.rotateFrame, frame, (f) => f.rotate);
const even = withKeys([{ f: 0, r: 0 }, { f: 10, r: 30 }]);
// Turns go across in whichever y direction the rigs are set to.
const ys = Math.sign(turnAt(even, "Idle", 10)) || 1;
check("a keyed piece follows its keys in that clip", turnAt(even, "Idle", 0) === 0 && Math.abs(turnAt(even, "Idle", 10)) === 30);
check("and keeps its loop in the others", even.animation.find((a) => a.name === "Attack").bone.some((b) => b.name === "piece1"));
const slow = withKeys([{ f: 0, r: 0, ease: "in" }, { f: 10, r: 40 }]);
check("Speed up eases in, a row a frame", Math.abs(turnAt(slow, "Idle", 5) - 10 * ys) < 1e-9);
const out = withKeys([{ f: 0, r: 0, ease: "out" }, { f: 10, r: 40 }]);
check("Slow down eases out", Math.abs(turnAt(out, "Idle", 5) - 30 * ys) < 1e-9);
const both = withKeys([{ f: 0, r: 0, ease: "inout" }, { f: 10, r: 40 }]);
check("Speed up, slow down is halfway at the middle", Math.abs(turnAt(both, "Idle", 5) - 20 * ys) < 1e-9);
const held = withKeys([{ f: 0, r: 0, ease: "hold" }, { f: 10, r: 40 }]);
check("Hold keeps the value until the next key", turnAt(held, "Idle", 9) === 0 && turnAt(held, "Idle", 10) === 40 * ys);
const faded = withKeys([{ f: 0, a: 1 }, { f: 10, a: 0.25 }]);
const fadeLine = faded.animation.find((a) => a.name === "Idle").slot?.find((l) => l.name === "piece1");
check("opacity keys become the slot's colour frames", fadeLine?.colorFrame?.[0]?.value?.aM === 100 && fadeLine.colorFrame.at(-1).value.aM === 25);
const swapped = withKeys([{ f: 0 }, { f: 8, img: "k0" }]);
const swapSkin = swapped.skin[0].slot.find((sl) => sl.name === "piece1");
const swapLine = swapped.animation.find((a) => a.name === "Idle").slot?.find((l) => l.name === "piece1");
check("a picture swap adds the other picture to the slot", swapSkin.display.length === 2 && swapSkin.display[1].name === "piece0");
check("and switches to it on its key", swapLine?.displayFrame?.[0]?.value === 0 && swapLine.displayFrame[1]?.value === 1 && swapLine.displayFrame[0].duration === 8);
if (process.env.GT_DUMP_HIDE) writeFileSync(process.env.GT_DUMP_HIDE, JSON.stringify(api.rigJson(keyedLayout.map((p, i) => (i === 1 ? { ...p, hidden: true } : p)), { name: "gt_hide", template: keyTemplate, anim: { Attack: { tracks: { k1: [{ f: 0 }, { f: 12, hide: false }, { f: 20, hide: true }] } } } })));
if (process.env.GT_DUMP) {
  const full = api.rigJson(keyedLayout, { name: "gt_full", template: keyTemplate, anim: { Idle: { tracks: { k1: [{ f: 0, r: 0, a: 1, ease: "inout" }, { f: 10, r: 40, a: 0.5 }, { f: 12, img: "k0" }] } } } });
  writeFileSync(process.env.GT_DUMP, JSON.stringify(full));
}
// Hidden pieces: no display until a key shows them.
const hiddenLayout = keyedLayout.map((piece, i) => (i === 1 ? { ...piece, hidden: true } : piece));
const hiddenArm = api.rigJson(hiddenLayout, { name: "gt_hide", template: keyTemplate, anim: { Attack: { tracks: { k1: [{ f: 0 }, { f: 12, hide: false }, { f: 20, hide: true }] } } } }).armature[0];
check("a piece hidden in game starts with no display", hiddenArm.slot.find((sl) => sl.name === "piece1")?.displayIndex === -1);
const shownLine = hiddenArm.animation.find((a) => a.name === "Attack").slot?.find((l) => l.name === "piece1")?.displayFrame;
check("a key shows it and another hides it again", shownLine?.map((f) => f.value).join() === "-1,0,-1" && shownLine[0].duration === 12);
check("and clips that don't key it leave it hidden", !hiddenArm.animation.find((a) => a.name === "Idle").slot?.some((l) => l.name === "piece1"));
const plainHide = withKeys([{ f: 0 }, { f: 6, hide: true }]);
check("any piece can be hidden from a key on", plainHide.animation.find((a) => a.name === "Idle").slot?.find((l) => l.name === "piece1")?.displayFrame?.map((f) => f.value).join() === "0,-1");
// Clips of your own, for things the game has no animation for.
const ownClips = api.rigJson(keyedLayout, { name: "gt_own", template: keyTemplate, clips: [{ name: "Heal", loops: false, length: 18 }, { name: "Fire", loops: true, length: 6 }, { name: "Idle", loops: true, length: 99 }] }).armature[0];
check("a clip of your own goes in with its length", ownClips.animation.find((a) => a.name === "Heal")?.duration === 18 && ownClips.animation.find((a) => a.name === "Heal").playTimes === 1);
check("and loops if it's set to", ownClips.animation.find((a) => a.name === "Fire")?.playTimes === 0 && ownClips.animation.find((a) => a.name === "Fire").duration === 6);
check("but can't replace one the plant has", ownClips.animation.filter((a) => a.name === "Idle").length === 1 && ownClips.animation.find((a) => a.name === "Idle").duration !== 99);
const longer = withKeys([{ f: 0 }], { Idle: { length: 48, tracks: {} }, Attack: { length: 90, tracks: {} } });
check("a clip's length can be set", longer.animation.find((a) => a.name === "Idle").duration === 48);
check("but not one the game times by its events", longer.animation.find((a) => a.name === "Attack").duration === 30);
// Triggers, GD style: each starts on a frame, lasts some frames, eases.
const withTriggers = (triggers, extra = {}, pieces = keyedLayout) => api.rigJson(pieces, { name: "gt_trig", template: keyTemplate, anim: { Idle: { triggers, ...extra } } }).armature[0];
const moveAt = (armature, clip, frame, col = "x", name) => sampleFrames(boneIn(armature, clip, name)?.translateFrame, frame, (f) => f[col]);
const quiet = { loopOff: ["k0", "k1"] };
const slide = withTriggers([{ id: "a", type: "move", targets: ["k1"], f: 2, d: 8, ease: "none", x: 40, y: -16 }], quiet);
check("a Move trigger slides the piece by its amount over its frames", moveAt(slide, "Idle", 2) === 0 && moveAt(slide, "Idle", 6) === 20 && moveAt(slide, "Idle", 10) === 40 && moveAt(slide, "Idle", 20) === 40);
check("and stays there after", Math.abs(moveAt(slide, "Idle", 10, "y")) === 16);
const twoMoves = withTriggers([
  { id: "a", type: "move", targets: ["k1"], f: 0, d: 10, ease: "none", x: 10, y: 0 },
  { id: "b", type: "move", targets: ["k1"], f: 5, d: 10, ease: "none", x: 20, y: 0 },
], quiet);
check("two Moves at once add up, like GD's", moveAt(twoMoves, "Idle", 10) === 20 && moveAt(twoMoves, "Idle", 15) === 30);
const onLoop = withTriggers([{ id: "a", type: "rotate", targets: ["k1"], f: 0, d: 10, ease: "none", r: 90 }]);
const loopOnly = withTriggers([]);
check("a trigger goes on top of the piece's loop", Math.abs(turnAt(onLoop, "Idle", 15) - (turnAt(loopOnly, "Idle", 15) + 90 * ys)) < 1e-6 && turnAt(loopOnly, "Idle", 15) !== 0);
const offLoop = withTriggers([{ id: "a", type: "rotate", targets: ["k1"], f: 0, d: 10, ease: "none", r: 90 }], quiet);
check("or on its own where the loop is switched off in that clip", turnAt(offLoop, "Idle", 15) === 90 * ys && turnAt(offLoop, "Idle", 0) === 0);
check("and the loop still plays in other clips", offLoop.animation.find((a) => a.name === "Attack").bone.some((b) => b.name === "piece1"));
const jump = withTriggers([{ id: "a", type: "move", targets: ["k1"], f: 6, d: 0, x: 30, y: 0 }], quiet);
check("an instant trigger jumps instead of sliding over a frame", moveAt(jump, "Idle", 5.5) === 0 && moveAt(jump, "Idle", 6) === 30);
check("by holding the frame before it (no tweenEasing)", boneIn(jump, "Idle").translateFrame.some((f) => f.tweenEasing === undefined));
const springy = withTriggers([{ id: "a", type: "rotate", targets: ["k1"], f: 0, d: 20, ease: "elasticout", r: 40 }], quiet);
const peak = Math.max(...Array.from({ length: 21 }, (_, f) => Math.abs(turnAt(springy, "Idle", f))));
check("any GD ease plays: Elastic Out overshoots and settles", peak > 40.5 && Math.abs(turnAt(springy, "Idle", 20)) === 40);
const bouncy = withTriggers([{ id: "a", type: "move", targets: ["k1"], f: 0, d: 20, ease: "bounceout", x: 50, y: 0 }], quiet);
check("Bounce Out lands on the value", moveAt(bouncy, "Idle", 20) === 50 && moveAt(bouncy, "Idle", 10) > 25);
const rated = (rate) => moveAt(withTriggers([{ id: "a", type: "move", targets: ["k1"], f: 0, d: 10, ease: "in", rate, x: 100, y: 0 }], quiet), "Idle", 5);
check("Ease In takes a rate", Math.abs(rated(2) - 25) < 1e-6 && rated(4) < rated(2));
const grow = withTriggers([
  { id: "a", type: "scale", targets: ["k1"], f: 0, d: 4, ease: "none", sx: 2, sy: 2 },
  { id: "b", type: "scale", targets: ["k1"], f: 4, d: 4, ease: "none", sx: 1.5, sy: 0.5 },
], quiet);
const sizeAt = (frame, col) => sampleFrames(boneIn(grow, "Idle").scaleFrame, frame, (f) => f[col]);
check("Scale triggers multiply", sizeAt(8, "x") === 3 && sizeAt(8, "y") === 1);
const fades = withTriggers([
  { id: "a", type: "alpha", targets: ["k1"], f: 0, d: 10, ease: "none", a: 0 },
  { id: "b", type: "alpha", targets: ["k1"], f: 10, d: 10, ease: "none", a: 0.5 },
], quiet);
const fadeFrames = fades.animation.find((a) => a.name === "Idle").slot.find((l) => l.name === "piece1").colorFrame;
const alphaAt = (frame) => sampleFrames(fadeFrames, frame, (f) => f.value.aM);
check("Alpha goes to its value from wherever it was", alphaAt(0) === 100 && alphaAt(10) === 0 && alphaAt(20) === 50);
const blink = withTriggers([
  { id: "a", type: "picture", targets: ["k1"], f: 4, d: 0, img: "k0" },
  { id: "b", type: "hide", targets: ["k1"], f: 8, d: 0 },
  { id: "c", type: "show", targets: ["k1"], f: 12, d: 0 },
  { id: "d", type: "picture", targets: ["k1"], f: 12, d: 0, img: null },
], quiet);
const blinkLine = blink.animation.find((a) => a.name === "Idle").slot.find((l) => l.name === "piece1").displayFrame;
check("Picture, Hide and Show switch the slot on their frames", blinkLine.map((f) => f.value).join() === "0,1,-1,0" && blinkLine[0].duration === 4 && blinkLine[1].duration === 4);
const pair2 = withTriggers([{ id: "a", type: "move", targets: ["k0", "k1"], f: 0, d: 4, ease: "none", x: 8, y: 0 }], quiet);
check("one trigger can act on several pieces", moveAt(pair2, "Idle", 4, "x", "piece0") === 8 && moveAt(pair2, "Idle", 4) === 8);
check("pieces with no triggers and no loop have no timeline", !withTriggers([], quiet).animation.find((a) => a.name === "Idle").bone.length);
// Idle here loops at the editor's speed: 48 frames.
const past = withTriggers([{ id: "a", type: "move", targets: ["k1"], f: 44, d: 10, ease: "none", x: 100, y: 0 }], quiet);
check("a trigger running past the end is cut short there", moveAt(past, "Idle", 48) === 40);
if (process.env.GT_DUMP_TRIG) {
  writeFileSync(process.env.GT_DUMP_TRIG, JSON.stringify(api.rigJson(keyedLayout, { name: "gt_trig", template: keyTemplate, anim: { Idle: { loopOff: ["k0", "k1"], triggers: [
    { id: "a", type: "move", targets: ["k1"], f: 6, d: 0, x: 30, y: 0 },
    { id: "b", type: "rotate", targets: ["k1"], f: 0, d: 20, ease: "elasticout", r: 40 },
    { id: "c", type: "alpha", targets: ["k1"], f: 0, d: 10, ease: "none", a: 0 },
    { id: "d", type: "hide", targets: ["k1"], f: 12, d: 0 },
    { id: "e", type: "show", targets: ["k1"], f: 16, d: 0 },
  ] } } })));
}
check("the old keys still build the same as their triggers", JSON.stringify(withKeys([{ f: 0, r: 0 }, { f: 10, r: 30 }]).animation) === JSON.stringify(withTriggers([{ id: "a", type: "rotate", targets: ["k1"], f: 0, d: 10, ease: "none", r: 30 }], { loopOff: ["k1"] }).animation));
check("the layout is the rest pose", arm.bone[1].transform.x === 0 && arm.bone[2].transform.x === 6);
check("y goes across as laid out: DragonBones is y-down too", arm.bone[1].transform.y === -20);
check("turn goes on the bone, size on the picture", Math.round(arm.bone[2].transform.skX) === 10 && arm.skin[0].slot[1].display[0].transform.scX === 0.5);
check("the skin points each slot at its piece", arm.skin[0].slot[1].display[0].name === "piece1");
// A piece turns about its pivot, so the picture is offset from the bone.
// Default pivot is the base: the picture sits entirely above the bone.
check("a base pivot stands the picture on the bone", arm.skin[0].slot[0].display[0].transform.y === -20);
const middle = api.rigJson([{ ...layout[0], pivot: 0.5 }]).armature[0];
check("a middle pivot centres it", middle.skin[0].slot[0].display[0].transform.y === 0);
const faster = api.rigJson(layout, { speed: 2 }).armature[0];
check("speed shortens the idle", faster.animation[0].duration < arm.animation[0].duration);
const wilder = api.rigJson(layout, { sway: 10 }).armature[0];
check("sway raises the angles", Math.abs(wilder.animation[0].bone[0].rotateFrame[0].rotate) > Math.abs(arm.animation[0].bone[0].rotateFrame[0].rotate));
check("it comes with animations", arm.animation.map((a) => a.name).join() === "Idle,Shoot,Food");
const idle = arm.animation[0];
check("the idle loops forever", idle.playTimes === 0 && idle.duration === 48);
check("every piece sways, smoothly", idle.bone.length === 2 && idle.bone[0].rotateFrame.length >= 8);
check("neighbouring pieces sway opposite ways", idle.bone[0].rotateFrame[0].rotate > 0 !== idle.bone[1].rotateFrame[0].rotate > 0);

// Pieces named by the user, attached to each other, moving their own way.
const named = [
  { id: "p1", name: "Stem", box: { x: 0, y: 0, width: 20, height: 60 }, x: 0, y: 0, rotation: 0, scale: 1 },
  { id: "p2", name: "Head!", box: { x: 20, y: 0, width: 40, height: 40 }, x: 0, y: -60, rotation: 90, scale: 1, parent: "p1", motion: "bob" },
  { id: "p3", name: "Stem", box: { x: 60, y: 0, width: 10, height: 10 }, x: 30, y: -10, rotation: 0, scale: 2, flip: true, pivotX: 0.5, pivotY: 0.5, motion: "still" },
];
const tree = api.rigJson(named).armature[0];
check("names become bone names", tree.bone.map((b) => b.name).join() === "root,stem,head,stem_2");
check("an attached piece is a child bone", tree.bone.find((b) => b.name === "head").parent === "stem");
check("placed in its parent's space", Math.round(tree.bone.find((b) => b.name === "head").transform.y) === -60);
check("mirroring flips the picture", tree.skin[0].slot[2].display[0].transform.scX === -2);
check("a centred pivot sits in the middle", tree.skin[0].slot[2].display[0].transform.y === 0);
const bob = tree.animation[0].bone.find((b) => b.name === "head");
check("a bobbing piece rises and falls instead of turning", !!bob?.translateFrame && !bob.rotateFrame);
check("a still piece has no animation", !tree.animation[0].bone.some((b) => b.name === "stem_2"));
const loop = api.rigJson([{ id: "a", name: "a", box: { x: 0, y: 0, width: 5, height: 5 }, parent: "b" }, { id: "b", name: "b", box: { x: 0, y: 0, width: 5, height: 5 }, parent: "a" }]).armature[0];
check("pieces attached in a loop come apart instead of hanging", loop.bone.filter((b) => b.parent === "root").length >= 1);

// Synced pieces share one beat: together, or half a beat apart to mirror.
const pair = (sync, opposite) => api.rigJson([
  { id: "l", name: "left", box: { x: 0, y: 0, width: 5, height: 5 }, sync, syncOpposite: false },
  { id: "r", name: "right", box: { x: 0, y: 0, width: 5, height: 5 }, sync, syncOpposite: opposite },
]).armature[0].animation[0].bone.map((b) => b.rotateFrame[0].rotate);
const [apartL, apartR] = pair(null, false);
const [withL, withR] = pair("s1", false);
const [mirL, mirR] = pair("s1", true);
check("unsynced neighbours keep their own beats", Math.sign(apartL) !== Math.sign(apartR));
check("synced pieces move together", withL === withR);
check("mirrored pieces move as opposites on the same beat", mirL === -mirR);

// Every preset loop moves something, and closes where it started.
const one = (extra) => api.rigJson([{ id: "x", name: "x", box: { x: 0, y: 0, width: 5, height: 5 }, ...extra }]).armature[0];
for (const motion of ["sway", "bob", "pulse", "squash", "wiggle", "float", "bounce", "shake", "spin", "flap", "nod"]) {
  const bone = one({ motion }).animation[0].bone[0];
  const track = bone?.rotateFrame ?? bone?.translateFrame ?? bone?.scaleFrame;
  const first = track?.[0];
  const last = track?.at(-1);
  const same = (a, b) => ["rotate", "x", "y"].every((k) => Math.abs(((a?.[k] ?? 0) - (b?.[k] ?? 0)) % 360) < 0.001);
  check(`the ${motion} loop moves and closes cleanly`, !!track && track.length > 2 && same(first, last));
}
const squash = one({ motion: "squash" }).animation[0].bone[0].scaleFrame[0];
check("squash stretches one way as it squashes the other", squash.x > 1 && squash.y < 1);

// Keyframes: a pose at each key, straight lines between, looping round.
const keyed = one({ motion: "custom", keys: [{ t: 0, rotate: 0, x: 0, y: 0, sx: 1, sy: 1 }, { t: 0.5, rotate: 30, x: 10, y: -20, sx: 1.5, sy: 0.5 }] }).animation[0];
const turns = keyed.bone[0].rotateFrame;
check("a keyframe loop hits its key", turns.some((f) => Math.abs(f.rotate - 30) < 0.001));
check("and comes back to the first key at the end", turns[0].rotate === 0 && turns.at(-1).rotate === 0);
check("keys move and stretch the piece too", keyed.bone[0].translateFrame.some((f) => f.x === 10 && f.y === -20) && keyed.bone[0].scaleFrame.some((f) => f.x === 1.5 && f.y === 0.5));
check("the key lands at its moment in the loop", (() => {
  let at = 0;
  for (const f of turns) {
    if (Math.abs(f.rotate - 30) < 0.001) return at === keyed.duration / 2;
    at += f.duration;
  }
  return false;
})());
check("a keyframe piece with no keys holds still", !one({ motion: "custom", keys: [] }).animation[0].bone.length);

// Stretch: the picture, not the bone; the whole plant: the root.
const stretched = one({ scale: 2, scaleX: 1.5, scaleY: 0.5, flip: true }).skin[0].slot[0].display[0].transform;
check("stretch wide and tall size the picture on their own", stretched.scX === -3 && stretched.scY === 1);
const bigPlant = api.rigJson([{ id: "x", name: "x", box: { x: 0, y: 0, width: 5, height: 5 } }], { sizeX: 2, sizeY: 1.5 }).armature[0];
check("whole plant size goes on the root bone", bigPlant.bone[0].transform?.scX === 2 && bigPlant.bone[0].transform?.scY === 1.5);
check("a piece called root doesn't clash with the root bone", one({ name: "root" }).bone.map((b) => b.name).join() === "root,root_2");

// The plant's own clip list: lengths, loops and the frame events it fires
// on, so a rigged Laser Bean still shoots.
const vanilla = {
  frameRate: 30,
  armature: [{ name: "laser", frameRate: 30, animation: [
    { name: "Idle", duration: 40, playTimes: 0 },
    { name: "Shoot", duration: 30, playTimes: 1, frame: [{ duration: 12 }, { duration: 18, events: [{ name: "shoot" }] }] },
    { name: "Death", duration: 20, playTimes: 1 },
  ] }],
};
const copied = api.rigJson(layout, { template: { fps: 30, clips: vanilla.armature[0].animation.map((c) => ({ name: c.name, duration: c.duration, playTimes: c.playTimes, frame: c.frame ?? null })) } }).armature[0];
const shootClip = copied.animation.find((a) => a.name === "Shoot");
check("the plant's clips are copied", copied.animation.map((a) => a.name).join() === "Idle,Shoot,Death");
check("an attack keeps its length", shootClip.duration === 30);
check("and its frame events", shootClip.frame?.[1]?.events?.[0]?.name === "shoot");
check("at the plant's frame rate", copied.frameRate === 30);
check("a death clip shrinks the plant away", copied.animation.find((a) => a.name === "Death").bone.some((b) => b.scaleFrame));

// Read off a real plant: its skeleton json, by its armature's name.
const bean = makePlant(11, sunflowerSheet);
bean.db.dragonAsset = { _uuid: "ske-laser", dragonBonesJson: JSON.stringify(vanilla) };
bean.db.armatureName = "laser";
pool.push(bean);
await api.applyRig("laserbean", layout, png, { width: 128, height: 128 });
const beanArm = JSON.parse(bean.db.dragonAsset._dragonBonesJson).armature[0];
check("a rig built on a plant copies that plant's clips", beanArm.animation.map((a) => a.name).join() === "Idle,Shoot,Death");
check("and its shoot event", beanArm.animation[1].frame?.[1]?.events?.[0]?.name === "shoot");
bean.characterOnDisable();
check("recycled, it gets its own skeleton back", bean.db.dragonAsset._uuid === "ske-laser");
pool.splice(pool.indexOf(bean), 1);

// In the game the skeleton json is gone once parsed, so the clips and their
// events are read off the loaded armature instead: the same arrays the
// runtime fires events from. Before 0.15 a rig fell back to three stock
// clips with no events there, and a rigged Chomper never bit.
const chomper = makePlant(12, sunflowerSheet);
chomper.db.dragonAsset = { _uuid: "ske-chomper" }; // no json on it
const attackData = { frameCount: 30, playTimes: 1, frameOffset: 0, actionTimeline: { offset: 0 } };
const chomperData = {
  frameRate: 24,
  animationNames: ["Idle", "Attack"],
  animations: { Idle: { frameCount: 40, playTimes: 0, actionTimeline: null }, Attack: attackData },
  actions: [{ type: 10, name: "chomp" }, { type: 11, name: "crunch" }],
  // TimelineScale, TimelineOffset, TimelineKeyFrameCount, _, _, then each
  // key frame's offset into frameArray: [position, action count, actions...].
  parent: { timelineArray: [100, 0, 1, 0, 0, 0], frameArray: [12, 2, 0, 1] },
};
attackData.parent = chomperData;
chomperData.animations.Idle.parent = chomperData;
chomper.__armature.armatureData = chomperData;
chomper.__armature.animation._animations = { Idle: 1, Attack: 1 };
// What the game had it doing, so the swap can carry on with it.
const replays = [];
chomper.db.animationName = "Attack";
chomper.db.playTimes = 1;
chomper.db.playAnimation = (name, times) => replays.push([name, times]);
pool.push(chomper);
await api.applyRig("chomper", layout, png, { width: 128, height: 128 });
const chompArm = JSON.parse(chomper.db.dragonAsset?._dragonBonesJson ?? "{}").armature?.[0];
const chompClip = chompArm?.animation?.find((a) => a.name === "Attack");
check("with no json, the clips come off the loaded armature", chompArm?.animation?.map((a) => a.name).join() === "Idle,Attack");
check("at their lengths and loop counts", chompClip?.duration === 30 && chompClip?.playTimes === 1 && chompArm.animation[0].playTimes === 0);
check("with the bite event on the frame it fires", chompClip?.frame?.[0]?.duration === 12 && chompClip?.frame?.[1]?.events?.[0]?.name === "chomp");
check("and the sound", chompClip?.frame?.[1]?.sound === "crunch");
check("the log says where the clips came from", logs.some(([k, m]) => k === "info" && /chomper: 2 clips read from its armature, events in Attack/.test(m)));
check("after the swap it carries on with what it was doing", replays.some(([n, t]) => n === "Attack" && t === 1));
chomper.characterOnDisable();
pool.splice(pool.indexOf(chomper), 1);

const builtAtlas = api.rigAtlas(layout, { width: 128, height: 128 }, "gt_test");
check("the atlas names match the skin", builtAtlas.SubTexture[1].name === "piece1");
check("and carry the boxes", builtAtlas.SubTexture[1].x === 40 && builtAtlas.SubTexture[1].width === 20);

const rigged = await api.applyRig("sunflower", layout, png, { width: 128, height: 128 });
check("the rig went on the plant", rigged >= 1);
check("the plant is wearing a built skeleton", JSON.parse(sunflower.db.dragonAsset._dragonBonesJson).armature[0].name === "gt_sunflower");
check("and the matching atlas", JSON.parse(sunflower.db.dragonAtlasAsset._atlasJson).SubTexture[0].name === "piece0");

// ---- a plant that gets eaten ----
// The reported bug: the art stayed on the pooled object and haunted whatever
// was planted next.
const victim = makePlant(9, sunflowerSheet);
pool.push(victim);
await api.apply("still:sunflower", png);
check("the victim is wearing a still image", !!victim.__gtStill);
// The node the game destroys at the end of a death. Destroying it disables
// the plant, which is where the mod takes its art back off.
const lawnNode = (plant) => {
  const node = new Node("plant");
  node.destroy = function () { this.isValid = false; plant.characterOnDisable(); };
  plant.node = node;
  return node;
};
lawnNode(victim);
victim.deathAnm = "Death";
victim.die();
check("a dying plant keeps its picture, no vanilla frames", !!victim.__gtStill && !seen(victim.db.node));
await new Promise((r) => setTimeout(r, 400));
// Hidden, not off: its own death clip plays and the game ends it as usual.
check("its hidden armature plays its own death, the mod doesn't cut in", victim.node.isValid === true);
victim.node.destroy();
check("and then the picture comes off", !victim.__gtStill);
check("and its armature is shown again for the next plant", seen(victim.db.node));

const carried = makePlant(9, sunflowerSheet);
lawnNode(carried);
pool.push(carried);
await api.apply("still:sunflower", png);
carried.deathAnm = "Death";
carried.die(false);
await new Promise((r) => setTimeout(r, 400));
check("a plant carried off keeps its picture and is left to the game", !!carried.__gtStill && carried.node.isValid);
carried.characterOnDisable();
pool.splice(pool.indexOf(carried), 1);

const painted = makePlant(9, sunflowerSheet);
lawnNode(painted);
pool.push(painted);
api.undo("still:sunflower");
await api.apply("plant:sunflower", png);
painted.deathAnm = "Death";
const paintedAtlas = painted.db.dragonAtlasAsset;
painted.die();
check("a repainted plant dies in its new art", painted.db.dragonAtlasAsset === paintedAtlas && painted.__gtWasAtlas !== undefined);
await new Promise((r) => setTimeout(r, 400));
check("and plays its own death clip rather than being cut short", painted.node.isValid === true);
painted.node.destroy();
check("and gets its own atlas back once it is gone", painted.db.dragonAtlasAsset.texture === sunflowerSheet);
pool.splice(pool.indexOf(painted), 1);
api.undo("plant:sunflower");
await api.apply("still:sunflower", png);

const recycled = makePlant(9, sunflowerSheet);
pool.push(recycled);
await api.apply("plant:sunflower", png);
check("a dressed plant remembers what it had", recycled.__gtWasAtlas !== undefined);
recycled.characterOnDisable();
check("being recycled puts its own atlas back", recycled.db.dragonAtlasAsset.texture === sunflowerSheet);
pool.pop();
pool.pop();
api.undo("still:sunflower");
api.undo("plant:sunflower");

// ---- seed packets ----
await api.applyPacket("sunflower", png);
const card = new CardFeature();
const artNode = new Node("plantDB");
artNode.parent = new Node("cardArt");
artNode.parent.getChildByName = (name) => artNode.parent.children.find((c) => c.name === name);
card.ca = { _plantDB: { node: artNode } };
card.Type = "sunflower";
card.cardGrouperPlant();
check("a card build hides the packet's armature", card.ca._plantDB.enabled === false);
check("and hangs the custom picture on it", artNode.parent.children.some((c) => c.name === "gtPacket"));

// Cards are pooled too. The reported bug: the card that had a custom packet
// gets rebuilt for another plant and comes up blank, because the armature
// underneath was left hidden.
card.Type = "gatlingpea";
card.cardGrouperPlant();
check("a card reused for another plant shows its own art again", card.ca._plantDB.enabled === true);
check("and the custom picture is gone from it", !artNode.parent.children.some((c) => c.name === "gtPacket" && c.isValid));

card.Type = "sunflower";
card.cardGrouperPlant();
check("and it can be dressed again after that", card.ca._plantDB.enabled === false);

// ---- sizes ----
const packetPic = () => artNode.parent.children.filter((c) => c.name === "gtPacket" && c.isValid).pop();
const packetBefore = packetPic().scaleX;
api.packetScale("sunflower", 1.5);
check("packet size resizes a card already showing", packetPic().scaleX > packetBefore);
check("packet size is saved", store.get("greenhousetextures.packetscale:sunflower") === "1.5");
check("packet size is clamped", api.packetScale("sunflower", 99) === 4);

const tall = makePlant(9, sunflowerSheet);
pool.push(tall);
await api.apply("still:sunflower", png);
const small = tall.__gtStill.scaleX;
api.stillScale("sunflower", 3);
await new Promise((r) => setTimeout(r, 20));
check("still size redraws the picture bigger", tall.__gtStill.scaleX > small);
check("still size is saved", store.get("greenhousetextures.stillscale:sunflower") === "3");
check("still size is clamped", api.stillScale("sunflower", -5) === 0.2);
api.undo("still:sunflower");
pool.pop();

// ---- position and layering ----
check("packet offset moves a card already showing",
  api.packetOffset("sunflower", 12, -7).x === 12 && packetPic().position.x === 12 && packetPic().position.y === -7);
check("packet offset is saved", store.get("greenhousetextures.packetoffset:sunflower") === "12,-7");
check("packet offset is clamped", api.packetOffset("sunflower", 500, -500).x === 40);
check("the packet picture sits right above the plant art, under the frame",
  packetPic().sibling === artNode.getSiblingIndex() + 1);
api.packetOffset("sunflower", 0, 0);

// The armature lives on a Body child of the plant node, so the still image
// belongs beside it, not stacked on top of everything the plant carries.
const placed = makePlant(9, sunflowerSheet);
const plantNode = new Node("plant");
const body = new Node("Body");
new Node("shadow").parent = plantNode;
body.parent = plantNode;
body.position = { x: 3, y: 5, z: 0 };
new Node("hpbar").parent = plantNode;
placed.node = plantNode;
placed.db.node = body;
pool.push(placed);
await api.apply("still:sunflower", png);
const pic = placed.__gtStill;
check("still image hangs off the plant, next to its body", pic?.parent === plantNode);
check("and is drawn where the body was in the order", pic?.sibling === 2);
check("and starts where the body is", pic?.position.x === 3 && pic?.position.y === 5);
api.stillOffset("sunflower", 20, -10);
check("still offset moves it without a rebuild", placed.__gtStill === pic && pic.position.x === 23 && pic.position.y === -5);
check("still offset is saved", store.get("greenhousetextures.stilloffset:sunflower") === "20,-10");
check("still offset is clamped", api.stillOffset("sunflower", -999, 0).x === -80);
api.stillOffset("sunflower", 0, 0);
api.undo("still:sunflower");
pool.pop();

// ---- dressed as it arrives ----
// The game builds a plant, then calls readCostume on it in the same tick.
// Dressing there means no frame of the vanilla art.
const spawn = (id) => {
  const plant = makePlant(id, sunflowerSheet);
  const node = new Node("plant");
  node.getComponent = (Cls) => (plant instanceof Cls ? plant : null);
  plant.node = node;
  plant.anmControl.node = node;
  pool.push(plant);
  return plant;
};
api.undo("still:sunflower");
await api.apply("still:sunflower", png);
await new Promise((r) => setTimeout(r, 20));
const fresh = spawn(9);
fresh.anmControl.readCostume(9);
check("a plant is dressed the moment it is built", !!fresh.__gtStill);
check("in the same tick, with its armature already hidden", !seen(fresh.db.node));
const plain = spawn(8);
plain.anmControl.readCostume(8);
check("a plant with nothing saved is left alone", !plain.__gtStill && !plain.db.refreshed && seen(plain.db.node));
pool.splice(pool.indexOf(fresh), 1);
pool.splice(pool.indexOf(plain), 1);

// The almanac, the chooser and the plant in hand show a bare controller,
// no Plant, and pool it by prefab, so the same one comes back for the
// vanilla plant that shares the pack plant's art.
const shown = new AnimationController();
shown.node = new Node("display");
shown.node.getComponent = () => null;
const shownBody = new Node("Body");
shownBody.parent = shown.node;
shown.db = { node: shownBody, armature: () => ({ animation: { _animations: { Idle: 1 } } }), dragonAtlasAsset: { _uuid: "a", texture: sunflowerSheet }, _refresh() {} };
shown.readCostume(9);
check("the almanac's plant wears its custom art", !!shown.__gtStill && !seen(shownBody));
check("its armature is hidden but still running, so animation events still fire", shownBody.active === true);
check("drawn beside its body like on the lawn", shown.__gtStill.parent === shown.node);
shown.readCostume(8);
check("the same display reused for another plant is itself again", !shown.__gtStill && seen(shownBody));
check("and carries nothing of the mod's", shownBody.getComponent(UIOpacity) === null);

// The reported bug: Astrocado stopped doing damage. Laser Bean shoots on a
// frame event, and a switched-off armature doesn't animate.
const shooter = spawn(9);
const shooterBody = new Node("Body");
shooterBody.parent = shooter.node;
shooter.db.node = shooterBody;
shooter.deathAnm = "Death";
shooter.anmControl.readCostume(9);
check("a plant in a still image keeps animating, so it keeps attacking", !!shooter.__gtStill && shooterBody.active === true && !seen(shooterBody));
check("and is still drawn, faintly, so its beam point follows the bone", drawn(shooterBody));
shooter.die();
await new Promise((r) => setTimeout(r, 400));
check("and dies on its own clip, which the game finishes", shooter.node.isValid === true);
shooter.characterOnDisable();
check("and is seen again once recycled", seen(shooterBody));
pool.splice(pool.indexOf(shooter), 1);

// Packets in the almanac: every child of a card is switched on each frame it
// is in view, which is what brought the old art back under the picture.
check("taking a still image off leaves the packet picture alone", store.has("greenhousetextures.packet:sunflower"));
card.Type = "sunflower";
card.cardGrouperPlant();
artNode.active = true;
check("an almanac card switching its children on doesn't bring the old art back", card.ca._plantDB.enabled === false);
const cardLook = new CardSelectAlmanac();
cardLook._plantDB = card.ca._plantDB;
cardLook._plantDB.color = { r: 122, g: 122, b: 122, a: 255 };
cardLook.update();
check("a packet picture dims with the card", packetPic().comp.color?.r === 122);

// Fits and rigs are saved as choices, and rebuilt from the picture at load.
store.set("greenhousetextures.rigart:gatlingpea", png);
store.set("greenhousetextures.rig:gatlingpea", JSON.stringify({ layout: [{ key: "piece0", boxIndex: 0, x: 0, y: 0, rotation: 0, scale: 1 }], options: {} }));
api.reload();
await new Promise((r) => setTimeout(r, 20));
const peashooter = spawn(8);
const ownBones = { _uuid: "ske-gatling", _dragonBonesJson: undefined };
peashooter.db.dragonAsset = ownBones;
peashooter.anmControl.readCostume(8);
check("a saved rig comes back after a restart", JSON.parse(peashooter.db.dragonAsset?._dragonBonesJson ?? "{}").armature?.[0]?.name === "gt_gatlingpea");
peashooter.characterOnDisable();
check("and a recycled plant gets its own skeleton back", peashooter.db.dragonAsset === ownBones);
pool.splice(pool.indexOf(peashooter), 1);
store.delete("greenhousetextures.rigart:gatlingpea");
store.delete("greenhousetextures.rig:gatlingpea");

// ---- art in a pack's textures folder ----
await api.ready();
// Turning everything off earlier switched the shipped art off too, which is
// what a panic button should do. unhide() brings it back.
check("turning everything off switched off shipped art too", !api.saved().includes("still:peashooter"));
check("unhide brings it back", api.unhide() === 3);
await new Promise((r) => setTimeout(r, 20));
check("every pack's textures folder is read", api.saved().includes("still:peashooter"));
check("file names are matched without caring about case", api.saved().includes("still:peashooter") && !api.saved().some((k) => k.includes("Peashooter")));
check("looks.json gives sizes and nudges", api.saved().includes("stillscale:peashooter") && api.saved().includes("stilloffset:peashooter"));
check("anything else in the folder is ignored", !api.saved().some((k) => k.includes("notes")));
const shipped = spawn(10);
shipped.anmControl.readCostume(10);
check("a plant wears art from the folder the moment it arrives", !!shipped.__gtStill && shipped.__gtStillScale === 2);
check("placed where looks.json puts it", shipped.__gtStill.position.x === 4 && shipped.__gtStill.position.y === -6);
check("with nothing written to localStorage", ![...store.keys()].some((k) => k.includes("peashooter")));
pool.splice(pool.indexOf(shipped), 1);

check("with no folder of its own, new art still goes to localStorage", api.folder().own === null && store.has("greenhousetextures.packet:sunflower"));

// This pack gets its textures folder.
putFile("gp-next/packs/GreenhouseTextures/pack.json", text({ uuid: "0ebee2cb-a35f-406f-ae13-6297940d59a0" }));
addDir("gp-next/packs/GreenhouseTextures/textures/removed");
await api.reload();
const own = "gp-next/packs/GreenhouseTextures/textures";
check("finds its own folder by uuid", api.folder().own === own);
const movedIn = await api.moveToFolder();
check("localStorage moves into the folder", movedIn > 0 && files.has(`${own}/sunflower.packet.png`));
check("and leaves localStorage", !store.has("greenhousetextures.packet:sunflower"));
check("sizes go into looks.json", JSON.parse(new TextDecoder().decode(files.get(`${own}/looks.json`))).sunflower?.packetScale === 4);
check("and everything still reads the same", api.saved().includes("packet:sunflower"));
check("a png goes in as the bytes it was", files.get(`${own}/sunflower.packet.png`).length === 3);

await api.apply("still:sunflower", png);
await new Promise((r) => setTimeout(r, 20));
check("new art is written straight into the folder", files.has(`${own}/sunflower.still.png`) && !store.has("greenhousetextures.still:sunflower"));
api.undo("still:sunflower");
await new Promise((r) => setTimeout(r, 20));
check("taking it off moves the file to removed, not the bin", !files.has(`${own}/sunflower.still.png`) && files.has(`${own}/removed/sunflower.still.png`));
// Saved animations: their own files, apart from the plant's one rig slot.
addDir(`${own}/saved`);
const savedAnim = await api.saveAnimation({ name: "Sunny sway", codename: "sunflower", label: "Sunflower", layout: [{ id: "p1", box: { x: 0, y: 0, width: 4, height: 4 } }], options: { sway: 4 }, sheet: png });
check("an animation saves as its own file", savedAnim.where.endsWith("textures/saved/sunny_sway.anim.json") && files.has(`${own}/saved/sunny_sway.anim.json`));
const listed = await api.animations();
check("and is listed back", listed.some((a) => a.name === "Sunny sway" && a.pieces === 1));
// Taking a rig off keeps a copy first.
store.set("greenhousetextures.rig:sunflower", JSON.stringify({ layout: [{ id: "p1", box: { x: 0, y: 0, width: 4, height: 4 } }], options: {} }));
store.set("greenhousetextures.rigart:sunflower", png);
await api.reload();
api.undo("rig:sunflower");
await new Promise((r) => setTimeout(r, 20));
const afterUndo = await api.animations();
check("taking a rig off keeps a copy of it in saved", afterUndo.some((a) => a.codename === "sunflower" && /removed/.test(a.name)));
check("and the rig itself is off", !api.saved().includes("rig:sunflower"));

api.stillScale("sunflower", 2.5);
await new Promise((r) => setTimeout(r, 450));
check("a size change rewrites looks.json", JSON.parse(new TextDecoder().decode(files.get(`${own}/looks.json`))).sunflower?.stillScale === 2.5);

api.undo("still:peashooter");
check("art from another pack is switched off here, its file left alone",
  !api.saved().includes("still:peashooter") && files.has("gp-next/packs/PlantPack/textures/Peashooter.still.png")
  && store.get("greenhousetextures.off:still:peashooter") === "1");
const again = spawn(10);
again.anmControl.readCostume(10);
await api.apply("still:peashooter", png);
check("and applying art again switches it back on", !store.has("greenhousetextures.off:still:peashooter"));
check("written into this pack's folder, which now wins over the other pack's", files.has(`${own}/peashooter.still.png`));
pool.splice(pool.indexOf(again), 1);
check("the fs calls stay inside the app data folder", !fsCalls.includes(undefined));

// The reported bug: a rig built in the animation maker played in the
// editor but the plant stood still. It had a still image saved too, which
// went on over the rig and hid it.
const rigged2 = spawn(11);
rigged2.anmControl.readCostume(11);
await api.apply("still:laserbean", png);
const heldStill = spawn(11);
const plays = [];
heldStill.db.playAnimation = (name, times) => plays.push([name, times]);
heldStill.anmControl.readCostume(11);
check("a plant with a rig doesn't get its still image laid over it", !heldStill.__gtStill && heldStill.db.node.active !== false);
check("it wears the rig", JSON.parse(heldStill.db.dragonAsset?._dragonBonesJson ?? "{}").armature?.[0]?.name === "gt_laserbean");
check("and the rig is set playing its idle", plays.some(([name, times]) => name === "Idle" && times === 0));

// The reported bug: adding a texture to one plant broke others. Every save
// rebuilt every dressed plant's armature, and a rebuilt armature leaves the
// game holding dead parts of the old one, so those plants did nothing.
// Let anything already under way for this plant finish first.
await new Promise((r) => setTimeout(r, 30));
const wornSkeleton = heldStill.db.dragonAsset;
let refreshed = 0;
const realRefresh = heldStill.db._refresh;
heldStill.db._refresh = function () {
  refreshed++;
  return realRefresh?.call(this);
};
const bystander = spawn(8);
bystander.anmControl.readCostume(8);
const bystanderAtlas = bystander.db.dragonAtlasAsset;
await api.apply("still:sunflower", png);
await new Promise((r) => setTimeout(r, 30));
check("saving art for one plant doesn't rebuild a different plant's rig", heldStill.db.dragonAsset === wornSkeleton && refreshed === 0);
check("or touch a plant with nothing saved", bystander.db.dragonAtlasAsset === bystanderAtlas && !bystander.__gtStill);
api.stillScale("sunflower", 1.8);
await new Promise((r) => setTimeout(r, 30));
check("nor does changing another plant's size", heldStill.db.dragonAsset === wornSkeleton && refreshed === 0);
heldStill.db._refresh = realRefresh;
pool.splice(pool.indexOf(bystander), 1);
api.undo("still:sunflower");
pool.splice(pool.indexOf(rigged2), 1);
pool.splice(pool.indexOf(heldStill), 1);
api.undo("still:laserbean");

// ---- the animation maker, driven through a fake page ----
const uiNodes = [];
const ctxStub = new Proxy({}, {
  get: (t, k) => (k === "getImageData"
    ? (x, y, w, h) => {
      const data = new Uint8ClampedArray(w * h * 4);
      for (const [bx, by, side] of [[8, 8, 40], [64, 64, 24]]) {
        for (let yy = by; yy < by + side; yy++) for (let xx = bx; xx < bx + side; xx++) data[(yy * w + xx) * 4 + 3] = 255;
      }
      return { data };
    }
    : () => {}),
  set: () => true,
});
const makeNode = (tag) => {
  const node = {
    tag, style: {}, children: [], dataset: {}, listeners: {}, textContent: "", value: "",
    appendChild(c) { this.children.push(c); return c; },
    remove() { this.removed = true; },
    focus() {}, click() {}, setSelectionRange() {},
    addEventListener(t, fn) { (this.listeners[t] ??= []).push(fn); },
    removeEventListener() {},
    querySelector: () => null,
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 800, height: 600 }),
    getContext: () => ctxStub,
    toDataURL: () => "data:image/png;base64,COMBINED",
  };
  Object.defineProperty(node, "innerHTML", { set() { node.children = []; }, get() { return ""; } });
  uiNodes.push(node);
  return node;
};
const allNodes = (root, out = []) => {
  out.push(root);
  for (const c of root.children ?? []) allNodes(c, out);
  return out;
};
const realCreate = document.createElement;
document.createElement = makeNode;
const ev = (extra) => ({ preventDefault() {}, stopPropagation() {}, target: { tagName: "DIV" }, ...extra });
api.animate("sunflower", png);
await new Promise((r) => setTimeout(r, 20));
const win = uiNodes.find((n) => n.tabIndex === 0);
check("the animation maker opens", !!win);
const find = (text) => allNodes(win).find((n) => n.tag === "button" && n.textContent.includes(text));
check("a first look starts on cutting out pieces", !!find("Find pieces") && !!find("Next: build the plant"));
const stageCanvas = allNodes(win).find((n) => n.tag === "canvas" && n.onmousedown);
const countRows = () => allNodes(win).filter((n) => n.tag === "input" && n.dataset.name).length;
const rowsBefore = countRows();
stageCanvas.onmousedown(ev({ button: 0, clientX: 200, clientY: 300 }));
const moveFns = listeners.filter(([n]) => n === "mousemove").map(([, fn]) => fn);
const upFns = listeners.filter(([n]) => n === "mouseup").map(([, fn]) => fn);
moveFns.at(-1)(ev({ clientX: 260, clientY: 360 }));
upFns.at(-1)(ev({}));
check("dragging on an empty spot draws a new piece", countRows() === rowsBefore + 1);
check("with a name to edit, not a number", allNodes(win).some((n) => n.tag === "input" && /^piece \d+$/.test(n.value)));
win.listeners.keydown.forEach((fn) => fn(ev({ key: "z", ctrlKey: true })));
check("Ctrl+Z takes it back", countRows() === rowsBefore);
win.listeners.keydown.forEach((fn) => fn(ev({ key: "y", ctrlKey: true })));
check("Ctrl+Y puts it back", countRows() === rowsBefore + 1);
find("Next: build the plant").onclick(ev({}));
check("step two shows the pieces as pictures with names", !!find("Build and wear") && allNodes(win).filter((n) => n.tag === "canvas").length > 2);
check("and no box sizes anywhere", !allNodes(win).some((n) => /\d+x\d+/.test(n.textContent)));
const draftNow = () => JSON.parse(store.get("greenhousetextures.rigdraft:sunflower") ?? "{}").layout ?? [];
win.listeners.keydown.forEach((fn) => fn(ev({ key: "a", ctrlKey: true })));
find("Move together").onclick(ev({}));
check("picking several and syncing puts them on one beat", draftNow().length > 1 && draftNow().every((q) => q.sync && q.sync === draftNow()[0].sync));
const countBefore = draftNow().length;
find("Copy").onclick(ev({}));
check("Copy duplicates every picked piece", draftNow().length === countBefore * 2);
check("copies get their own names", new Set(draftNow().map((q) => q.name)).size === draftNow().length);
check("and use the same art", draftNow().at(-1).box.x === draftNow()[countBefore - 1].box.x);
win.listeners.keydown.forEach((fn) => fn(ev({ key: "Delete" })));
check("Delete removes everything picked (the copies)", draftNow().length === countBefore);
win.listeners.keydown.forEach((fn) => fn(ev({ key: "a", ctrlKey: true })));
find("Mirror each other").onclick(ev({}));
check("Mirror each other alternates them within the group", draftNow().some((q) => q.syncOpposite) && draftNow().some((q) => !q.syncOpposite));
find("Stop syncing").onclick(ev({}));
check("and Stop syncing lets them go", draftNow().every((q) => !q.sync));
find("Mirror each other").onclick(ev({}));
find("Add piece").onclick(ev({}));
check("Add piece goes back to cutting one out", !!find("Find pieces"));
find("Next: build the plant").onclick(ev({}));
// Step two is everything now: the layout, and every clip under the stage.
win.listeners.keydown.forEach((fn) => fn(ev({ key: "Tab" })));
check("there is no step three", !find("3  Animate") && !!find("2  Build and animate"));
check("the old keyframe loop isn't offered to a piece that doesn't have it", !allNodes(win).some((n) => n.tag === "option" && n.value === "custom"));
const wide = allNodes(win).filter((n) => n.tag === "input" && n.type === "range" && n.max === "3" && n.min === "0.2");
check("each piece can be stretched wide and tall", wide.length >= 2);
const optionsNow = () => JSON.parse(store.get("greenhousetextures.rigdraft:sunflower") ?? "{}").options ?? {};
const exactButton = (text) => allNodes(win).find((n) => n.tag === "button" && n.textContent === text);
const clipChips = () => {
  const layoutChip = exactButton("Layout");
  const bar = allNodes(win).find((n) => n.children?.includes(layoutChip));
  return bar.children.filter((c) => c.tag === "button" && c !== layoutChip);
};
check("the clips sit under the stage, after Layout", !!exactButton("Layout") && clipChips().length >= 2);
check("with GD's edit buttons under them", !!exactButton("\u2190") && !!exactButton("\u21BB 15") && allNodes(win).some((n) => n.textContent === "Edit layout:"));
const pickedPiece = () => draftNow().find((q) => allNodes(win).some((n) => n.tag === "input" && n.dataset?.name === q.id));
const laidOut = { ...pickedPiece() };
exactButton("\u2192").onclick(ev({}));
check("in the layout the arrows move the piece", pickedPiece().x === laidOut.x + 5);
const clipChip = clipChips()[0];
const clipName = clipChip.textContent;
clipChip.onclick(ev({}));
const tlCanvas = allNodes(win).filter((n) => n.tag === "canvas" && n.ondblclick).find((n) => n !== stageCanvas);
check("picking a clip shows its timeline", !!tlCanvas && allNodes(win).some((n) => n.textContent === `Clip: ${clipName}`));
check("and the same buttons now edit triggers", allNodes(win).some((n) => n.textContent === "Edit triggers:"));
const triggersNow = () => optionsNow().anim?.[clipName]?.triggers ?? [];
const keyDown = (key, extra = {}) => win.listeners.keydown.forEach((fn) => fn(ev({ key, ...extra })));
const layoutBefore = JSON.stringify(draftNow());
keyDown("ArrowUp", { shiftKey: true });
check("an arrow in a clip makes a Move trigger at the red line", triggersNow().length === 1 && triggersNow()[0].type === "move" && triggersNow()[0].f === 0 && triggersNow()[0].y === -10);
keyDown("ArrowUp");
check("and the next arrow changes that trigger rather than making another", triggersNow().length === 1 && triggersNow()[0].y === -11);
check("without touching the layout", JSON.stringify(draftNow()) === layoutBefore);
exactButton("\u21BB 15").onclick(ev({}));
const firstEnd = triggersNow()[0].f + triggersNow()[0].d;
check("a turn button makes a Rotate trigger where the Move ends", triggersNow().length === 2 && triggersNow()[1].type === "rotate" && triggersNow()[1].r === 15 && triggersNow()[1].f === firstEnd);
check("with its own panel", allNodes(win).some((n) => n.textContent === "Rotate trigger"));
const easeSelect = allNodes(win).find((n) => n.tag === "select" && n.children.some((o) => o.value === "elasticout"));
easeSelect.value = "bounceout";
easeSelect.onchange();
check("it takes any of GD's eases", triggersNow()[1].ease === "bounceout");
keyDown("Delete");
check("Delete removes the picked trigger, not the piece", triggersNow().length === 1 && draftNow().length === rowsBefore + 1);
keyDown("z", { ctrlKey: true });
check("and undo brings it back", triggersNow().length === 2);
const addHide = allNodes(win).find((n) => n.tag === "button" && n.textContent === "Hide" && n.style.borderLeft);
addHide.onclick(ev({}));
check("Add a trigger makes one of any kind at the red line", triggersNow().some((t) => t.type === "hide" && t.d === 0));
// On the stage in a clip: a click picks, a drag makes a Move trigger.
keyDown("Escape");
const countT = triggersNow().length;
const onStage = draftNow().find((q) => q.id === triggersNow()[0].targets[0]);
const press = (dy) => {
  stageCanvas.onmousedown(ev({ button: 0, clientX: 400 + onStage.x, clientY: 492 + onStage.y - 4 }));
  if (dy) listeners.filter(([n]) => n === "mousemove").at(-1)[1](ev({ clientX: 400 + onStage.x, clientY: 492 + onStage.y - 4 + dy }));
  listeners.filter(([n]) => n === "mouseup").at(-1)[1](ev({}));
};
press(0);
check("clicking a piece in a clip only picks it", triggersNow().length === countT);
press(-30);
check("dragging it makes a Move trigger at the red line, by as far as it went", triggersNow().length === countT + 1 && triggersNow().at(-1).type === "move" && triggersNow().at(-1).y === -30);
check("and leaves the layout alone", JSON.stringify(draftNow()) === layoutBefore);
// The timeline: drag a bar to move it in time.
const target = triggersNow()[0];
const lane = draftNow().findIndex((q) => q.id === target.targets[0]);
if (lane >= 0 && lane < 8) {
  const len = Math.max(...triggersNow().map((t) => t.f + t.d), 1);
  const xOf = (f, length) => 104 + (f / length) * (600 - 104 - 12);
  const clipLen = Number((allNodes(win).find((n) => /^\d+ frames at /.test(n.textContent ?? ""))?.textContent ?? "0").split(" ")[0]);
  tlCanvas.onmousedown(ev({ clientX: xOf(target.f, clipLen) + 3, clientY: 18 + 14 + lane * 20 + 6 }));
  const tlMoves = listeners.filter(([n]) => n === "mousemove").map(([, fn]) => fn);
  const tlUps = listeners.filter(([n]) => n === "mouseup").map(([, fn]) => fn);
  tlMoves.at(-1)(ev({ clientX: xOf(target.f + 3, clipLen) + 3 }));
  tlUps.at(-1)(ev({}));
  check("dragging a bar on the timeline moves its trigger in time", triggersNow()[0].f === target.f + 3 && len > 0);
}
const smooth = exactButton("Add a return");
if (smooth) {
  smooth.onclick(ev({}));
  check("a loop that wouldn't close gets a return added", !exactButton("Add a return"));
}
find("Copy triggers to that clip").onclick(ev({}));
check("a clip's triggers copy to another clip", Object.values(optionsNow().anim ?? {}).filter((a) => a.triggers?.length).length === 2);
find("Export for DragonBones").onclick(ev({}));
await new Promise((r) => setTimeout(r, 20));
check("and export as DragonBones files", [`sunflower_ske.json`, `sunflower_tex.json`, `sunflower_tex.png`].every((f) => files.has(`${own}/saved/${f}`)));
const exported = JSON.parse(new TextDecoder().decode(files.get(`${own}/saved/sunflower_ske.json`)));
check("with the triggers in them", exported.armature[0].animation.some((a) => a.bone.some((b) => b.rotateFrame || b.translateFrame)));
check("and the header says the plant hasn't got them yet", !!find("Build and wear *"));
// Clips of your own, and what a plant pack asks for.
globalThis.GreenhouseActs = { sunflower: [{ name: "Heal", loops: false, length: 18, when: "she heals" }] };
exactButton("Layout").onclick(ev({}));
check("clips of your own are listed with what another pack plays", allNodes(win).some((n) => n.textContent === "Heal: when she heals"));
allNodes(win).find((n) => n.tag === "button" && n.textContent === "Add").onclick(ev({}));
check("Add makes that clip", (optionsNow().clips ?? []).some((c) => c.name === "Heal" && c.length === 18));
check("opens it, and says when it plays", allNodes(win).some((n) => /Another pack plays this when she heals/.test(n.textContent)));
check("and it's a chip under the stage", !!exactButton("Heal"));
const clipInput = allNodes(win).find((n) => n.tag === "input" && n.placeholder === "new clip name");
clipInput.value = "Wave";
clipInput.oninput();
find("New clip").onclick(ev({}));
check("New clip makes one of your own", (optionsNow().clips ?? []).some((c) => c.name === "Wave"));
exactButton("Layout").onclick(ev({}));
// Show and hide: in the editor only, or in game.
const eyeButton = allNodes(win).find((n) => n.tag === "button" && n.textContent === "Hide");
eyeButton.onclick(ev({}));
check("Hide switches a piece off in the editor", (optionsNow().viewOff ?? []).length === 1);
check("without hiding it in game", !draftNow().some((q) => q.hidden));
allNodes(win).find((n) => n.tag === "button" && n.textContent === "Show").onclick(ev({}));
check("and Show brings it back", (optionsNow().viewOff ?? []).length === 0);
const hiddenTick = allNodes(win).find((n) => n.tag === "input" && n.type === "checkbox" && allNodes(win).some((m) => m.children?.includes(n) && m.children.some((c) => c.textContent === "Hidden")));
hiddenTick.checked = true;
hiddenTick.onchange();
check("a piece can be hidden in game until an animation shows it", draftNow().some((q) => q.hidden));
hiddenTick.checked = false;
hiddenTick.onchange();
find("Build and wear").onclick(ev({}));
await new Promise((r) => setTimeout(r, 20));
const savedRig = JSON.parse(store.get("greenhousetextures.rig:sunflower") ?? new TextDecoder().decode(files.get(`${own}/sunflower.rig.json`) ?? new Uint8Array()) ?? "null");
check("building saves the pieces with their own boxes and names", savedRig?.layout?.length === rowsBefore + 1 && savedRig.layout.every((piece) => piece.box && piece.name));
check("and their sync", savedRig.layout.some((piece) => piece.sync && piece.syncOpposite));
check("and the triggers made in clips", Object.values(savedRig.options?.anim ?? {}).filter((a) => a.triggers?.length).length === 2);
check("and then the header says so", !find("Build and wear *"));
find("Close").onclick(ev({}));
check("and Close closes it", win.removed === true);

// More than one sprite sheet: packed side by side into one picture.
const packed = await api.packSheets([png, png, png]);
check("two sheets pack side by side, the first at the top left", packed.regions[0].x === 0 && packed.regions[0].y === 0 && packed.regions[1].x === 132);
check("a third goes where it keeps the picture squarest", packed.regions[2].y === 132 && packed.width === 260 && packed.height === 260);
globalThis.FileReader = class {
  readAsDataURL(file) {
    this.result = file.data;
    setTimeout(() => this.onload?.(), 0);
  }
};
// Keys made before triggers open as triggers.
const oldRig = JSON.parse(store.get("greenhousetextures.rig:sunflower") ?? new TextDecoder().decode(files.get(`${own}/sunflower.rig.json`)));
const oldId = oldRig.layout[0].id;
store.set("greenhousetextures.rigdraft:sunflower", JSON.stringify({ layout: oldRig.layout, options: { ...oldRig.options, anim: { [clipName]: { tracks: { [oldId]: [{ f: 0 }, { f: 6, r: 20 }] } } } } }));
await api.reload();
api.animate("sunflower", png);
await new Promise((r) => setTimeout(r, 20));
const win2 = uiNodes.filter((n) => n.tabIndex === 0).at(-1);
const find2 = (text) => allNodes(win2).find((n) => n.tag === "button" && n.textContent.includes(text));
check("keys made before open as triggers", !!allNodes(win2).find((n) => n.tag === "button" && n.textContent === `${clipName} (1)`)
  && allNodes(win2).some((n) => /Keys made before this version are triggers now/.test(n.textContent ?? "")));
check("the editor has Add sprite sheets", !!find2("Add sprite sheets"));
find2("Add sprite sheets").onclick(ev({}));
const chooser = uiNodes.filter((n) => n.tag === "input" && n.type === "file").at(-1);
check("which lets you pick several files at once", chooser?.multiple === true);
chooser.files = [{ name: "leaves.png", data: png }, { name: "head.png", data: png }];
chooser.onchange();
await new Promise((r) => setTimeout(r, 40));
const win3 = uiNodes.filter((n) => n.tabIndex === 0).at(-1);
check("the editor comes back on the combined picture", win3 !== win2 && win2.removed === true);
check("saying what was added", allNodes(win3).some((n) => /Added 2 sheets/.test(n.textContent)));
const combinedDraft = JSON.parse(store.get("greenhousetextures.rigdraft:sunflower") ?? "{}");
check("remembering where each sheet sits", combinedDraft.options?.sheets?.length === 3);
check("and the combined picture is saved for the rig", files.get(`${own}/sunflower.rig.png`) !== undefined || store.has("greenhousetextures.rigart:sunflower"));
// The Saved panel: save what's open, see it listed, open it again.
const inWin3 = (text) => allNodes(win3).find((n) => n.tag === "button" && n.textContent === text);
inWin3("Saved").onclick(ev({}));
await new Promise((r) => setTimeout(r, 30));
check("Saved opens the saved animations", allNodes(win3).some((n) => n.textContent === "Saved animations"));
inWin3("Save").onclick(ev({}));
await new Promise((r) => setTimeout(r, 40));
check("Save keeps what's open", allNodes(win3).some((n) => /^Saved "/.test(n.textContent ?? "")));
const openButtons = allNodes(win3).filter((n) => n.tag === "button" && n.textContent === "Open");
check("and it's listed with the others to open again", openButtons.length >= 2);
inWin3("Back to editing").onclick(ev({}));
allNodes(win3).find((n) => n.tag === "button" && n.textContent === "Close").onclick(ev({}));

// A real card from the game is drawn behind the picture: its sprites and
// labels, under or over the plant art as they're ordered.
const mat = (x, y, k = 1) => ({ m00: k, m01: 0, m04: 0, m05: k, m12: x, m13: y });
const uiNode = (name, x, y, comps = []) => {
  const n = new Node(name);
  n.worldMatrix = mat(x, y);
  n.activeInHierarchy = true;
  n._uiProps = { uiTransformComp: { contentSize: { width: 80, height: 100 }, anchorPoint: { x: 0.5, y: 0.5 } }, opacity: 1 };
  n.components = comps;
  return n;
};
const cardRoot = uiNode("card", 0, 0);
const cardHolder = uiNode("holder", 0, 0);
cardHolder.parent = cardRoot;
const bgNode = uiNode("bg", 0, 0, [{ spriteFrame: { texture: { image: { data: { width: 64, height: 64 } } }, rect: { x: 0, y: 0, width: 64, height: 64 } }, color: { a: 255 } }]);
bgNode.parent = cardHolder;
const plantArt = uiNode("plantDB", 0, 10);
plantArt.position = { x: 0, y: 10, z: 0 };
plantArt.parent = cardHolder;
const costNode = uiNode("cost", 0, -40, [{ string: "150", fontSize: 18, color: { r: 0, g: 0, b: 0, a: 255 } }]);
costNode.parent = cardHolder;
const realCard = new CardFeature();
realCard.node = cardRoot;
realCard.ca = { _plantDB: { node: plantArt } };
realCard.Type = "peashooter";
realCard.cardGrouperPlant();
api.packetEditor("peashooter", "Peashooter");
await new Promise((r) => setTimeout(r, 20));
const cardWin = uiNodes.filter((n) => n.tabIndex === 0).at(-1);
check("the packet editor knows the card's size from a real one", allNodes(cardWin).some((n) => /measured off a real one/.test(n.textContent ?? "")));
allNodes(cardWin).find((n) => n.tag === "button" && n.textContent === "Measure the card").onclick(ev({}));
check("and says what it measured", allNodes(cardWin).some((n) => n.textContent === "Card measured: 80 by 100."));
allNodes(cardWin).find((n) => n.tag === "button" && n.textContent === "Close").onclick(ev({}));

// The packet editor: layers in, one picture out.
api.packetEditor("sunflower", "Sunflower");
await new Promise((r) => setTimeout(r, 20));
const pwin = uiNodes.filter((n) => n.tabIndex === 0).at(-1);
const inP = (text) => allNodes(pwin).find((n) => n.tag === "button" && n.textContent === text);
check("the packet editor opens for any plant by name", allNodes(pwin).some((n) => n.textContent === "Packet editor: Sunflower"));
const layerCount = () => allNodes(pwin).filter((n) => n.tag === "span" && n.style.textOverflow === "ellipsis").length;
const layersBefore = layerCount();
inP("Colour").onclick(ev({}));
check("Colour adds a layer", layerCount() === layersBefore + 1);
check("with its own colour and shape", allNodes(pwin).some((n) => n.tag === "input" && n.type === "color"));
check("under the plant, as the background", allNodes(pwin).some((n) => n.textContent === "Background (under the plant)"));
check("which switches the game's own background off", allNodes(pwin).some((n) => /background is switched off under yours/.test(n.textContent ?? "")));
pwin.listeners.keydown.forEach((fn) => fn(ev({ key: "ArrowLeft", shiftKey: true })));
pwin.listeners.keydown.forEach((fn) => fn(ev({ key: "z", ctrlKey: true })));
pwin.listeners.keydown.forEach((fn) => fn(ev({ key: "z", ctrlKey: true })));
check("undo takes layers back out", layerCount() === layersBefore);
pwin.listeners.keydown.forEach((fn) => fn(ev({ key: "y", ctrlKey: true })));
pwin.listeners.keydown.forEach((fn) => fn(ev({ key: "y", ctrlKey: true })));
// The card measured above is 80 by 100 from x -40, y -40; the view fits it
// and a margin of a fifth of its longest side all round.
const pCanvas = allNodes(pwin).find((n) => n.tag === "canvas" && n.onmousedown && n.onwheel);
const projNow = () => JSON.parse(store.get("greenhousetextures.packetproj:sunflower") ?? (new TextDecoder().decode(files.get(`${own}/sunflower.packet.json`) ?? new Uint8Array()) || "null"));
const A = { x: -60, y: -60, w: 120, h: 140 };
const z = Math.min(800 / (A.w * 1.1), 600 / (A.h * 1.1));
const at = (x, y) => ({ clientX: 400 - (A.x + A.w / 2) * z + x * z, clientY: 300 - (A.y + A.h / 2) * z + y * z });
// Pick the colour in the list: the plant picture covers it on the stage.
const rowOf = (name) => allNodes(pwin).find((n) => n.onclick && n.children?.some((c) => c.textContent === name));
rowOf("colour").onclick(ev({}));
// It fills the card, and was nudged 5 left: centre (-5, 10), a corner at
// (35, 60). Dragging that corner twice as far out doubles it.
pCanvas.onmousedown(ev({ button: 0, ...at(35, 60) }));
listeners.filter(([n]) => n === "mousemove").at(-1)[1](ev(at(75, 110)));
listeners.filter(([n]) => n === "mouseup").at(-1)[1](ev({}));
const sizedText = allNodes(pwin).filter((n) => n.tag === "input" && n.type === "range" && n.max === "6").map((n) => Number(n.value));
check("dragging a corner sizes the layer", sizedText.some((v) => v > 1.8 && v < 2.2));
// A side handle stretches it wide on its own.
pCanvas.onmousedown(ev({ button: 0, ...at(75, 10) }));
listeners.filter(([n]) => n === "mousemove").at(-1)[1](ev(at(115, 10)));
listeners.filter(([n]) => n === "mouseup").at(-1)[1](ev({}));
const wideNow = allNodes(pwin).filter((n) => n.tag === "input" && n.type === "range" && n.max === "6").map((n) => Number(n.value));
check("dragging a side stretches it wide", wideNow.some((v) => v > 1.4 && v < 1.6));
const pHide = allNodes(pwin).filter((n) => n.tag === "button" && n.textContent === "Hide").at(0);
pHide.onclick(ev({}));
check("a layer can be hidden", allNodes(pwin).some((n) => n.tag === "button" && n.textContent === "Show"));
allNodes(pwin).find((n) => n.tag === "button" && n.textContent === "Show").onclick(ev({}));
// Pictures of your own for the background and the border.
const pickOne = async (buttonText, name) => {
  inP(buttonText).onclick(ev({}));
  const input = uiNodes.filter((n) => n.tag === "input" && n.type === "file").at(-1);
  input.files = [{ name, data: png }];
  input.onchange();
  await new Promise((r) => setTimeout(r, 30));
};
await pickOne("Background", "leaves.png");
check("Background imports a picture under the plant", allNodes(pwin).some((n) => n.textContent === "leaves"));
await pickOne("Border", "frame.png");
check("Border imports one over it", allNodes(pwin).some((n) => n.textContent === "frame"));
const plateTick = allNodes(pwin).find((n) => n.tag === "input" && n.type === "checkbox" && allNodes(pwin).some((m) => m.children?.includes(n) && m.children.some((c) => c.textContent === "Hide the sun cost plate")));
plateTick.checked = true;
plateTick.onchange();
inP("Save").onclick(ev({}));
await new Promise((r) => setTimeout(r, 450));
check("Save makes the packet pictures, one a part", ["packet:sunflower", "packetback:sunflower", "packetfront:sunflower"].every((k) => api.saved().includes(k)));
check("as files beside the rest of its look", [`sunflower.packetback.png`, `sunflower.packetfront.png`].every((f) => files.has(`${own}/${f}`)));
check("with the layers as they were left", projNow()?.layers?.some((l) => l.kind === "box" && l.scale > 1.8 && l.part === "back"));
check("and what's hidden of the game's card", projNow()?.card?.hideBg === true && projNow()?.card?.hidePlate === true && projNow()?.card?.hideFamily === false);
check("and keeps the layers to edit again", api.saved().includes("packetproj:sunflower"));
const packetLooks = JSON.parse(new TextDecoder().decode(files.get(`${own}/looks.json`)));
check("sized and placed to cover the card and its margin", Math.abs(packetLooks.sunflower?.packetScale - 140 / 62) < 0.01 && packetLooks.sunflower?.packetOffset?.join() === "0,-10");
// On a card in game: a background under the plant art, a border over it,
// and the game's own background and sun plate switched off, not removed.
const fakeArm = () => ({ enabled: true, color: { r: 140, g: 140, b: 140, a: 255 }, playAnimation() {} });
const sunCard = new CardFeature();
const sunHolder = uiNode("sunCard", 0, 0);
const partNode = (name, comp) => {
  const n = uiNode(name, 0, 0);
  n.components = comp ? [comp] : [];
  n.parent = sunHolder;
  return n;
};
const bgArm = fakeArm();
const plateArm = fakeArm();
const familyArm = fakeArm();
partNode("Background", bgArm);
const sunArt = partNode("Plant");
sunArt.position = { x: 0, y: 10, z: 0 };
partNode("Dots", plateArm);
partNode("Family", familyArm);
const sunDB = { node: sunArt, enabled: true, color: { r: 255, g: 255, b: 255, a: 255 } };
sunCard.ca = { _plantDB: sunDB };
sunCard.Type = "sunflower";
sunCard.cardGrouperPlant();
const sunKids = () => sunHolder.children.filter((c) => c.isValid !== false).map((c) => c.name);
const sunOrder = sunKids();
check("a card gets a background, the plant picture and a border", ["gtPacketBack", "gtPacket", "gtPacketFront"].every((n) => sunOrder.includes(n)));
const cardPics = sunHolder.children.filter((c) => /^gtPacket/.test(c.name) && c.isValid !== false);
check("the background goes just above the game's, the border just above the plant", cardPics.find((c) => c.name === "gtPacketBack").sibling === 1 && cardPics.find((c) => c.name === "gtPacketFront").sibling === sunHolder.children.indexOf(cardPics.find((c) => c.name === "gtPacket")) + 1);
check("all three the same size and place", new Set(cardPics.map((c) => `${c.position.x},${c.position.y},${c.scaleX}`)).size === 1);
check("the game's background and sun plate are switched off, the family icon isn't", !bgArm.enabled && !plateArm.enabled && familyArm.enabled && !sunDB.enabled);
sunCard.Type = "peashooter";
sunCard.cardGrouperPlant();
check("rebuilt as another plant, the card gets its own parts back", bgArm.enabled && plateArm.enabled && !sunHolder.children.some((c) => c.name === "gtPacketBack" && c.isValid !== false));
// Designs keep in textures/saved, like animations.
inP("Saved").onclick(ev({}));
await new Promise((r) => setTimeout(r, 30));
check("Saved lists packet designs", allNodes(pwin).some((n) => n.textContent === "Saved packet designs"));
inP("Save design").onclick(ev({}));
await new Promise((r) => setTimeout(r, 40));
check("Save design keeps it as a file", files.has(`${own}/saved/sunflower_packet.packetdesign.json`) && allNodes(pwin).some((n) => /^Saved "Sunflower packet"/.test(n.textContent ?? "")));
check("listed to open again", allNodes(pwin).some((n) => n.tag === "button" && n.textContent === "Open"));
inP("Back to editing").onclick(ev({}));
inP("Close").onclick(ev({}));
api.packetEditor("sunflower", "Sunflower");
await new Promise((r) => setTimeout(r, 20));
const pwin2 = uiNodes.filter((n) => n.tabIndex === 0).at(-1);
check("opening it again brings the layers back", allNodes(pwin2).some((n) => n.textContent === "Your layers from last time."));
allNodes(pwin2).find((n) => n.tag === "button" && n.textContent === "Close").onclick(ev({}));
document.createElement = realCreate;

const errors = logs.filter(([k, m]) => k === "error" && !m.includes("nothing on the lawn is using it") && !m.includes("cached atlas"));
// Where new art goes: into the pack that adds the plant, or else into
// the home pack, never into this pack, which gets replaced on update.
putFile("gp-next/packs/SomeonesPlants/pack.json", text({ uuid: "someone-1" }));
putFile("gp-next/packs/SomeonesPlants/jsons/objects/PlantTypes.json", text({ version: 1, objects: [{ objclass: "PlantType", aliases: ["moonbloom"] }] }));
addDir("gp-next/packs/SomeonesPlants/textures");
const homeTex = "gp-next/packs/PlantPack/textures";
const topLevel = (dir) => [...files.keys()].filter((f) => f.startsWith(`${dir}/`) && !f.slice(dir.length + 1).includes("/"));
const ownBefore = topLevel(own).filter((f) => /\.(png|json)$/.test(f) && !files.has(`${homeTex}/${f.split("/").pop()}`));
// With two packs to pick from and "this pack" no longer picked, it waits to
// be told rather than guessing.
store.delete("greenhousetextures.option:homepack");
await api.reload();
check("with more than one pack to pick from, nothing is picked for you", api.folder().home === own && api.folder().choices.length === 2);
store.set("greenhousetextures.option:homepack", "plantpack-1");
await api.reload();
await new Promise((r) => setTimeout(r, 20));
check("art left in this pack's folder moves over to the home pack", ownBefore.length > 0 && ownBefore.every((f) => !files.has(f) && files.has(`${homeTex}/${f.split("/").pop()}`)));
check("and the saved animations with it", files.has(`${homeTex}/saved/sunny_sway.anim.json`) && !files.has(`${own}/saved/sunny_sway.anim.json`));
check("and it all still reads back", (await api.animations()).some((a) => a.name === "Sunny sway"));
await api.applyPacket("moonbloom", png);
await new Promise((r) => setTimeout(r, 20));
check("a modded plant's art goes into the pack that adds it", files.has("gp-next/packs/SomeonesPlants/textures/moonbloom.packet.png") && !files.has(`${homeTex}/moonbloom.packet.png`));
await api.applyPacket("peashooter", png);
await new Promise((r) => setTimeout(r, 20));
check("anything else goes into the home pack", files.has(`${homeTex}/peashooter.packet.png`) && !files.has(`${own}/peashooter.packet.png`));
api.packetScale("moonbloom", 1.5);
await new Promise((r) => setTimeout(r, 450));
const moonLooks = JSON.parse(new TextDecoder().decode(files.get("gp-next/packs/SomeonesPlants/textures/looks.json") ?? text("{}")));
check("its sizes go in a looks.json beside its art", moonLooks.moonbloom?.packetScale === 1.5);
const homeLooks = JSON.parse(new TextDecoder().decode(files.get(`${homeTex}/looks.json`) ?? text("{}")));
check("and not in the home pack's one", !homeLooks.moonbloom);
// A plant pack with no textures folder: the file plugin can't make one, so
// its art lands in the home pack instead of falling back to localStorage.
putFile("gp-next/packs/NoFolder/pack.json", text({ uuid: "nofolder-1" }));
putFile("gp-next/packs/NoFolder/jsons/objects/PlantTypes.json", text({ version: 1, objects: [{ objclass: "PlantType", aliases: ["dustcap"] }] }));
await api.reload();
const mkdirWas = globalThis.__TAURI_INTERNALS__.invoke;
globalThis.__TAURI_INTERNALS__.invoke = async (cmd, args, opts) => {
  if (cmd.endsWith("|mkdir")) throw new Error("not allowed: mkdir");
  return mkdirWas(cmd, args, opts);
};
await api.applyPacket("dustcap", png);
await new Promise((r) => setTimeout(r, 30));
check("a plant pack with no textures folder gets its art kept in the home pack", files.has(`${homeTex}/dustcap.packet.png`) && !store.has("greenhousetextures.packet:dustcap"));
check("and one failed folder doesn't send everything else to localStorage", api.folder().writable !== false);
globalThis.__TAURI_INTERNALS__.invoke = mkdirWas;
const homeSave = await api.saveAnimation({ name: "Moon wave", codename: "moonbloom", label: "Moonbloom", layout: [{ id: "p1", box: { x: 0, y: 0, width: 4, height: 4 } }], options: {}, sheet: png });
check("saved animations go to the home pack", homeSave.where === "PlantPack/textures/saved/moon_wave.anim.json" && files.has(`${homeTex}/saved/moon_wave.anim.json`));
check("and the console says where", api.folder().home === homeTex && api.folder().plants.moonbloom === "gp-next/packs/SomeonesPlants/textures");
check(`no unexpected errors (${errors.length})`, errors.length === 0);
for (const [, m] of errors) console.log("   log:", m);

// ---- a build whose getCc() is missing classes ----
// A Mac player's had no UIOpacity and no dragonBones on it. The still image
// then switched the armature off (no events, no attacks), and the rig never
// went on at all, with nothing in the log to say why.
const bareCc = { ...cc };
delete bareCc.UIOpacity;
delete bareCc.dragonBones;
e.unsafe.engine.getCc = () => bareCc;
const logsBefore = logs.length;
const second = await import(`file://${file}?bare`);
(second.default ?? second.setup ?? globalThis.setup)(e);
const bare = globalThis.GreenhouseTextures;
const bareBody = (plant) => {
  const body = plant.db.node;
  body._uiProps = { localOpacity: 1 };
  return body;
};
const lone = makePlant(9, sunflowerSheet);
const loneBody = bareBody(lone);
pool.length = 0;
pool.push(lone);
await bare.apply("still:sunflower", png);
check("with no UIOpacity a still leaves the armature switched on", !!lone.__gtStill && loneBody.active !== false);
check("and hides it by its opacity instead", loneBody._uiProps.localOpacity < 0.01);
bare.undo("still:sunflower");
check("and shows it again after", loneBody._uiProps.localOpacity === 1);
const rigPlant = makePlant(9, sunflowerSheet);
const realDb = Object.assign(new ArmatureDisplay(), rigPlant.db);
rigPlant.db = realDb;
rigPlant.anmControl.db = realDb;
rigPlant.anmControl._db = realDb;
bareBody(rigPlant);
pool.push(rigPlant);
const bareRigged = await bare.applyRig("sunflower", layout, png, { width: 128, height: 128 });
check("with no dragonBones on getCc the rig still goes on the plant's own armature",
  bareRigged >= 1 && JSON.parse(rigPlant.db.dragonAsset?._dragonBonesJson ?? "{}").armature?.[0]?.name === "gt_sunflower");

process.exit(fails.length ? 1 : 0);
