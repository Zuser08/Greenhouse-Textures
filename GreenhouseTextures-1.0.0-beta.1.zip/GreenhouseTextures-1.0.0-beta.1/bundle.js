// Greenhouse Textures -- GP-Next JS mod (experimental.jsModding).
//
// Custom art for a game whose pack format has no room for any. GP-Next
// datapacks are JSON only, and there is no file API to read a PNG off disk.
// What there is: Cocos running inside Electron, so a browser sits under the
// game. The game leans on that itself, and its custom-music feature is the
// proof -- it builds an <input type="file">, reads it, and hands the result
// to the asset manager. A file picker, a canvas and localStorage are all this
// needs.
//
// Finding the art is the other half. Cocos ships native assets under uuid
// filenames, so nothing in the asset cache is called "GatlingPea" and hunting
// by name finds nothing. Plants on the lawn know better: every plant carries
// `db`, its DragonBones display, and that holds the atlas it draws from. So
// the list is built from the plants standing in front of you.
//

function setup(e) {
  const VERSION = `1.0.0-beta.1`;
  e.log.info(`[Textures] ${VERSION} loaded, waiting for the engine.`);
  const boot = () => {
    const getModule = (name) => {
      try {
        return e.unsafe.engine.getSystemModule(`chunks:///_virtual/${name}.ts`);
      } catch (err) {
        return null;
      }
    };
    const cc = e.unsafe.engine.getCc();
    // getCc() doesn't carry every engine class on every build: a Mac player
    // had no UIOpacity and no dragonBones on it. The class registry does.
    const engineClass = (name) => {
      for (const find of [
        () => e.unsafe.engine.getClassByName?.(name),
        () => cc?.js?.getClassByName?.(name),
      ]) {
        try {
          const found = find();
          if (found) return found;
        } catch (err) { /* next way */ }
      }
      return null;
    };
    const doc = typeof document !== `undefined` ? document : null;
    if (!doc) {
      e.log.info(`[Textures] No DOM here, so custom textures are off.`);
      return;
    }
    if (!cc?.assetManager) {
      e.log.error(`[Textures] No assetManager -- custom textures are off.`);
      return;
    }

    const plantRegistry = () => getModule(`Plants`)?.plants;
    const PlantPool = getModule(`CharacterManager`)?.PlantPool;
    const Square = getModule(`Square`)?.Square;
    const STORE = `greenhousetextures.`;
    const RECHECK_MS = 2000;

    // Anything this mod does to a live texture can take the renderer with it
    // if the engine dislikes it, and a frozen game can't be clicked out of.
    // So: one failure stops all of it until asked again, nothing is touched
    // outside a running level, and Ctrl+Shift+X wipes the lot.
    let stopped = false;
    const halt = (why) => {
      if (stopped) return;
      stopped = true;
      e.log.error(`[Textures] Stopped putting textures back: ${why}. Nothing else will be touched this session. GreenhouseTextures.clear() forgets every override, GreenhouseTextures.retry() tries again.`);
    };
    const inLevel = () => {
      try {
        return !!Square?.getLnC?.(0, 0);
      } catch (err) {
        return false;
      }
    };

    // ==================================================================
    // Finding art
    // ==================================================================

    // Everything a plant draws itself with. The atlas behind its DragonBones
    // display is the one that matters; a texture can arrive as a SpriteFrame,
    // so unwrap that too.
    const textureIn = (thing) => {
      const tex = thing?._texture ?? thing?.texture ?? thing;
      if (!tex || typeof tex !== `object`) return null;
      const inner = tex._texture ?? tex.texture;
      const candidate = inner && typeof inner === `object` && typeof inner.width === `number` ? inner : tex;
      return typeof candidate.width === `number` ? candidate : null;
    };

    const atlasOf = (plant) => {
      const db = plant?.db ?? plant?.anmControl?.db;
      if (!db) return null;
      return db.dragonAtlasAsset ?? db._dragonAtlasAsset ?? db.dragonAtlas ?? null;
    };

    const texturesOfPlant = (plant) => {
      const out = [];
      const seen = new Set();
      const add = (thing, where) => {
        const tex = textureIn(thing);
        if (!tex || seen.has(tex)) return;
        seen.add(tex);
        out.push({ tex, where });
      };
      try {
        add(atlasOf(plant), `armature`);
        const db = plant?.db ?? plant?.anmControl?.db;
        add(db?.texture, `display`);
        for (const child of plant?.node?.children ?? []) {
          for (const comp of child?.components ?? []) {
            add(comp?.spriteFrame, `sprite`);
            add(comp?.dragonAtlasAsset, `armature`);
          }
        }
      } catch (err) { /* half-built plant */ }
      return out;
    };

    // A pack plant borrows a vanilla plant's art, which is the whole reason
    // the two routes exist. Pack ids start well above the vanilla range, and
    // a plant whose props carry a key the game never defines is modded too.
    const MODDED_ID_FROM = 900000;
    const isModded = (plant, feature) => {
      if (typeof plant?.ID === `number` && plant.ID >= MODDED_ID_FROM) return true;
      try {
        return !!feature?._CARDSPRITENAME && feature._CARDSPRITENAME !== feature.CODENAME;
      } catch (err) {
        return false;
      }
    };

    const nameOfPlant = (plant) => {
      try {
        const feature = plantRegistry()?.getPlantFeature?.(plant.ID);
        return {
          codename: feature?.CODENAME ?? `plant${plant.ID}`,
          label: feature?.NAME?.en ?? feature?.CODENAME ?? `Plant ${plant.ID}`,
          modded: isModded(plant, feature),
        };
      } catch (err) {
        return { codename: `plant${plant?.ID}`, label: `Plant ${plant?.ID}`, modded: false };
      }
    };

    // One row per kind of plant on the lawn, not per plant.
    const plantRows = () => {
      let pool = [];
      try {
        pool = PlantPool?.pool?.() ?? [];
      } catch (err) {
        pool = [];
      }
      const rows = new Map();
      for (const plant of pool) {
        if (!plant || plant.dead) continue;
        const { codename, label, modded } = nameOfPlant(plant);
        const found = texturesOfPlant(plant);
        if (!found.length) continue;
        const row = rows.get(codename) ?? { codename, label, modded, plants: [], textures: [] };
        row.plants.push(plant);
        for (const entry of found) {
          if (!row.textures.some((t) => t.tex === entry.tex)) row.textures.push(entry);
        }
        rows.set(codename, row);
      }
      return [...rows.values()].sort((a, b) => (Number(b.modded) - Number(a.modded)) || a.label.localeCompare(b.label));
    };

    const isTexture = (asset) => {
      try {
        return !!asset && (asset instanceof cc.Texture2D
          || asset?.constructor?.name === `Texture2D`
          || (typeof asset.uploadData === `function` && typeof asset.width === `number`));
      } catch (err) {
        return false;
      }
    };

    // Which plants draw from the same sheet, split by whether they are modded.
    // "Every user" repaints for all of them, so the vanilla ones are the part
    // worth warning about.
    const sharersOf = (tex) => {
      const out = { modded: [], vanilla: [] };
      for (const row of plantRows()) {
        if (!row.textures.some((t) => t.tex === tex)) continue;
        (row.modded ? out.modded : out.vanilla).push(row.label);
      }
      return out;
    };

    // Every texture the game has loaded. Names here are uuids, so each one is
    // labelled with the plant using it wherever that can be worked out.
    const allTextures = () => {
      const byTexture = new Map();
      for (const row of plantRows()) {
        for (const entry of row.textures) {
          const users = byTexture.get(entry.tex) ?? [];
          users.push(row.label);
          byTexture.set(entry.tex, users);
        }
      }
      const out = [];
      try {
        cc.assetManager.assets.forEach((asset, uuid) => {
          if (!isTexture(asset)) return;
          out.push({ uuid, tex: asset, users: byTexture.get(asset) ?? [] });
        });
      } catch (err) {
        e.log.error(`[Textures] Couldn't read the asset cache: ${err.message}`);
      }
      return out.sort((a, b) => (b.users.length - a.users.length) || (b.tex.width - a.tex.width));
    };

    const uuidOf = (tex) => {
      for (const key of [`_uuid`, `uuid`]) {
        const value = tex?.[key];
        if (typeof value === `string` && value) return value;
      }
      let found = null;
      try {
        cc.assetManager.assets.forEach((asset, uuid) => {
          if (!found && asset === tex) found = uuid;
        });
      } catch (err) { /* no cache */ }
      return found ?? `tex-${tex?.width}x${tex?.height}`;
    };

    // ==================================================================
    // Putting a picture on something
    // ==================================================================

    const imageFrom = (dataUrl) => new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        try {
          resolve(new cc.ImageAsset(img));
        } catch (err) {
          try {
            resolve(new cc.ImageAsset({ _data: img, width: img.width, height: img.height, _compressed: false }));
          } catch (err2) {
            reject(err2);
          }
        }
      };
      img.onerror = () => reject(new Error(`that file isn't an image this build can read`));
      img.src = dataUrl;
    });

    const textureFrom = (imageAsset) => {
      const tex = new cc.Texture2D();
      tex.image = imageAsset;
      return tex;
    };

    // A sheet has to keep the size of the one it replaces. The armature's
    // slots are coordinates into the old layout, and handing the engine a
    // differently sized image mid-level is the fastest way to a frozen game.
    // So anything the wrong size is redrawn onto a canvas of the right one.
    const fitTo = (dataUrl, width, height) => new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        if (img.width === width && img.height === height) {
          resolve(dataUrl);
          return;
        }
        try {
          const canvas = doc.createElement(`canvas`);
          canvas.width = width;
          canvas.height = height;
          canvas.getContext(`2d`).drawImage(img, 0, 0, width, height);
          e.log.info(`[Textures] The import was ${img.width}x${img.height} and the sheet is ${width}x${height}, so it was scaled to fit.`);
          resolve(canvas.toDataURL(`image/png`));
        } catch (err) {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });

    // Repaint a texture the game already has. Everything drawing from it
    // changes at once, which is the point and also the catch.
    const repaint = (tex, imageAsset) => {
      try {
        tex.image = imageAsset;
        return `repainted`;
      } catch (err) { /* try the long way */ }
      try {
        tex.reset({ width: imageAsset.width, height: imageAsset.height, format: tex.format });
        tex.uploadData(imageAsset.data ?? imageAsset._data);
        return `uploaded`;
      } catch (err) {
        e.log.error(`[Textures] Couldn't repaint: ${err.message}`);
        return null;
      }
    };

    // Give one plant its own art and leave everything else alone: its own
    // armature gets a copy of its atlas pointing at the new sheet.
    const dressPlant = (plant, tex) => {
      const db = plant?.db ?? plant?.anmControl?.db;
      if (!db) return null;
      const source = atlasOf(plant);
      const made = sharedAssets(tex, `sheet:${source ? idOf(source) : 0}:${db.dragonAsset ? idOf(db.dragonAsset) : 0}`,
        () => ({ ske: db.dragonAsset, atlas: newAtlas(source, null, tex) }));
      if (!made?.atlas) return null;
      if (!wearOn(plant, { atlas: made.atlas })) return null;
      return textureIn(atlasOf(plant)) === tex ? `atlas` : `atlas (not confirmed)`;
    };

    // ==================================================================
    // What the player has chosen
    // ==================================================================

    // ==================================================================
    // Where the art lives
    //
    // Two places. Files in a textures folder inside a pack:
    //
    //   packs/SomePlantMod/textures/sunflower.still.png
    //
    // and localStorage, which is only the fallback now: it holds about 5MB
    // and lives in one browser profile. The game is a Tauri app whose file
    // plugin may read and write inside its own app data folder, and that is
    // where gp-next/packs is, so the mod reads every pack's textures folder
    // at startup.
    //
    // New art is written where it will travel with the plant: into the pack
    // that adds that plant (its PlantTypes.json lists it), so a mod maker's
    // animations ship with their mod. Anything else goes to the home pack:
    // the one the player picks in the panel, or, with none picked and only
    // one other pack that has a textures folder, that one. This pack's own
    // folder is the last resort, since installing a new version of it
    // replaces the folder and whatever is in it.
    //
    // Everything below asks stored(key) and never cares which place a value
    // came from. localStorage wins over a file, because anything still in
    // there is newer than the folder: it was saved when the folder couldn't
    // be written.
    // ==================================================================
    let savedCache = null; // localStorage, read once and kept in step
    const packValues = new Map(); // key -> value, from the textures folders
    const packSource = new Map(); // key -> { path, own }
    const loadLocal = () => {
      if (savedCache) return;
      savedCache = {};
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key?.startsWith(STORE)) savedCache[key.slice(STORE.length)] = localStorage.getItem(key);
        }
      } catch (err) { /* no storage, nothing persists */ }
    };
    // A file from some other pack can't be deleted from here, so taking it
    // off leaves a marker in localStorage instead.
    const OFF = `off:`;
    const isOff = (key) => savedCache?.[OFF + key] === `1`;
    const saved = () => {
      loadLocal();
      const out = {};
      for (const [key, value] of packValues) if (!isOff(key)) out[key] = value;
      for (const [key, value] of Object.entries(savedCache)) if (!key.startsWith(OFF)) out[key] = value;
      return out;
    };
    const stored = (key) => {
      loadLocal();
      if (key in savedCache) return savedCache[key];
      if (isOff(key)) return null;
      return packValues.get(key) ?? null;
    };
    const setLocal = (key, value) => {
      loadLocal();
      localStorage.setItem(STORE + key, value);
      savedCache[key] = value;
    };
    const dropLocal = (key) => {
      loadLocal();
      try {
        localStorage.removeItem(STORE + key);
      } catch (err) { /* nothing there */ }
      delete savedCache[key];
    };

    // ---- the folder ----
    const tauri = globalThis.__TAURI_INTERNALS__;
    const APP_DATA = 14; // BaseDirectory.AppData: Roaming/com.pvzge.game
    const PACKS = `gp-next/packs`;
    const OWN_UUID = `0ebee2cb-a35f-406f-ae13-6297940d59a0`;
    // scope <-> file name. Sizes and nudges share one looks.json.
    const FILE_KINDS = [
      [`still`, `still.png`], [`packet`, `packet.png`], [`plant`, `sheet.png`],
      [`fitart`, `fit.png`], [`fit`, `fit.json`], [`rigart`, `rig.png`], [`rig`, `rig.json`], [`packetproj`, `packet.json`],
      [`packetback`, `packetback.png`], [`packetfront`, `packetfront.png`],
    ];
    const LOOK_KINDS = { stillscale: `stillScale`, packetscale: `packetScale`, stilloffset: `stillOffset`, packetoffset: `packetOffset` };
    const LOOKS = `looks.json`;
    let ownFolder = null; // gp-next/packs/<this pack>/textures
    let homeFolder = null; // the home pack's textures folder
    const plantHomes = new Map(); // codename -> textures folder of the pack that adds it
    let homeChoices = []; // packs with a textures folder: { uuid, name, folder }
    let folderWritable = null; // null until a write has been tried
    let folderNote = `not read yet`;
    // Where new art for a key goes, and where saved animations go.
    const mainHome = () => homeFolder ?? ownFolder;
    const homeFor = (key) => plantHomes.get(String(key).split(`:`)[1] ?? ``) ?? mainHome();
    const isHome = (folder) => !!folder && (folder === ownFolder || folder === homeFolder || [...plantHomes.values()].includes(folder));
    const packNameOf = (folder) => String(folder ?? ``).split(`/`).slice(-2, -1)[0] ?? `?`;

    const fileNameOf = (key) => {
      const [scope, codename] = key.split(`:`);
      const kind = FILE_KINDS.find(([s]) => s === scope);
      return kind && codename ? `${codename}.${kind[1]}` : null;
    };
    const inFolder = (key) => !!fileNameOf(key) || (key.split(`:`)[0] in LOOK_KINDS);

    const fsCall = (cmd, args, options) => tauri.invoke(`plugin:fs|${cmd}`, args, options);
    const at = { baseDir: APP_DATA };
    const readDir = (path) => fsCall(`read_dir`, { path, options: at });
    const readBytes = async (path) => {
      const out = await fsCall(`read_file`, { path, options: at });
      return out instanceof ArrayBuffer ? new Uint8Array(out) : Uint8Array.from(out ?? []);
    };
    const readText = async (path) => new TextDecoder().decode(await readBytes(path));
    // Newer builds of the plugin take the bytes as the raw request body,
    // older ones as a number array. Whichever this build refuses, try the
    // other.
    const writeBytes = async (path, bytes) => {
      try {
        return await fsCall(`write_file`, bytes, { headers: { path: encodeURIComponent(path), options: JSON.stringify(at) } });
      } catch (err) {
        return fsCall(`write_file`, { path, data: Array.from(bytes), options: at });
      }
    };
    const moveFile = (from, to) => fsCall(`rename`, { oldPath: from, newPath: to, options: { oldPathBaseDir: APP_DATA, newPathBaseDir: APP_DATA } });
    // A pack zip may come without a textures folder. If the file plugin
    // won't make one, the write that follows says so.
    const madeDirs = new Set();
    const ensureDir = async (path) => {
      if (madeDirs.has(path)) return;
      try {
        await fsCall(`mkdir`, { path, options: { ...at, recursive: true } });
      } catch (err) { /* there already, or not allowed */ }
      madeDirs.add(path);
    };
    const writeInto = async (path, bytes) => {
      await ensureDir(path.slice(0, path.lastIndexOf(`/`)));
      return writeBytes(path, bytes);
    };

    const toDataUrl = (bytes, type) => {
      let binary = ``;
      for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      return `data:${type};base64,${btoa(binary)}`;
    };
    const fromDataUrl = (url) => {
      const comma = url.indexOf(`,`);
      const head = url.slice(0, comma);
      const body = url.slice(comma + 1);
      if (!head.includes(`;base64`)) return new TextEncoder().encode(decodeURIComponent(body));
      const binary = atob(body);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return bytes;
    };

    // Every pack's textures folder. Where the same file is in more than
    // one, the plant's own pack wins, then the home pack, then this pack,
    // then the rest by name.
    const readFolders = async () => {
      if (typeof tauri?.invoke !== `function`) {
        folderNote = `no file access here (not the desktop app), so everything is in localStorage`;
        return 0;
      }
      let dirs = [];
      try {
        dirs = (await readDir(PACKS)).filter((d) => d.isDirectory).map((d) => d.name);
      } catch (err) {
        folderNote = `couldn't list the packs folder (${err?.message ?? err})`;
        return 0;
      }
      ownFolder = null;
      homeFolder = null;
      plantHomes.clear();
      const packs = [];
      for (const dir of dirs) {
        let uuid = null;
        let name = dir;
        try {
          const info = JSON.parse(await readText(`${PACKS}/${dir}/pack.json`));
          uuid = info?.uuid ?? null;
          name = String(info?.name ?? dir);
        } catch (err) { /* not a pack, or no pack.json */ }
        const folder = `${PACKS}/${dir}/textures`;
        if (uuid === OWN_UUID) ownFolder = folder;
        // The plants a pack adds, so their art is written into it.
        if (uuid !== OWN_UUID) {
          try {
            const types = JSON.parse(await readText(`${PACKS}/${dir}/jsons/objects/PlantTypes.json`));
            for (const obj of types?.objects ?? []) {
              for (const alias of obj?.aliases ?? []) if (alias) plantHomes.set(String(alias).toLowerCase(), folder);
            }
          } catch (err) { /* adds no plants, or not as a PlantTypes file */ }
        }
        packs.push({ dir, folder, uuid, name });
      }
      const found = [];
      for (const pack of packs) {
        try {
          found.push({ ...pack, entries: await readDir(pack.folder) });
        } catch (err) { /* no textures folder */ }
      }
      // The home pack: the one picked, or the only candidate.
      homeChoices = found.filter((p) => p.uuid && p.uuid !== OWN_UUID).map(({ uuid, name, folder }) => ({ uuid, name, folder }));
      const picked = stored(`option:homepack`);
      const chosen = homeChoices.find((p) => p.uuid === picked);
      if (chosen) homeFolder = chosen.folder;
      else if (picked !== OWN_UUID && homeChoices.length === 1) homeFolder = homeChoices[0].folder;
      const rank = (folder, key) => (folder === homeFor(key) ? 3 : folder === homeFolder ? 2 : folder === ownFolder ? 1 : 0);
      found.sort((x, y) => x.dir.localeCompare(y.dir));
      packValues.clear();
      packSource.clear();
      const take = (key, value, path, folder) => {
        const had = packSource.get(key);
        if (had && rank(had.folder, key) > rank(folder, key)) return;
        packValues.set(key, value);
        packSource.set(key, { path, folder, own: isHome(folder) });
      };
      let files = 0;
      for (const { folder, entries } of found) {
        for (const entry of entries) {
          if (entry.isDirectory || !entry.name) continue;
          const name = entry.name;
          const path = `${folder}/${name}`;
          try {
            if (name.toLowerCase() === LOOKS) {
              const looks = JSON.parse(await readText(path));
              for (const [codename, look] of Object.entries(looks ?? {})) {
                for (const [scope, field] of Object.entries(LOOK_KINDS)) {
                  const value = look?.[field];
                  if (value === undefined) continue;
                  take(`${scope}:${codename.toLowerCase()}`, Array.isArray(value) ? `${value[0] ?? 0},${value[1] ?? 0}` : String(value), path, folder);
                }
              }
              files++;
              continue;
            }
            const match = /^(.+)\.([a-z]+\.(?:png|json))$/i.exec(name);
            const kind = match && FILE_KINDS.find(([, suffix]) => suffix === match[2].toLowerCase());
            if (!kind) continue;
            const value = name.toLowerCase().endsWith(`.png`)
              ? toDataUrl(await readBytes(path), `image/png`)
              : JSON.stringify(JSON.parse(await readText(path)));
            take(`${kind[0]}:${match[1].toLowerCase()}`, value, path, folder);
            files++;
          } catch (err) {
            e.log.error(`[Textures] Skipped ${path}: ${err?.message ?? err}`);
          }
        }
      }
      const home = mainHome();
      folderNote = `${files} file(s) from ${found.length} textures folder(s); new art goes to `
        + (home ? `${packNameOf(home)}/textures` : `localStorage, since no textures folder was found`)
        + (plantHomes.size ? `, or to the pack that adds the plant` : ``);
      return files;
    };
    // Art in this pack's folder goes over to the home pack once there is
    // one, where it's safe from this pack being replaced.
    const adoptOld = async () => {
      if (!homeFolder || !ownFolder || homeFolder === ownFolder) return 0;
      let moved = 0;
      for (const sub of [``, `/${SAVED}`]) {
        let entries = [];
        try {
          entries = await readDir(`${ownFolder}${sub}`);
        } catch (err) {
          continue;
        }
        let there = new Set();
        try {
          there = new Set((await readDir(`${homeFolder}${sub}`)).map((x) => x.name));
        } catch (err) { /* not made yet */ }
        for (const entry of entries) {
          const name = entry.name ?? ``;
          if (entry.isDirectory || !/\.(png|json)$/i.test(name) || there.has(name)) continue;
          try {
            await ensureDir(`${homeFolder}${sub}`);
            await moveFile(`${ownFolder}${sub}/${name}`, `${homeFolder}${sub}/${name}`);
            moved++;
          } catch (err) {
            e.log.error(`[Textures] Couldn't move ${name} into ${packNameOf(homeFolder)}: ${err?.message ?? err}. It's still read from where it is.`);
          }
        }
      }
      if (moved) e.log.info(`[Textures] Moved ${moved} file(s) from this pack's folder into ${packNameOf(homeFolder)}/textures.`);
      return moved;
    };
    const readAll = async () => {
      const files = await readFolders();
      return (await adoptOld()) ? readFolders() : files;
    };

    // Sizes and nudges, one file per folder for the plants that live there,
    // rewritten whole on each change.
    const looksJson = (folder = mainHome()) => {
      const out = {};
      for (const [key, value] of Object.entries(saved())) {
        const [scope, codename] = key.split(`:`);
        const field = LOOK_KINDS[scope];
        if (!field || !codename || homeFor(key) !== folder) continue;
        const look = out[codename] ?? (out[codename] = {});
        if (scope.endsWith(`offset`)) {
          const [x, y] = String(value).split(`,`).map(Number);
          look[field] = [x || 0, y || 0];
        } else {
          look[field] = Number(value);
        }
      }
      return `${JSON.stringify(out, null, 2)}\n`;
    };

    const folderFailed = (key, value, err) => {
      if (folderWritable !== false) {
        e.log.error(`[Textures] Couldn't write into the mod's textures folder (${err?.message ?? err}). Saving to localStorage instead.`);
      }
      folderWritable = false;
      try {
        setLocal(key, value);
      } catch (err2) {
        e.log.error(`[Textures] Couldn't save ${key} anywhere: ${err2.message}`);
      }
    };
    let looksTimer = null;
    const looksDue = new Map(); // folder -> the last key changed there
    const writeToFolder = (key, value) => {
      const folder = homeFor(key);
      const name = fileNameOf(key);
      if (name) {
        const bytes = String(value).startsWith(`data:`) ? fromDataUrl(value) : new TextEncoder().encode(String(value));
        const put = (where) => writeInto(`${where}/${name}`, bytes).then(() => {
          folderWritable = true;
          packSource.set(key, { path: `${where}/${name}`, folder: where, own: true });
        });
        // A plant's own pack may ship without a textures folder, and the
        // file plugin can't make one: then it goes to the home pack.
        return put(folder)
          .catch((err) => {
            if (folder === mainHome() || !mainHome()) throw err;
            plantHomes.delete(String(key).split(`:`)[1]);
            return put(mainHome());
          })
          .catch((err) => folderFailed(key, value, err));
      }
      // Sizes: one file a folder, written a moment after the last change so
      // dragging a slider isn't a write per step.
      looksDue.set(folder, [key, value]);
      clearTimeout(looksTimer);
      looksTimer = setTimeout(() => {
        const due = [...looksDue];
        looksDue.clear();
        for (const [where, [lastKey, lastValue]] of due) {
          writeInto(`${where}/${LOOKS}`, new TextEncoder().encode(looksJson(where)))
            .then(() => {
              folderWritable = true;
            })
            .catch((err) => {
              if (where === mainHome() || !mainHome()) throw err;
              for (const [codename, home] of [...plantHomes]) if (home === where) plantHomes.delete(codename);
              return writeInto(`${mainHome()}/${LOOKS}`, new TextEncoder().encode(looksJson(mainHome())));
            })
            .catch((err) => folderFailed(lastKey, lastValue, err));
        }
      }, 400);
      return Promise.resolve();
    };

    // Filled in further down, once there is something to tell.
    let onStored = () => {};
    const remember = (key, value) => {
      loadLocal();
      delete savedCache[OFF + key];
      try {
        localStorage.removeItem(STORE + OFF + key);
      } catch (err) { /* nothing there */ }
      if (homeFor(key) && folderWritable !== false && inFolder(key)) {
        packValues.set(key, value);
        dropLocal(key);
        writeToFolder(key, value);
        onStored(key);
        return true;
      }
      try {
        setLocal(key, value);
        onStored(key);
        return true;
      } catch (err) {
        e.log.error(`[Textures] Applied, but too big to save (${err.message}). localStorage holds about 5MB; the mod's textures folder has no such limit.`);
        return false;
      }
    };
    // A file this pack wrote is moved into textures/removed rather than
    // deleted: it may be the only copy of someone's art. One from another
    // pack is left alone and switched off here instead.
    const forget = (key) => {
      loadLocal();
      const had = key in savedCache || packValues.has(key);
      dropLocal(key);
      const source = packSource.get(key);
      if (packValues.has(key)) {
        packValues.delete(key);
        packSource.delete(key);
        if (source?.own && fileNameOf(key)) {
          const name = source.path.split(`/`).pop();
          const folder = source.path.slice(0, source.path.lastIndexOf(`/`));
          ensureDir(`${folder}/removed`)
            .then(() => moveFile(source.path, `${folder}/removed/${name}`))
            .catch(() => moveFile(source.path, `${source.path}.removed`))
            .catch((err) => e.log.error(`[Textures] Couldn't move ${name} out of the textures folder: ${err?.message ?? err}. It comes back at the next restart.`));
        } else if (source?.own) {
          writeToFolder(key, ``);
        } else if (source) {
          try {
            setLocal(OFF + key, `1`);
          } catch (err) { /* it comes back at the next restart */ }
        }
      }
      if (had) onStored(key);
    };

    // Everything in localStorage that has a place in the folder, moved there.
    const moveToFolder = async () => {
      loadLocal();
      if (!mainHome()) {
        e.log.error(`[Textures] No textures folder to move into (${folderNote}).`);
        return 0;
      }
      let moved = 0;
      const looks = [];
      for (const [key, value] of Object.entries(savedCache)) {
        if (key.startsWith(OFF) || !inFolder(key)) continue;
        if (!fileNameOf(key)) {
          looks.push([key, value]);
          continue;
        }
        const folder = homeFor(key);
        const path = `${folder}/${fileNameOf(key)}`;
        try {
          await writeInto(path, String(value).startsWith(`data:`) ? fromDataUrl(value) : new TextEncoder().encode(String(value)));
        } catch (err) {
          e.log.error(`[Textures] Couldn't write ${fileNameOf(key)}: ${err?.message ?? err}. It stays in localStorage.`);
          folderWritable = false;
          continue;
        }
        packValues.set(key, value);
        packSource.set(key, { path, folder, own: true });
        dropLocal(key);
        moved++;
      }
      if (looks.length) {
        // looks.json is built from everything stored, local included, so it
        // is written first and the local copies dropped only once it lands.
        try {
          const folders = new Set(looks.map(([key]) => homeFor(key)));
          for (const folder of folders) await writeInto(`${folder}/${LOOKS}`, new TextEncoder().encode(looksJson(folder)));
          for (const [key, value] of looks) {
            packValues.set(key, value);
            packSource.set(key, { path: `${homeFor(key)}/${LOOKS}`, folder: homeFor(key), own: true });
            dropLocal(key);
            moved++;
          }
        } catch (err) {
          e.log.error(`[Textures] Couldn't write ${LOOKS}: ${err?.message ?? err}. Sizes stay in localStorage.`);
        }
      }
      if (moved) folderWritable = true;
      e.log.info(`[Textures] Moved ${moved} item(s) from localStorage into ${packNameOf(mainHome())}/textures.`);
      return moved;
    };

    // ==================================================================
    // Saved animations
    //
    // A plant has one rig slot: build again, or take the rig off, and what
    // was there is gone. These live apart from that slot, one file each in
    // textures/saved (localStorage when the folder can't be written), and
    // nothing in the game removes them.
    // ==================================================================
    const SAVED = `saved`;
    const ANIM_LOCAL = `anim:`;
    const animSlug = (text) => slug(text, `animation`);
    const saveAnimation = async ({ name, codename, label, layout, options, sheet }) => {
      const record = {
        kind: `greenhouse-animation`,
        version: 1,
        name: String(name ?? ``).trim() || label || codename,
        codename,
        label: label ?? codename,
        saved: new Date().toISOString(),
        layout,
        options,
        sheet,
      };
      const text = JSON.stringify(record);
      const file = `${animSlug(record.name)}.anim.json`;
      const home = mainHome();
      if (home && folderWritable !== false) {
        try {
          await writeInto(`${home}/${SAVED}/${file}`, new TextEncoder().encode(text));
          return { where: `${packNameOf(home)}/textures/${SAVED}/${file}`, record };
        } catch (err) { /* localStorage instead */ }
      }
      try {
        setLocal(ANIM_LOCAL + animSlug(record.name), text);
        return { where: `local storage`, record };
      } catch (err) {
        throw new Error(`there's no room left to save it (${err?.message ?? err})`);
      }
    };
    const listAnimations = async () => {
      const found = [];
      const folders = [...new Set([homeFolder, ownFolder, ...plantHomes.values()].filter(Boolean))];
      if (typeof tauri?.invoke === `function`) {
        for (const folder of folders) {
          try {
            for (const entry of await readDir(`${folder}/${SAVED}`)) {
              if (entry.isDirectory || !/\.anim\.json$/i.test(entry.name ?? ``)) continue;
              found.push({ path: `${folder}/${SAVED}/${entry.name}` });
            }
          } catch (err) { /* no saved folder there */ }
        }
      }
      loadLocal();
      for (const key of Object.keys(savedCache)) if (key.startsWith(ANIM_LOCAL)) found.push({ key });
      const read = await Promise.all(found.map(async (item) => {
        try {
          const record = JSON.parse(item.path ? await readText(item.path) : savedCache[item.key]);
          return record?.layout?.length && record.sheet ? { ...item, record } : null;
        } catch (err) {
          return null;
        }
      }));
      return read.filter(Boolean).sort((a, b) => String(b.record.saved).localeCompare(String(a.record.saved)));
    };
    // Packet designs are kept the same way: one file each in textures/saved
    // of the home pack, with every layer's picture inside, so a design
    // opens again on any plant and travels with that pack.
    const DESIGN_LOCAL = `design:`;
    const saveDesign = async ({ name, codename, label, layers, card }) => {
      const record = {
        kind: `greenhouse-packet`,
        version: 2,
        name: String(name ?? ``).trim() || label || codename,
        codename,
        label: label ?? codename,
        saved: new Date().toISOString(),
        layers,
        card,
      };
      const text = JSON.stringify(record);
      const file = `${slug(record.name, `packet`)}.packetdesign.json`;
      const home = mainHome();
      if (home && folderWritable !== false) {
        try {
          await writeInto(`${home}/${SAVED}/${file}`, new TextEncoder().encode(text));
          return { where: `${packNameOf(home)}/textures/${SAVED}/${file}`, record };
        } catch (err) { /* localStorage instead */ }
      }
      try {
        setLocal(DESIGN_LOCAL + slug(record.name, `packet`), text);
        return { where: `local storage`, record };
      } catch (err) {
        throw new Error(`there's no room left to save it (${err?.message ?? err})`);
      }
    };
    const listDesigns = async () => {
      const found = [];
      const folders = [...new Set([homeFolder, ownFolder, ...plantHomes.values()].filter(Boolean))];
      if (typeof tauri?.invoke === `function`) {
        for (const folder of folders) {
          try {
            for (const entry of await readDir(`${folder}/${SAVED}`)) {
              if (entry.isDirectory || !/\.packetdesign\.json$/i.test(entry.name ?? ``)) continue;
              found.push({ path: `${folder}/${SAVED}/${entry.name}` });
            }
          } catch (err) { /* no saved folder there */ }
        }
      }
      loadLocal();
      for (const key of Object.keys(savedCache)) if (key.startsWith(DESIGN_LOCAL)) found.push({ key });
      const read = await Promise.all(found.map(async (item) => {
        try {
          const record = JSON.parse(item.path ? await readText(item.path) : savedCache[item.key]);
          return Array.isArray(record?.layers) ? { ...item, record } : null;
        } catch (err) {
          return null;
        }
      }));
      return read.filter(Boolean).sort((a, b) => String(b.record.saved).localeCompare(String(a.record.saved)));
    };
    // A rig coming off is kept first, so taking it off can't lose it.
    const keptLately = new Map(); // codename -> ms
    const keepRig = (codename, why) => {
      const last = keptLately.get(codename) ?? 0;
      if (Date.now() - last < 5000) return;
      let choice = null;
      try {
        choice = JSON.parse(stored(`rig:${codename}`) ?? `null`);
      } catch (err) {
        choice = null;
      }
      const sheet = stored(`rigart:${codename}`);
      if (!choice?.layout?.length || !sheet) return;
      keptLately.set(codename, Date.now());
      const when = new Date().toISOString().slice(0, 16).replace(`T`, ` `);
      saveAnimation({ name: `${codename} ${why} ${when}`, codename, label: codename, layout: choice.layout, options: choice.options ?? {}, sheet })
        .then(({ where }) => e.log.info(`[Textures] ${codename}: its animation was kept in ${where} before it came off. Open it again from Saved in the animation maker.`))
        .catch((err) => e.log.error(`[Textures] ${codename}: couldn't keep a copy of its animation: ${err.message}`));
    };

    let routes = {};
    const stamped = new WeakSet();
    const sheetsDone = new Map(); // uuid -> the texture object it was put on
    // What was there before, so undo can put it back now rather than at the
    // next restart. A repaint throws the old image away otherwise.
    const originalImages = new Map(); // uuid -> the ImageAsset it had

    // scope `plant:<codename>` dresses that plant only; `sheet:<uuid>`
    // repaints the sheet for everything using it.
    const stillScales = new Map();
    const applyKey = (key, dataUrl) => {
      const [scope, id] = key.split(`:`);
      const target = scope === `sheet` ? allTextures().find((t) => t.uuid === id) : null;
      // Repainting a sheet nothing on the lawn is drawing from is how a menu
      // or loading-screen texture gets broken, and that is unrecoverable
      // without a restart.
      if (scope === `sheet` && target && !target.users.length) {
        e.log.error(`[Textures] Not repainting that sheet: nothing on the lawn is using it right now.`);
        return Promise.resolve(0);
      }
      const sized = target ? fitTo(dataUrl, target.tex.width, target.tex.height) : Promise.resolve(dataUrl);
      return sized.then(imageFrom).then((imageAsset) => {
      if (scope === `sheet`) {
        if (!target) return 0;
        if (!originalImages.has(id)) originalImages.set(id, target.tex.image);
        const how = repaint(target.tex, imageAsset);
        if (!how) return 0;
        sheetsDone.set(id, target.tex);
        routes[key] = how;
        return 1;
      }
      const row = plantRows().find((r) => r.codename === id);
      if (!row) return 0;
      const tex = textureFrom(imageAsset);
      let done = 0;
      for (const plant of row.plants) {
        const how = scope === `still`
          ? still(plant, tex, stillScales.get(id))
          : dressPlant(plant, tex);
        if (!how) continue;
        stamped.add(plant);
        routes[key] = how;
        done++;
      }
      if (!done && scope !== `still`) e.log.error(`[Textures] ${row.label}: neither its atlas nor its material would take a new texture on this build. Use the whole-sheet button instead.`);
      if (!done && scope === `still`) e.log.error(`[Textures] ${row.label}: couldn't hang a still image on it.`);
      return done;
      });
    };

    // Whole-sheet repaints go back on on a timer: assets get thrown away
    // between levels. Per-plant art is put on as each plant arrives, further
    // down; the timer only catches what arrived before its picture was ready.
    const reapply = () => {
      if (stopped || !inLevel()) return;
      for (const [key, dataUrl] of Object.entries(saved())) {
        const [scope, id] = key.split(`:`);
        if (scope !== `sheet`) continue;
        const target = allTextures().find((t) => t.uuid === id);
        if (!target || sheetsDone.get(id) === target.tex) continue;
        applyKey(key, dataUrl).catch(() => { /* asset mid-swap */ });
      }
      // A plant re-assigns its own material every frame, so a material-route
      // override has to be re-set rather than assumed.
      for (const plant of PlantPool?.pool?.() ?? []) {
        if (plant?.__gtTexture && plant.__gtMaterial?.setProperty) {
          try {
            plant.__gtMaterial.setProperty(`mainTexture`, plant.__gtTexture);
          } catch (err) { /* gone */ }
        }
      }
    };
    setInterval(() => {
      if (stopped) return;
      try {
        reapply();
        settle();
      } catch (err) {
        halt(err.message);
      }
      const t = Date.now();
      if (!rebuilds.since) rebuilds.since = t;
      if (t - rebuilds.since >= 10000) {
        if (rebuilds.count && inLevel()) {
          e.log.info(`[Textures] ${rebuilds.count} armature rebuild(s) in the last ${Math.round((t - rebuilds.since) / 1000)}s`
            + (unclocked ? `, ${unclocked} of them couldn't be put on the animation clock.` : `, all animating.`));
        }
        rebuilds.count = 0;
        unclocked = 0;
        rebuilds.since = t;
      }
    }, RECHECK_MS);

    // ==================================================================
    // Pictures in and out
    // ==================================================================

    const pictureOf = (tex, maxSide) => {
      const source = tex?.image?.data ?? tex?.image?._data ?? tex?.image?.nativeAsset;
      if (!source || typeof source.width !== `number`) return null;
      try {
        const scale = maxSide ? Math.min(1, maxSide / Math.max(source.width, source.height)) : 1;
        const canvas = doc.createElement(`canvas`);
        canvas.width = Math.max(1, Math.round(source.width * scale));
        canvas.height = Math.max(1, Math.round(source.height * scale));
        const ctx = canvas.getContext(`2d`);
        ctx.imageSmoothingEnabled = scale < 1;
        ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL(`image/png`);
      } catch (err) {
        return null;
      }
    };

    const exportTexture = (tex, filename) => {
      const url = pictureOf(tex, 0);
      if (!url) {
        e.log.error(`[Textures] ${filename}: no readable image (it may be compressed on this build).`);
        return false;
      }
      const link = doc.createElement(`a`);
      link.href = url;
      link.download = filename.endsWith(`.png`) ? filename : `${filename}.png`;
      doc.body.appendChild(link);
      link.click();
      link.remove();
      return true;
    };

    const pickFile = (onDataUrl) => {
      const input = doc.createElement(`input`);
      input.type = `file`;
      input.accept = `image/png,image/jpeg,image/webp`;
      input.style.display = `none`;
      input.onchange = () => {
        const file = input.files?.[0];
        input.remove();
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => onDataUrl(String(reader.result ?? ``), file.name);
        reader.onerror = () => e.log.error(`[Textures] Couldn't read ${file.name}.`);
        reader.readAsDataURL(file);
      };
      doc.body.appendChild(input);
      input.click();
    };

    // Several pictures at once, in the order they were picked.
    const pickFiles = (onDataUrls) => {
      const input = doc.createElement(`input`);
      input.type = `file`;
      input.multiple = true;
      input.accept = `image/png,image/jpeg,image/webp`;
      input.style.display = `none`;
      input.onchange = () => {
        const files = [...(input.files ?? [])];
        input.remove();
        if (!files.length) return;
        Promise.all(files.map((file) => new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result ?? ``));
          reader.onerror = () => reject(new Error(`couldn't read ${file.name}`));
          reader.readAsDataURL(file);
        })))
          .then((urls) => onDataUrls(urls, files.map((f) => f.name)))
          .catch((err) => e.log.error(`[Textures] ${err.message}`));
      };
      doc.body.appendChild(input);
      input.click();
    };

    const loadImage = (url) => new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error(`that file isn't an image this build can read`));
      img.src = url;
    });

    // Sprite sheets packed into one picture, the first at the top left so
    // anything already cut from it keeps its coordinates. Each next sheet
    // goes to the right or below, whichever keeps the picture squarer. A
    // rig draws from a single texture, so this is how it gets several.
    const SHEET_GAP = 4;
    const MAX_SHEET = 4096;
    const combineSheets = (urls) => Promise.all(urls.map(loadImage)).then((images) => {
      const regions = [];
      let width = 0;
      let height = 0;
      images.forEach((im, i) => {
        let at = { x: 0, y: 0 };
        if (i > 0) {
          const rightSide = Math.max(width + SHEET_GAP + im.width, height, im.height);
          const belowSide = Math.max(width, im.width, height + SHEET_GAP + im.height);
          at = rightSide <= belowSide ? { x: width + SHEET_GAP, y: 0 } : { x: 0, y: height + SHEET_GAP };
        }
        regions.push({ x: at.x, y: at.y, width: im.width, height: im.height });
        width = Math.max(width, at.x + im.width);
        height = Math.max(height, at.y + im.height);
      });
      if (Math.max(width, height) > MAX_SHEET) {
        throw new Error(`together the sheets come to ${width}x${height}, over the ${MAX_SHEET} a texture can be. Crop them first, or use fewer`);
      }
      const canvas = doc.createElement(`canvas`);
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext(`2d`);
      images.forEach((im, i) => ctx.drawImage(im, regions[i].x, regions[i].y));
      return { dataUrl: canvas.toDataURL(`image/png`), regions, width, height };
    });

    const replace = (key, label) => pickFile((dataUrl, filename) => {
      applyKey(key, dataUrl)
        .then((count) => {
          if (!count) {
            e.log.error(`[Textures] ${label}: nothing to put it on right now.`);
            return;
          }
          remember(key, dataUrl);
          e.log.info(`[Textures] ${label}: now wearing ${filename} (${routes[key] ?? `applied`}).`);
          drawPanel();
        })
        .catch((err) => e.log.error(`[Textures] ${label}: ${err.message}`));
    });

    // Undo puts the original back where it can, rather than only forgetting
    // the override: a repainted sheet gets its old image, a dressed plant gets
    // its own atlas and material texture again.
    const undo = (key, label) => {
      const [goingScope, goingId] = key.split(`:`);
      if (goingScope === `plant` || goingScope === `rig` || goingScope === `rigart`) keepRig(goingId, `removed`);
      forget(key);
      const [scope, id] = key.split(`:`);
      let live = false;
      try {
        if (scope === `sheet`) {
          sheetsDone.delete(id);
          const target = allTextures().find((t) => t.uuid === id);
          const before = originalImages.get(id);
          if (target && before) {
            live = !!repaint(target.tex, before);
            originalImages.delete(id);
          }
        } else {
          // One piece of a plant's look, or with `plant:` all of it.
          const all = scope === `plant`;
          if (all || scope === `fit` || scope === `fitart`) {
            fittedSets.delete(id);
            forget(`fit:${id}`);
            forget(`fitart:${id}`);
          }
          if (all || scope === `rig` || scope === `rigart`) {
            rigSets.delete(id);
            forget(`rig:${id}`);
            forget(`rigart:${id}`);
          }
          if (all || scope === `packet`) {
            packetTextures.delete(id);
            packetBacks.delete(id);
            packetFronts.delete(id);
            packetLooks.delete(id);
            forget(`packet:${id}`);
            forget(`packetback:${id}`);
            forget(`packetfront:${id}`);
            for (const card of [...dressedCards]) {
              if (card?.Type !== id) continue;
              undressCard(card);
              dressedCards.delete(card);
              live = true;
            }
          }
          if (all || scope === `still`) forget(`still:${id}`);
          if (all) armatureSets.delete(id);
          // Everything showing that plant goes back to vanilla and then puts
          // on whatever is left of its look.
          const showing = [
            ...(plantRows().find((r) => r.codename === id)?.plants ?? []),
            ...[...displays].filter((shown) => shown?.node && codenameOf(shown) === id),
          ];
          for (const one of showing) {
            if (isDressed(one) || one.__gtMaterial) live = true;
            if (one.__gtMaterial?.setProperty && one.__gtWasTexture) {
              one.__gtMaterial.setProperty(`mainTexture`, one.__gtWasTexture);
            }
            undressPlant(one);
            dressNow(one);
          }
        }
      } catch (err) {
        e.log.error(`[Textures] ${label}: couldn't put the original back (${err.message}). A restart will.`);
      }
      delete routes[key];
      e.log.info(live
        ? `[Textures] ${label} is back to its own art.`
        : `[Textures] ${label} is forgotten. It looks vanilla again after a restart, or when that art next loads.`);
      drawPanel();
    };



    // ==================================================================
    // Still image
    //
    // A sheet from another plant is not a repaint: the armature's slots hold
    // coordinates into the layout it was built for, so every piece lands in
    // the wrong place and the plant reads as a glitchy mess. Until the art
    // comes with its own skeleton, this is the way to make a plant look
    // right: hide the armature and hang one picture on it instead, with a
    // slow sway so it doesn't look dead.
    // ==================================================================
    const STILL_FIT = 1.4; // how many tiles tall a still image is drawn
    const TILE_H = 80;

    // Hidden, not switched off. A plant's attacks often hang off its own
    // animation: Laser Bean fires on a "shoot" frame event, from a beam point
    // that rides a bone. A switched-off node stops animating, so no event.
    // Zero opacity is no better: the renderer skips the node entirely, and
    // bone-riding nodes are only moved while it is being drawn, so the beam
    // point froze and the beam missed the lane. Opacity 1 of 255 is drawn,
    // keeps every attached point moving, and can't be seen.
    const HIDDEN_OPACITY = 1;
    const Opacity = cc.UIOpacity ?? engineClass(`cc.UIOpacity`);
    const setSeen = (node, seen) => {
      if (!node) return;
      // No component to be had: the opacity it sets, set directly.
      if (!Opacity && node._uiProps && `localOpacity` in node._uiProps) {
        if (!seen) {
          if (node.__gtWasLocal === undefined) node.__gtWasLocal = node._uiProps.localOpacity;
          node._uiProps.localOpacity = HIDDEN_OPACITY / 255;
        } else if (node.__gtWasLocal !== undefined) {
          node._uiProps.localOpacity = node.__gtWasLocal;
          node.__gtWasLocal = undefined;
        }
        return;
      }
      if (Opacity && typeof node.addComponent === `function`) {
        let comp = node.getComponent?.(Opacity) ?? null;
        if (!seen) {
          if (!comp) {
            comp = node.addComponent(Opacity);
            node.__gtOpacityAdded = true;
          } else if (node.__gtWasOpacity === undefined && !node.__gtOpacityAdded) {
            node.__gtWasOpacity = comp.opacity;
          }
          comp.opacity = HIDDEN_OPACITY;
          return;
        }
        if (!comp) return;
        if (node.__gtOpacityAdded) {
          comp.opacity = 255;
          comp.destroy?.();
          node.__gtOpacityAdded = false;
        } else if (node.__gtWasOpacity !== undefined) {
          comp.opacity = node.__gtWasOpacity;
          node.__gtWasOpacity = undefined;
        }
        return;
      }
      // No UIOpacity on this build: switching it off is all there is.
      node.active = seen;
    };

    const hideArmature = (plant, hidden) => {
      const db = plant?.db ?? plant?.anmControl?.db;
      const parts = [db, ...(plant?.anmControl?.bodyPartsDB ?? [])].filter(Boolean);
      for (const part of new Set(parts)) {
        try {
          if (part.node) setSeen(part.node, !hidden);
          else part.enabled = !hidden;
        } catch (err) { /* that part won't hide */ }
      }
      return parts.length > 0;
    };

    // Nudges, in pixels, kept per plant kind like the sizes are.
    const stillOffsets = new Map();
    const packetOffsets = new Map();
    const codenameOf = (plant) => nameOfPlant(plant).codename;

    const still = (plant, tex, scale) => {
      if (!cc.Node || !cc.Sprite || !cc.SpriteFrame) return null;
      try {
        if (plant.__gtStill?.isValid !== false) plant.__gtStill?.destroy?.();
        const node = new cc.Node(`gtStill`);
        const frame = new cc.SpriteFrame();
        frame.texture = tex;
        const sprite = node.addComponent(cc.Sprite);
        sprite.spriteFrame = frame;
        sprite.sizeMode = cc.Sprite?.SizeMode?.RAW ?? sprite.sizeMode;
        // Take the armature's own place in the draw order: same parent, right
        // beside it. Above the shadow, below anything drawn over the plant,
        // and it rides along with whatever moves the body.
        const armNode = (plant.db ?? plant.anmControl?.db)?.node;
        const parent = armNode?.parent ?? plant.node;
        node.parent = parent;
        if (armNode && typeof armNode.getSiblingIndex === `function`) node.setSiblingIndex?.(armNode.getSiblingIndex() + 1);
        const base = armNode?.position ?? { x: 0, y: 0, z: 0 };
        node.__gtBase = { x: base.x ?? 0, y: base.y ?? 0, z: base.z ?? 0 };
        const shift = stillOffsets.get(codenameOf(plant)) ?? { x: 0, y: 0 };
        node.setPosition?.(node.__gtBase.x + shift.x, node.__gtBase.y + shift.y, node.__gtBase.z);
        // Drawn a fixed number of tiles tall whatever the picture's own size,
        // so a 1536px sheet doesn't arrive the size of the lawn.
        const wanted = TILE_H * (scale ?? STILL_FIT);
        const factor = tex.height ? wanted / tex.height : 1;
        node.setScale?.(factor, factor, 1);
        node.layer = plant.node?.layer ?? node.layer;
        // The plant's own material carries the hit flash and the frozen and
        // poisoned tints, so the picture takes it too. The colour (dimmed in
        // the almanac, faded when a plant goes) is copied across each frame.
        const db = plant.db ?? plant.anmControl?.db;
        const skin = stored(`option:stillflash`) === `off` ? null : (plant.material ?? db?.customMaterial ?? null);
        if (skin) {
          try {
            sprite.customMaterial = skin;
          } catch (err) { /* plain sprite, no flash */ }
        }
        if (db) {
          db.__gtSprite = sprite;
          tint(db);
        }
        hideArmature(plant, true);
        plant.__gtStill = node;
        plant.__gtStillScale = scale ?? STILL_FIT;
        // A slow breath, so a still plant still reads as alive.
        try {
          cc.tween?.(node)
            ?.repeatForever(
              cc.tween(node).to(1.2, { scale: new cc.Vec3(factor * 1.03, factor * 0.97, 1) })
                .to(1.2, { scale: new cc.Vec3(factor, factor, 1) }),
            )
            ?.start?.();
        } catch (err) { /* no sway, just a still picture */ }
        return `still image`;
      } catch (err) {
        e.log.error(`[Textures] Couldn't hang a still image: ${err.message}`);
        return null;
      }
    };

    const stillOff = (plant) => {
      try {
        plant.__gtStill?.destroy?.();
      } catch (err) { /* already gone */ }
      plant.__gtStill = null;
      const db = plant.db ?? plant.anmControl?.db;
      if (db) db.__gtSprite = null;
      hideArmature(plant, false);
    };

    // ==================================================================
    // Whole armatures
    //
    // Repainting a sheet only works while the layout stays put, because the
    // armature's slots hold coordinates into the old one. Wearing a different
    // plant's art means bringing its skeleton as well: a DragonBones set is
    // three files, the skeleton json, the atlas json that says where each
    // piece sits on the sheet, and the sheet itself.
    //
    // PvZ2's own art is not in that format -- it ships PAM/reanim animations,
    // which have to be converted first. Once converted, this puts the result
    // on a plant.
    // ==================================================================
    const dragonBones = cc.dragonBones ?? cc.dragonbones ?? {
      ArmatureDisplay: engineClass(`dragonBones.ArmatureDisplay`),
      DragonBonesAsset: engineClass(`dragonBones.DragonBonesAsset`),
      DragonBonesAtlasAsset: engineClass(`dragonBones.DragonBonesAtlasAsset`),
    };
    const AnimationController = getModule(`AnimationController`)?.AnimationController;

    // What the new armature can actually play. The game asks for clip names
    // from the plant it borrowed ("Idle", "Shoot", "Food"), and a converted
    // armature rarely uses the same ones, so the closest match wins and
    // anything unmatched falls back to the first clip rather than freezing.
    const clipsOf = (db) => {
      try {
        return Object.keys(db?.armature?.()?.animation?._animations ?? db?._armature?.animation?._animations ?? {});
      } catch (err) {
        return [];
      }
    };

    const mapClip = (wanted, have) => {
      if (!have.length) return wanted;
      if (have.includes(wanted)) return wanted;
      const lower = String(wanted).toLowerCase();
      const same = have.find((n) => n.toLowerCase() === lower);
      if (same) return same;
      const near = have.find((n) => n.toLowerCase().includes(lower) || lower.includes(n.toLowerCase()));
      return near ?? have[0];
    };

    let clipMapped = 0;
    if (AnimationController?.prototype?.playAnimation) {
      e.unsafe.hooks.wrapMethod({
        target: AnimationController.prototype,
        methodName: `playAnimation`,
        handler: ({ args, thisArg, callNext }) => {
          const have = thisArg?.__gtClips;
          if (!have?.length) return callNext(...args);
          const mapped = mapClip(args[0], have);
          if (mapped !== args[0]) clipMapped++;
          return callNext(mapped, ...args.slice(1));
        },
      });
    } else {
      e.log.error(`[Textures] No AnimationController.playAnimation -- a new armature will only play clips named exactly like the old one's.`);
    }

    const buildArmature = ({ skeleton, atlasJson, imageAsset }) => {
      if (!dragonBones?.DragonBonesAsset || !dragonBones?.DragonBonesAtlasAsset) {
        throw new Error(`this build doesn't expose the DragonBones asset classes`);
      }
      const ske = new dragonBones.DragonBonesAsset();
      ske.dragonBonesJson = skeleton;
      ske._uuid = `gt-ske-${Date.now()}`;
      const atlas = new dragonBones.DragonBonesAtlasAsset();
      atlas.atlasJson = atlasJson;
      atlas._uuid = `gt-atlas-${Date.now()}`;
      const tex = textureFrom(imageAsset);
      atlas.texture = tex;
      atlas._texture = tex;
      return { ske, atlas };
    };

    // ==================================================================
    // Wearing a look
    //
    // A plant's armature is half its behaviour. Attacks fire on its frame
    // events (Chomper bites on "chomp", Spikeweed hits on "attack", Laser
    // Bean fires on "shoot") and the game waits on a clip's COMPLETE before
    // it will attack again. A new sheet keeps all of that, being the same
    // skeleton. A rig carries it across: its clips copy the plant's names,
    // lengths and events (vanillaClips).
    // ==================================================================
    let atlasCount = 0;
    // A fresh atlas asset. text null keeps the source's layout, for a
    // repainted sheet; otherwise it's the json the new pieces are cut by.
    const newAtlas = (source, text, tex) => {
      atlasCount++;
      let atlas = null;
      try {
        if (text !== null && dragonBones?.DragonBonesAtlasAsset) atlas = new dragonBones.DragonBonesAtlasAsset();
      } catch (err) { /* clone instead */ }
      if (!atlas && source) {
        atlas = Object.create(Object.getPrototypeOf(source));
        Object.assign(atlas, source);
      }
      if (!atlas) return null;
      // A clone carries the source's parsed atlas, which points at the old
      // texture. Dropped here so it's parsed again against the new one.
      atlas._factory = null;
      atlas._textureAtlasData = null;
      atlas._uuid = `gt-atlas-${atlasCount}-${Date.now()}`;
      if (text !== null) {
        try {
          atlas.atlasJson = text;
        } catch (err) { /* read-only on this build */ }
        atlas._atlasJson = text;
        atlas._atlasJsonData = null;
      }
      atlas.texture = tex;
      atlas._texture = tex;
      return atlas;
    };

    // Parsed skeletons and atlases stay in the DragonBones factory for good,
    // so every plant of a kind shares one pair rather than adding its own.
    const lookCache = new WeakMap(); // texture -> key -> { ske, atlas }
    const objectIds = new WeakMap();
    let objectCount = 0;
    const idOf = (obj) => {
      let id = objectIds.get(obj);
      if (!id) objectIds.set(obj, id = ++objectCount);
      return id;
    };
    const sharedAssets = (tex, key, make) => {
      let byKey = lookCache.get(tex);
      if (!byKey) lookCache.set(tex, byKey = new Map());
      if (byKey.has(key)) return byKey.get(key);
      const made = make();
      if (made?.ske && made?.atlas) byKey.set(key, made);
      return made;
    };

    const armatureNameIn = (ske, fallback) => {
      try {
        let json = ske?.dragonBonesJson ?? ske?._dragonBonesJson;
        if (typeof json === `string`) json = JSON.parse(json);
        return json?.armature?.[0]?.name ?? fallback;
      } catch (err) {
        return fallback;
      }
    };

    // A pooled object goes back to being whatever it was, skeleton included,
    // or the next plant built on it animates a stranger's bones.
    const keepSkeleton = (plant, db) => {
      if (plant.__gtWasAtlas === undefined) {
        plant.__gtWasAtlas = atlasOf(plant) ?? null;
        plant.__gtWasTexture = textureIn(plant.__gtWasAtlas) ?? null;
      }
      if (plant.__gtWasSkeleton !== undefined) return;
      plant.__gtWasSkeleton = db.dragonAsset ?? null;
      plant.__gtWasArmatureName = db.armatureName;
    };

    // A rebuild drops whatever clip was playing. The game only asks for a
    // new one when the plant changes what it's doing, and it waits on the
    // old one finishing (the idle cycles on COMPLETE, a Chomper can't bite
    // again until its attack ends). So the same clip is started again, the
    // same number of times, and the game carries on as if nothing happened.
    const keepPlaying = (db, clips, was, times) => {
      try {
        if (!clips?.length) return;
        const idle = clips.find((c) => clipKind(c) === `idle`) ?? clips[0];
        const name = was ? mapClip(was, clips) : idle;
        db.playAnimation?.(clips.includes(name) ? name : idle, typeof times === `number` ? times : 0);
      } catch (err) { /* it plays when the game next asks */ }
    };
    // Rebuilds, counted, and logged every 10s of a level that has any. One
    // per plant as it arrives is normal; a steady stream means something is
    // rebuilding in a loop, and that line says so.
    const rebuilds = { count: 0, since: 0 };
    // _refresh() builds a new armature, but only the display's setters and
    // its onEnable put an armature on the world clock that moves it. Every
    // rebuild this mod did left the plant on an armature nothing advanced:
    // frozen, and with no frame events, so no attacks either. That was the
    // "adding a texture kills the plant" bug, the rig that "won't animate no
    // matter what", and the pooled plant that came back dead after a dressed
    // one died. After a rebuild the armature is put on the clock here.
    let unclocked = 0;
    const clockOf = (db) => db?._factory?._dragonBones?.clock
      ?? dragonBones?.CCFactory?.getInstance?.()?._dragonBones?.clock
      ?? null;
    const rebuild = (db) => {
      db._refresh?.();
      rebuilds.count++;
      try {
        if (db.isAnimationCached?.()) return;
        const arm = db.armature?.() ?? db._armature;
        if (!arm || arm.clock) return;
        const clock = clockOf(db);
        if (clock?.add) {
          clock.add(arm);
        } else if (db.enabledInHierarchy !== false) {
          // No clock to be had from here: switching the display off and on
          // runs the engine's own onEnable, which adds it.
          db.enabled = false;
          db.enabled = true;
        }
        if (!arm.clock) unclocked++;
      } catch (err) { /* reported by the rig check */ }
    };

    // Every look goes on the plant's own armature, the way the game builds
    // its own plants: one display, its sheet (and for a rig its skeleton)
    // swapped, rebuilt once, in whatever cache mode the game gave it.
    //
    // 0.13 and 0.14 drew the look on a second display and kept the plant's
    // own one running hidden underneath for its attack events. That cost the
    // game most of its frame rate. The events come along with the rig now
    // instead (see vanillaClips), so there is only ever one armature.
    const wearOn = (plant, { ske = null, atlas, armatureName = null }) => {
      const db = plant?.db ?? plant?.anmControl?.db;
      if (!db || !atlas) return null;
      try {
        keepSkeleton(plant, db);
        if (plant.__gtStill) stillOff(plant);
        const was = db.animationName;
        const times = db.playTimes;
        db.dragonAtlasAsset = atlas;
        if (ske) {
          db.dragonAsset = ske;
          if (armatureName) db.armatureName = armatureName;
        }
        rebuild(db);
        const clips = clipsOf(db);
        // A new skeleton may name its clips differently; the game's names
        // are mapped onto the nearest it has.
        if (plant.anmControl) plant.anmControl.__gtClips = ske ? clips : null;
        keepPlaying(db, clips, was, times);
        return clips;
      } catch (err) {
        e.log.error(`[Textures] ${codenameOf(plant)}: couldn't put the new look on: ${err.message}`);
        return null;
      }
    };

    const wearArmature = (plant, built) => {
      const clips = wearOn(plant, { ske: built.ske, atlas: built.atlas, armatureName: armatureNameIn(built.ske, null) });
      if (!clips) return null;
      plant.__gtArmature = built;
      return clips.length ? `armature (${clips.length} clips)` : `armature`;
    };

    // Sorts whatever was picked into the three parts a set needs.
    const readSet = (files) => Promise.all([...files].map((file) => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error(`couldn't read ${file.name}`));
      if (/^image\//.test(file.type) || /\.(png|jpe?g|webp)$/i.test(file.name)) {
        reader.onload = () => resolve({ kind: `image`, name: file.name, data: String(reader.result ?? ``) });
        reader.readAsDataURL(file);
        return;
      }
      reader.onload = () => {
        const text = String(reader.result ?? ``);
        const kind = /"SubTexture"|"imagePath"/.test(text) ? `atlas`
          : /"armature"|"bone"/.test(text) ? `skeleton`
          : `unknown`;
        resolve({ kind, name: file.name, data: text });
      };
      reader.readAsText(file);
    }))).then((parts) => {
      const picked = {};
      for (const part of parts) picked[part.kind] = part;
      const missing = [`image`, `atlas`, `skeleton`].filter((k) => !picked[k]);
      if (missing.length) {
        throw new Error(`a set needs a skeleton json, an atlas json and a png. Missing: ${missing.join(`, `)}`);
      }
      return picked;
    });

    const dressFromSet = (codename, label) => {
      const input = doc.createElement(`input`);
      input.type = `file`;
      input.multiple = true;
      input.accept = `.json,.png,.jpg,.jpeg,.webp,image/*,application/json`;
      input.style.display = `none`;
      input.onchange = () => {
        const files = input.files;
        input.remove();
        if (!files?.length) return;
        readSet(files)
          .then((picked) => imageFrom(picked.image.data).then((imageAsset) => ({ picked, imageAsset })))
          .then(({ picked, imageAsset }) => {
            const built = buildArmature({
              skeleton: picked.skeleton.data,
              atlasJson: picked.atlas.data,
              imageAsset,
            });
            const row = plantRows().find((r) => r.codename === codename);
            let done = 0;
            for (const plant of row?.plants ?? []) {
              const how = wearArmature(plant, built);
              if (how) {
                routes[`armature:${codename}`] = how;
                done++;
              }
            }
            if (!done) {
              e.log.error(`[Textures] ${label}: nothing on the lawn took the armature.`);
              return;
            }
            armatureSets.set(codename, built);
            bumpLook(codename);
            e.log.info(`[Textures] ${label}: wearing ${picked.skeleton.name} + ${picked.image.name} (${routes[`armature:${codename}`]}).`);
            drawPanel();
          })
          .catch((err) => e.log.error(`[Textures] ${label}: ${err.message}`));
      };
      doc.body.appendChild(input);
      input.click();
    };

    // Armature sets are far too big for localStorage, so they last the
    // session and go on each plant of that kind as it arrives.
    const armatureSets = new Map();

    // What DragonBones art this build has, whether or not a plant uses it.
    const armatures = (query) => {
      const needle = String(query ?? ``).toLowerCase();
      const found = [];
      try {
        cc.assetManager.bundles.forEach((bundle) => {
          const infos = bundle?.config?.assetInfos;
          infos?.forEach?.((info, uuid) => {
            const path = info?.path ?? info?.name ?? ``;
            if (!path || (needle && !path.toLowerCase().includes(needle))) return;
            found.push({ bundle: bundle.name, path, uuid });
          });
        });
      } catch (err) {
        e.log.error(`[Textures] Couldn't read the bundle list: ${err.message}`);
      }
      e.log.info(`[Textures] ${found.length} asset path(s)${needle ? ` matching "${needle}"` : ``}:`);
      for (const row of found.slice(0, 60)) e.log.info(`  ${row.bundle}: ${row.path}`);
      return found;
    };

    // ==================================================================
    // Fitting art to a rig
    //
    // An armature's atlas is a list of named rectangles: slot "leaf_1" draws
    // whatever sits at x=812,y=240,w=96,h=64. Hand it a different plant's
    // sheet and every one of those rectangles lands on the wrong pixels,
    // which is the glitchy mess.
    //
    // The fix is to tell the rig where its pieces moved to. The sheet is
    // scanned for separate lumps of opaque pixels, each lump becomes a box,
    // and each box is paired with one of the rig's named rectangles. Rewrite
    // the atlas with those coordinates and the rig draws the new art in the
    // right places, animating exactly as it did before.
    // ==================================================================

    // Separate lumps of opaque pixels, found by walking the alpha channel.
    // Downsampled first: a 1536 square is two million pixels, and a piece of
    // plant is never one pixel wide, so a quarter-scale mask finds the same
    // lumps for a sixteenth of the work.
    const detectBoxes = (mask, width, height, { step = 4, minSide = 3 } = {}) => {
      const seen = new Uint8Array(width * height);
      const boxes = [];
      const stack = [];
      for (let start = 0; start < mask.length; start++) {
        if (!mask[start] || seen[start]) continue;
        let minX = width;
        let maxX = 0;
        let minY = height;
        let maxY = 0;
        stack.length = 0;
        stack.push(start);
        seen[start] = 1;
        while (stack.length) {
          const at = stack.pop();
          const x = at % width;
          const y = (at - x) / width;
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
          // Four neighbours is enough: pieces are solid, not hairlines.
          if (x > 0 && mask[at - 1] && !seen[at - 1]) { seen[at - 1] = 1; stack.push(at - 1); }
          if (x < width - 1 && mask[at + 1] && !seen[at + 1]) { seen[at + 1] = 1; stack.push(at + 1); }
          if (y > 0 && mask[at - width] && !seen[at - width]) { seen[at - width] = 1; stack.push(at - width); }
          if (y < height - 1 && mask[at + width] && !seen[at + width]) { seen[at + width] = 1; stack.push(at + width); }
        }
        if (maxX - minX < minSide || maxY - minY < minSide) continue;
        boxes.push({
          x: minX * step,
          y: minY * step,
          width: (maxX - minX + 1) * step,
          height: (maxY - minY + 1) * step,
        });
      }
      return boxes.sort((a, b) => (b.width * b.height) - (a.width * a.height));
    };

    const maskOf = (image, step, alphaAt) => {
      const width = Math.ceil(image.width / step);
      const height = Math.ceil(image.height / step);
      const mask = new Uint8Array(width * height);
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          mask[y * width + x] = alphaAt(x * step, y * step) > 16 ? 1 : 0;
        }
      }
      return { mask, width, height };
    };

    const boxesInImage = (img, step = 4) => {
      const canvas = doc.createElement(`canvas`);
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext(`2d`);
      ctx.drawImage(img, 0, 0);
      const data = ctx.getImageData(0, 0, img.width, img.height).data;
      const alphaAt = (x, y) => data[((y * img.width) + x) * 4 + 3] ?? 0;
      const { mask, width, height } = maskOf(img, step, alphaAt);
      return detectBoxes(mask, width, height, { step });
    };

    // The rectangles the rig is asking for.
    const atlasJsonOf = (plant) => {
      const atlas = atlasOf(plant);
      const raw = atlas?.atlasJson ?? atlas?._atlasJson ?? atlas?.atlasJsonStr;
      try {
        if (typeof raw === `string`) return JSON.parse(raw);
        if (raw && typeof raw === `object`) return JSON.parse(JSON.stringify(raw));
      } catch (err) {
        e.log.error(`[Textures] That rig's atlas isn't readable json: ${err.message}`);
      }
      return null;
    };

    const rigPieces = (plant) => {
      const json = atlasJsonOf(plant);
      const list = json?.SubTexture ?? json?.subTexture ?? json?.frames ?? [];
      return (Array.isArray(list) ? list : []).map((piece) => ({
        name: piece.name ?? piece.Name ?? `?`,
        x: piece.x ?? 0,
        y: piece.y ?? 0,
        width: piece.width ?? 0,
        height: piece.height ?? 0,
      }));
    };

    // A first guess, so the list starts mostly right: biggest piece to
    // biggest lump, in order. Wrong often enough to need the click-to-pair
    // below, close enough to save most of the clicking.
    const autoPair = (pieces, boxes) => {
      const bySize = [...pieces].sort((a, b) => (b.width * b.height) - (a.width * a.height));
      const pairs = {};
      bySize.forEach((piece, index) => {
        if (boxes[index]) pairs[piece.name] = index;
      });
      return pairs;
    };

    // The same atlas, with the paired pieces pointing at their new boxes.
    // Trim offsets are dropped for anything repointed: they describe where a
    // piece sat inside its old frame, which is meaningless on a new sheet.
    const rewriteAtlas = (json, pairs, boxes, imageSize) => {
      const out = JSON.parse(JSON.stringify(json));
      const list = out.SubTexture ?? out.subTexture ?? out.frames ?? [];
      let moved = 0;
      for (const piece of list) {
        const name = piece.name ?? piece.Name;
        const index = pairs[name];
        const box = typeof index === `number` ? boxes[index] : null;
        if (!box) continue;
        piece.x = box.x;
        piece.y = box.y;
        piece.width = box.width;
        piece.height = box.height;
        delete piece.frameX;
        delete piece.frameY;
        delete piece.frameWidth;
        delete piece.frameHeight;
        moved++;
      }
      if (imageSize) {
        out.width = imageSize.width;
        out.height = imageSize.height;
      }
      return { json: out, moved };
    };

    // DragonBones caches parsed atlas data by the name inside the json, so a
    // rewritten atlas under the old name gets the old rectangles handed back
    // and nothing appears to change. Every fit gets its own name and uuid.
    let fitCount = 0;
    const uniqueAtlas = (json) => {
      fitCount++;
      const copy = typeof json === `string` ? JSON.parse(json) : JSON.parse(JSON.stringify(json));
      copy.name = `${copy.name ?? `atlas`}_gt${fitCount}`;
      copy.imagePath = `${copy.imagePath ?? `sheet`}_gt${fitCount}.png`;
      return copy;
    };

    const fitToRig = (plant, atlasJson, tex) => {
      const db = plant?.db ?? plant?.anmControl?.db;
      if (!db) {
        e.log.error(`[Textures] That plant has no armature display to fit art to.`);
        return null;
      }
      try {
        const source = atlasOf(plant);
        const made = sharedAssets(tex, `fit:${idOf(atlasJson)}:${db.dragonAsset ? idOf(db.dragonAsset) : 0}`,
          () => ({ ske: db.dragonAsset, atlas: newAtlas(source, JSON.stringify(uniqueAtlas(atlasJson)), tex) }));
        if (!made?.atlas) {
          e.log.error(`[Textures] No way to build an atlas on this build: no DragonBonesAtlasAsset and no atlas to copy.`);
          return null;
        }
        // Same skeleton, new sheet: the plant's events and bones stay put.
        return wearOn(plant, { atlas: made.atlas }) ? `fitted` : null;
      } catch (err) {
        e.log.error(`[Textures] Couldn't fit that art to the rig: ${err.message}`);
        return null;
      }
    };


    // ==================================================================
    // Cleaning up after a plant
    //
    // A still image is a node parented to the plant, and a hidden armature is
    // a flag on a component. Plants are pooled: the object that just got
    // eaten comes back as the next plant of any kind, so anything left on it
    // haunts whatever is planted next. Everything this mod put on a plant
    // comes off when that plant is recycled. The override itself is
    // kept, so the next one of that kind is dressed again on the next pass.
    // ==================================================================
    const PlantBase = getModule(`Plant`)?.Plant;
    let cleaned = 0;
    const undressPlant = (plant) => {
      if (!plant) return;
      try {
        if (plant.__gtStill) {
          stillOff(plant);
          cleaned++;
        }
        const db = plant.db ?? plant.anmControl?.db;
        let needsRebuild = false;
        if (plant.__gtWasSkeleton !== undefined) {
          if (db && plant.__gtWasSkeleton) {
            db.dragonAsset = plant.__gtWasSkeleton;
            if (plant.__gtWasArmatureName !== undefined) db.armatureName = plant.__gtWasArmatureName;
            needsRebuild = true;
          }
          plant.__gtWasSkeleton = undefined;
          plant.__gtWasArmatureName = undefined;
        }
        if (plant.__gtWasAtlas !== undefined) {
          if (db && plant.__gtWasAtlas) {
            db.dragonAtlasAsset = plant.__gtWasAtlas;
            needsRebuild = true;
          }
          plant.__gtWasAtlas = undefined;
          plant.__gtWasTexture = undefined;
          cleaned++;
        }
        if (needsRebuild) rebuild(db);
        if (plant.__gtWasCache !== undefined) {
          try {
            db?.setAnimationCacheMode?.(plant.__gtWasCache);
          } catch (err) { /* stays realtime */ }
          plant.__gtWasCache = undefined;
        }
        if (plant.anmControl) plant.anmControl.__gtClips = null;
        plant.__gtFitted = null;
        plant.__gtRig = null;
        plant.__gtArmature = null;
        plant.__gtMaterial = null;
        plant.__gtTexture = null;
        plant.__gtLook = undefined;
        stamped.delete(plant);
      } catch (err) { /* it's leaving anyway */ }
    };

    // Dying is not leaving. Plant.die plays the death clip on the armature
    // and only destroys the node when that clip fires COMPLETE, so for a
    // moment the plant is dead but still on screen. Undressing it there put
    // the vanilla art back for exactly those frames. The art now stays on
    // until the node is actually disabled.
    //
    // That leaves one hole: a clip that never completes. A hidden armature
    // doesn't tick, and a rig built here has no death clip, so the game would
    // wait forever and the plant would never go. Those get finished here.
    const DEATH_FADE = 0.25;
    let finished = 0;

    const deathWillFinish = (plant, playsClip) => {
      const db = plant.anmControl?.db ?? plant.db;
      if (!db || db.node?.active === false || !playsClip) return false;
      try {
        return (db.armature?.()?.animation?.animationNames ?? []).includes(plant.deathAnm);
      } catch (err) {
        return false;
      }
    };

    const later = (plant, seconds, fn) => {
      if (typeof plant.scheduleOnce === `function`) plant.scheduleOnce(fn, seconds);
      else setTimeout(fn, seconds * 1000);
    };

    // The death clip plays unseen under a still image, so the picture does
    // the dying: a quick shrink.
    const shrinkStill = (plant) => {
      const pic = plant.__gtStill;
      if (!pic) return false;
      try {
        cc.Tween?.stopAllByTarget?.(pic);
        cc.tween?.(pic)?.to(DEATH_FADE, { scale: new cc.Vec3(0, 0, 1) })?.start?.();
      } catch (err) { /* it just goes, without the shrink */ }
      return true;
    };

    const finishDeath = (plant, particle) => {
      const token = {};
      plant.__gtDying = token;
      const pic = shrinkStill(plant);
      later(plant, pic ? DEATH_FADE : 0.1, () => {
        if (plant.__gtDying !== token) return;
        plant.__gtDying = null;
        const node = plant.node;
        if (!plant.dead || !node || node.isValid === false) return;
        if (particle) {
          try { plant.playDeathParticle?.(); } catch (err) { /* no puff */ }
        }
        finished++;
        node.destroy();
      });
    };

    const isDressed = (plant) => !!(plant?.__gtStill || plant?.__gtWasAtlas !== undefined || plant?.__gtArmature);

    try {
      if (typeof PlantBase?.prototype?.die === `function`) {
        e.unsafe.hooks.wrapMethod({
          target: PlantBase.prototype,
          methodName: `die`,
          handler: ({ args, thisArg, callNext }) => {
            const plant = thisArg;
            const watch = isDressed(plant) && !plant.dead;
            const result = callNext(...args);
            // Same defaults as Plant.die: kill, _, particle, playsClip.
            const [kill = true, , particle = true, playsClip = true] = args;
            // No death clip means the game destroyed it already; kill=false
            // means it was carried off (sky fall, chi hole) and goes later.
            if (!watch || !plant.dead || !kill || plant.deathAnm === `` || plant.node?.isValid === false) return result;
            if (!deathWillFinish(plant, playsClip)) finishDeath(plant, particle);
            else shrinkStill(plant);
            return result;
          },
        });
      }
    } catch (err) {
      e.log.error(`[Textures] Couldn't hook Plant.die: a plant with custom art may not go away when it dies.`);
    }

    try {
      if (typeof PlantBase?.prototype?.characterOnDisable === `function`) {
        e.unsafe.hooks.wrapMethod({
          target: PlantBase.prototype,
          methodName: `characterOnDisable`,
          handler: ({ args, thisArg, callNext }) => {
            if (thisArg) thisArg.__gtDying = null;
            undressPlant(thisArg);
            return callNext(...args);
          },
        });
      }
    } catch (err) {
      e.log.error(`[Textures] Couldn't hook Plant.characterOnDisable: custom art may stay on a recycled plant.`);
    }

    // ==================================================================
    // Seed packets
    //
    // A packet's picture is an armature too: cardGrouperPlant ends with
    // ca._plantDB.playAnimation(PF._CARDSPRITENAME). So the same trick as a
    // still image works here -- hide that display and hang a picture in front
    // of it -- and it has to run on every card build, because the bank and
    // the chooser rebuild cards constantly.
    // ==================================================================
    const CardFeature = getModule(`CardFeature`)?.CardFeature;
    const PACKET_H = 62; // the art box on a packet, near enough
    let packets = 0;

    // A packet can wear three pictures, all the same size and place: a
    // background under the plant art, the plant art itself, and a border
    // over it. The game's own background, the sun cost plate and the family
    // icon can each be switched off; the sun cost number always stays, since
    // it changes in play. Everything goes on in the card's own space, as
    // siblings of the plant art, so the card's size and the bank's scaling
    // apply to it like to the rest of the card.
    const packetBacks = new Map(); // codename -> Texture2D, under the plant
    const packetFronts = new Map(); // codename -> Texture2D, over the plant
    const packetLooks = new Map(); // codename -> { hideBg, hidePlate, hideFamily }
    const armatureOn = (node) => {
      if (!node) return null;
      try {
        const found = dragonBones?.ArmatureDisplay ? node.getComponent?.(dragonBones.ArmatureDisplay) : null;
        if (found) return found;
      } catch (err) { /* look by shape instead */ }
      return (node.components ?? node._components ?? []).find((c) => typeof c?.playAnimation === `function`) ?? null;
    };
    const cardNodes = (card) => {
      const ca = card?.ca ?? null;
      const db = ca?._plantDB ?? card?._plantDB ?? null;
      const art = db?.node ?? null;
      const holder = art?.parent ?? null;
      const named = (name) => {
        try {
          return holder?.getChildByName?.(name) ?? null;
        } catch (err) {
          return null;
        }
      };
      const bgNode = named(`Background`);
      const plateNode = named(`Dots`);
      return {
        db, art, holder, bgNode,
        bg: armatureOn(bgNode),
        plate: armatureOn(plateNode),
        family: armatureOn(named(`Family`)),
      };
    };
    const cardPictures = (holder) => (holder?.children ?? []).filter((c) => /^gtPacket/.test(c?.name ?? ``) && c.isValid !== false);
    const wantsCardLook = (codename) => !!(packetTextures.get(codename) || packetBacks.get(codename) || packetFronts.get(codename)
      || Object.values(packetLooks.get(codename) ?? {}).some(Boolean));

    const dressCard = (card, tex, scale) => {
      const type = card?.Type;
      const { db, art: node, holder, bgNode, bg, plate, family } = cardNodes(card);
      if (!node || !holder || !cc.Node || !cc.Sprite || !cc.SpriteFrame) return null;
      try {
        undressCard(card);
        const look = packetLooks.get(type) ?? {};
        // The component, not the node: the almanac switches every child of a
        // card on each frame it is in view, which brought the old art back.
        const hidden = [];
        const off = (comp) => {
          if (!comp || comp.enabled === false) return;
          comp.enabled = false;
          hidden.push(comp);
        };
        const plant = tex ?? packetTextures.get(type) ?? null;
        const back = packetBacks.get(type) ?? null;
        const front = packetFronts.get(type) ?? null;
        if (plant) off(db);
        if (look.hideBg) off(bg);
        if (look.hidePlate) off(plate);
        if (look.hideFamily) off(family);
        const at = node.position ?? { x: 0, y: 0, z: 0 };
        const base = { x: at.x ?? 0, y: at.y ?? 0, z: at.z ?? 0 };
        const shift = packetOffsets.get(type) ?? { x: 0, y: 0 };
        const sprites = [];
        const place = (name, picture, after, tintFrom) => {
          const holderChild = new cc.Node(name);
          const frame = new cc.SpriteFrame();
          frame.texture = picture;
          const sprite = holderChild.addComponent(cc.Sprite);
          sprite.spriteFrame = frame;
          sprite.sizeMode = cc.Sprite?.SizeMode?.RAW ?? sprite.sizeMode;
          holderChild.parent = holder;
          // Where it goes in the card's draw order.
          if (after && typeof after.getSiblingIndex === `function`) holderChild.setSiblingIndex?.(after.getSiblingIndex() + 1);
          else if (after === 0) holderChild.setSiblingIndex?.(0);
          holderChild.layer = node.layer ?? holderChild.layer;
          holderChild.__gtBase = base;
          holderChild.setPosition?.(base.x + shift.x, base.y + shift.y, base.z);
          const factor = (picture.height ? (PACKET_H * (scale ?? packetScales.get(type) ?? 1)) / picture.height : 1);
          holderChild.setScale?.(factor, factor, 1);
          sprites.push({ sprite, from: tintFrom });
          return holderChild;
        };
        if (back) place(`gtPacketBack`, back, bgNode ?? 0, bg ?? db);
        const plantPicture = plant ? place(`gtPacket`, plant, node, db) : null;
        if (front) place(`gtPacketFront`, front, plantPicture ?? node, bg ?? db);
        holder.__gtCard = { hidden, sprites };
        tintCard(holder);
        packets++;
        return `packet`;
      } catch (err) {
        e.log.error(`[Textures] Couldn't put a picture on that packet: ${err.message}`);
        return null;
      }
    };

    // Cards are pooled exactly like plants: the card that showed a custom
    // packet is rebuilt for some other plant a moment later. Taking the
    // pictures off is not enough -- whatever was switched off under them has
    // to come back, or every card that object is reused for comes up blank.
    const undressCard = (card) => {
      const { db, holder } = cardNodes(card);
      if (!holder) return;
      try {
        for (const old of cardPictures(holder)) old.destroy?.();
        for (const comp of holder.__gtCard?.hidden ?? []) comp.enabled = true;
        holder.__gtCard = null;
        // Hidden by 0.17 and before.
        if (db?.__gtHidden) {
          db.enabled = true;
          db.__gtHidden = false;
          db.__gtSprite = null;
        }
      } catch (err) { /* card mid-build */ }
    };

    // A packet greys out while it recharges or can't be afforded, and the
    // chooser dims the ones already picked. The picture follows the art it
    // stands in for, or it would be the one card on the bar that never dims.
    const tint = (db) => {
      const sprite = db?.__gtSprite;
      const from = db?.color;
      if (!sprite || !from) return;
      const to = sprite.color;
      if (to && to.r === from.r && to.g === from.g && to.b === from.b && to.a === from.a) return;
      try {
        sprite.color = from.clone ? from.clone() : { ...from };
      } catch (err) { /* keep whatever it had */ }
    };
    // The card's pictures follow what they stand in for: the plant art dims
    // with the plant, background and border with the background.
    const tintCard = (holder) => {
      for (const { sprite, from } of holder?.__gtCard?.sprites ?? []) {
        const c = from?.color;
        const to = sprite?.color;
        if (!c || (to && to.r === c.r && to.g === c.g && to.b === c.b && to.a === c.a)) continue;
        try {
          sprite.color = c.clone ? c.clone() : { ...c };
        } catch (err) { /* keep whatever it had */ }
      }
    };
    const CardLook = getModule(`CardSelectAlmanac`)?.CardSelectAlmanac;
    if (CardLook?.prototype?.update) {
      e.unsafe.hooks.wrapMethod({
        target: CardLook.prototype,
        methodName: `update`,
        handler: ({ args, thisArg, callNext }) => {
          const result = callNext(...args);
          try {
            const holder = thisArg?._plantDB?.node?.parent ?? thisArg?.node;
            if (holder?.__gtCard) tintCard(holder);
          } catch (err) { /* card mid-build */ }
          return result;
        },
      });
    }

    const packetTextures = new Map(); // codename -> Texture2D
    const packetScales = new Map();
    // Every card this mod has dressed, so a size change shows at once rather
    // than waiting for the chooser to rebuild.
    const dressedCards = new Set();
    // Every card built lately, dressed or not: the packet editor draws one
    // behind your picture and puts its live preview on them.
    const seenCards = new Set();
    const SEEN_CARDS = 60;
    // A card's size, in the space the packet pictures go in: from the plant
    // art's position, y down. Read off the first card built and kept, so the
    // editor has it even with no card on screen.
    let cardRectSeen = null;
    const measureCard = (card) => {
      try {
        const { art, holder } = cardNodes(card);
        const ui = holder?._uiProps?.uiTransformComp ?? (cc.UITransform ? holder?.getComponent?.(cc.UITransform) : null);
        const size = ui?.contentSize;
        const anchor = ui?.anchorPoint ?? { x: 0.5, y: 0.5 };
        if (!art || !(size?.width > 10) || !(size?.height > 10)) return null;
        const pos = art.position ?? { x: 0, y: 0 };
        const rect = {
          x: Math.round(-anchor.x * size.width - (pos.x ?? 0)),
          y: Math.round((pos.y ?? 0) - (1 - anchor.y) * size.height),
          w: Math.round(size.width),
          h: Math.round(size.height),
        };
        if (!cardRectSeen || JSON.stringify(rect) !== JSON.stringify(cardRectSeen)) {
          cardRectSeen = rect;
          try {
            setLocal(`option:cardrect`, JSON.stringify(rect));
          } catch (err) { /* measured again next time */ }
        }
        return rect;
      } catch (err) {
        return null;
      }
    };
    const liveCards = () => {
      for (const card of seenCards) {
        const node = (card?.ca?._plantDB ?? card?._plantDB)?.node;
        if (!node || node.isValid === false) seenCards.delete(card);
      }
      return [...seenCards];
    };

    if (CardFeature?.prototype?.cardGrouperPlant) {
      e.unsafe.hooks.wrapMethod({
        target: CardFeature.prototype,
        methodName: `cardGrouperPlant`,
        handler: ({ args, thisArg, callNext }) => {
          // Undressed first, so the build runs on a card that is its own.
          try {
            undressCard(thisArg);
            dressedCards.delete(thisArg);
          } catch (err) { /* card mid-build */ }
          const result = callNext(...args);
          try {
            seenCards.delete(thisArg);
            seenCards.add(thisArg);
            if (seenCards.size > SEEN_CARDS) seenCards.delete(seenCards.values().next().value);
            if (!cardRectSeen) measureCard(thisArg);
            if (wantsCardLook(thisArg?.Type)) {
              dressCard(thisArg, packetTextures.get(thisArg.Type), packetScales.get(thisArg.Type));
              dressedCards.add(thisArg);
            }
          } catch (err) { /* card mid-build */ }
          return result;
        },
      });
    } else {
      e.log.error(`[Textures] No CardFeature.cardGrouperPlant -- seed packet pictures are off.`);
    }

    // Packets are wanted before any of that plant is on the lawn, so they
    // load from storage at startup rather than waiting for a level.
    const loadScales = () => {
      const sign = Number(stored(`option:rigysign`));
      if (sign === 1 || sign === -1) rigYSign = sign;
      for (const [key, value] of Object.entries(saved())) {
        const number = Number(value);
        if (!Number.isFinite(number)) continue;
        if (key.startsWith(`packetscale:`)) packetScales.set(key.slice(`packetscale:`.length), number);
        if (key.startsWith(`stillscale:`)) stillScales.set(key.slice(`stillscale:`.length), number);
      }
      for (const [key, value] of Object.entries(saved())) {
        const [x, y] = String(value).split(`,`).map(Number);
        if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
        if (key.startsWith(`stilloffset:`)) stillOffsets.set(key.slice(`stilloffset:`.length), { x, y });
        if (key.startsWith(`packetoffset:`)) packetOffsets.set(key.slice(`packetoffset:`.length), { x, y });
      }
    };

    const PACKET_MAPS = { packet: packetTextures, packetback: packetBacks, packetfront: packetFronts };
    const loadPackets = () => {
      if (!cardRectSeen) {
        try {
          cardRectSeen = JSON.parse(stored(`option:cardrect`) ?? `null`);
        } catch (err) { /* measured from the first card */ }
      }
      for (const [key, value] of Object.entries(saved())) {
        const [scope, codename] = key.split(`:`);
        if (scope === `packetproj`) {
          try {
            const card = JSON.parse(value)?.card;
            if (card) packetLooks.set(codename, { hideBg: !!card.hideBg, hidePlate: !!card.hidePlate, hideFamily: !!card.hideFamily });
          } catch (err) { /* layers only */ }
          continue;
        }
        const map = PACKET_MAPS[scope];
        if (!map || !codename || map.has(codename)) continue;
        map.set(codename, null);
        imageFrom(value)
          .then((imageAsset) => map.set(codename, textureFrom(imageAsset)))
          .catch((err) => e.log.error(`[Textures] ${codename}'s ${scope} picture wouldn't load: ${err.message}`));
      }
    };

    // Sizes: kept in storage and put straight onto what is already showing.
    const STILL_STEP = 0.15;
    const PACKET_STEP = 0.1;
    const setStillScale = (codename, tiles) => {
      const size = Math.min(6, Math.max(0.2, Math.round(tiles * 100) / 100));
      stillScales.set(codename, size);
      remember(`stillscale:${codename}`, String(size));
      const dataUrl = saved()[`still:${codename}`];
      if (dataUrl) applyKey(`still:${codename}`, dataUrl).catch(() => { /* next pass */ });
      return size;
    };
    const setPacketScale = (codename, factor) => {
      const size = Math.min(4, Math.max(0.2, Math.round(factor * 100) / 100));
      packetScales.set(codename, size);
      remember(`packetscale:${codename}`, String(size));
      const tex = packetTextures.get(codename);
      for (const card of dressedCards) {
        try {
          if (card?.Type === codename && wantsCardLook(codename)) dressCard(card, tex, size);
        } catch (err) { /* card is gone */ }
      }
      return size;
    };


    const OFFSET_RANGE = { still: 80, packet: 40 };
    const clampOffset = (v, range) => Math.max(-range, Math.min(range, Math.round(Number(v) || 0)));
    const moveTo = (node, shift) => {
      const base = node?.__gtBase;
      if (!base) return;
      node.setPosition?.(base.x + shift.x, base.y + shift.y, base.z);
    };
    const setStillOffset = (codename, x, y) => {
      const shift = { x: clampOffset(x, OFFSET_RANGE.still), y: clampOffset(y, OFFSET_RANGE.still) };
      stillOffsets.set(codename, shift);
      remember(`stilloffset:${codename}`, `${shift.x},${shift.y}`);
      for (const plant of plantRows().find((r) => r.codename === codename)?.plants ?? []) {
        if (plant.__gtStill) moveTo(plant.__gtStill, shift);
      }
      for (const shown of displays) {
        if (shown.__gtStill && codenameOf(shown) === codename) moveTo(shown.__gtStill, shift);
      }
      return shift;
    };
    const setPacketOffset = (codename, x, y) => {
      const shift = { x: clampOffset(x, OFFSET_RANGE.packet), y: clampOffset(y, OFFSET_RANGE.packet) };
      packetOffsets.set(codename, shift);
      remember(`packetoffset:${codename}`, `${shift.x},${shift.y}`);
      for (const card of dressedCards) {
        if (card?.Type !== codename) continue;
        const holder = (card?.ca?._plantDB ?? card?._plantDB)?.node?.parent;
        for (const picture of cardPictures(holder)) moveTo(picture, shift);
      }
      return shift;
    };

    const setPacket = (codename, label) => pickFile((dataUrl, filename) => {
      imageFrom(dataUrl)
        .then((imageAsset) => {
          packetTextures.set(codename, textureFrom(imageAsset));
          remember(`packet:${codename}`, dataUrl);
          e.log.info(`[Textures] ${label}: packet picture set to ${filename}. Reopen the seed chooser to see it.`);
          drawPanel();
        })
        .catch((err) => e.log.error(`[Textures] ${label}: ${err.message}`));
    });


    // ==================================================================
    // Building a rig
    //
    // Fitting art to a borrowed rig gets the pieces in the right places but
    // leaves them moving like the plant they were borrowed from. A rig of
    // your own is the way out: lay the pieces out, and this writes the
    // DragonBones skeleton for them -- one bone and one slot per piece, the
    // layout as the rest pose, and animations generated from it.
    //
    // DragonBones stores y downward, the way Flash did. If a built rig comes
    // out upside down on a build, rigFlip() turns the sign over and rebuilds.
    // ==================================================================
    // DragonBones data is y-down, like the editor's stage, so a rig goes
    // across as laid out. If some build draws it upside down after all, the
    // editor's flip button (or rigFlip()) mirrors every position and turn,
    // and the choice is kept.
    let rigYSign = 1;
    const RIG_FPS = 24;

    // ---- pieces ----
    // A piece: a box on the sheet, a name, where it stands in the rest pose
    // (x, y from the ground point, turn in degrees), its size and flip, the
    // point it turns about (pivotX/pivotY as fractions of the box, 0.5/1 is
    // the middle of its base), what it's attached to, and how it moves.
    const slug = (text, fallback) => String(text ?? ``).trim().toLowerCase()
      .replace(/[^a-z0-9]+/g, `_`).replace(/^_+|_+$/g, ``) || fallback;
    const keyPieces = (pieces) => {
      // "root" is the bone everything hangs from.
      const used = new Set([`root`]);
      return pieces.map((piece, index) => {
        let key = piece.key ?? slug(piece.name, `piece${index + 1}`);
        if (used.has(key)) {
          let n = 2;
          while (used.has(`${key}_${n}`)) n++;
          key = `${key}_${n}`;
        }
        used.add(key);
        return { ...piece, key };
      });
    };
    const pivotOf = (piece) => ({ x: piece.pivotX ?? 0.5, y: piece.pivotY ?? piece.pivot ?? 1 });

    // 2D transforms as canvas matrices [a, b, c, d, e, f].
    const M = {
      at: (x, y, deg) => {
        const r = (deg * Math.PI) / 180;
        return [Math.cos(r), Math.sin(r), -Math.sin(r), Math.cos(r), x, y];
      },
      mul: (m, n) => [
        m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
        m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
        m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5],
      ],
      inv: (m) => {
        const det = m[0] * m[3] - m[1] * m[2] || 1;
        return [m[3] / det, -m[1] / det, -m[2] / det, m[0] / det,
          (m[2] * m[5] - m[3] * m[4]) / det, (m[1] * m[4] - m[0] * m[5]) / det];
      },
      scale: (m, sx, sy) => [m[0] * sx, m[1] * sx, m[2] * sy, m[3] * sy, m[4], m[5]],
      angle: (m) => (Math.atan2(m[1], m[0]) * 180) / Math.PI,
    };

    // Parent of each piece by index, with loops and strays cut: a piece
    // can't hang off itself or off something hanging off it.
    const parentsOf = (pieces) => {
      const byId = new Map(pieces.map((piece, index) => [piece.id ?? `#${index}`, index]));
      return pieces.map((piece, index) => {
        let parent = piece.parent == null ? -1 : byId.get(piece.parent) ?? -1;
        for (let at = parent, depth = 0; at >= 0; at = byId.get(pieces[at].parent) ?? -1, depth++) {
          if (at === index || depth > pieces.length) {
            parent = -1;
            break;
          }
        }
        return parent;
      });
    };
    // Bones have to be listed parents first.
    const boneOrder = (parents) => {
      const order = [];
      const placed = new Set();
      const place = (index) => {
        if (placed.has(index)) return;
        if (parents[index] >= 0) place(parents[index]);
        placed.add(index);
        order.push(index);
      };
      parents.forEach((_, index) => place(index));
      return order;
    };

    // ---- motion ----
    // The clips a plant is asked to play come from the plant itself: its
    // own skeleton lists them, with their length and the frame events the
    // game listens for (Laser Bean fires on "shoot", a Peashooter on its own
    // name for it). A rig that copies those keeps the plant attacking, and
    // one that has a death clip dies like any other plant.
    // Read from the skeleton json when the asset still has it. In the game
    // it usually doesn't: the json is dropped once parsed, and before 0.15
    // that sent every rig out with three stock clips and no events, so a
    // rigged Chomper never bit. So the loaded armature is read too, which
    // always has them: each clip's length and loop count, and its events
    // from the action timeline, the same arrays the runtime fires them from.
    const fromJson = (plant, db) => {
      const ske = plant?.__gtWasSkeleton ?? db?.dragonAsset;
      let json = ske?.dragonBonesJson ?? ske?._dragonBonesJson;
      if (typeof json === `string`) json = JSON.parse(json);
      const wanted = plant?.__gtWasArmatureName ?? db?.armatureName;
      const arm = json?.armature?.find((a) => a.name === wanted) ?? json?.armature?.[0];
      const fps = arm?.frameRate ?? json?.frameRate ?? RIG_FPS;
      const clips = (arm?.animation ?? []).filter((clip) => clip?.name).map((clip) => ({
        name: clip.name,
        duration: Math.max(1, Math.round(clip.duration ?? fps)),
        playTimes: clip.playTimes ?? 1,
        frame: Array.isArray(clip.frame) && clip.frame.length ? clip.frame : null,
      }));
      return clips.length ? { fps, clips, from: `json` } : null;
    };
    const TIMELINE_KEYS = 2; // BinaryOffset.TimelineKeyFrameCount
    const TIMELINE_FRAMES = 5; // BinaryOffset.TimelineFrameOffset
    const eventFrames = (anim, length) => {
      const timeline = anim?.actionTimeline;
      const armData = anim?.parent;
      const data = armData?.parent;
      const tl = data?.timelineArray;
      const fr = data?.frameArray;
      const actions = armData?.actions;
      if (!timeline || !tl || !fr || !actions) return null;
      const marks = new Map(); // frame -> { events, sound }
      const count = tl[timeline.offset + TIMELINE_KEYS] ?? 0;
      for (let i = 0; i < count; i++) {
        const at = anim.frameOffset + tl[timeline.offset + TIMELINE_FRAMES + i];
        const pos = fr[at];
        const n = fr[at + 1] ?? 0;
        for (let j = 0; j < n; j++) {
          const act = actions[fr[at + 2 + j]];
          if (!act?.name || (act.type !== 10 && act.type !== 11)) continue; // Frame, Sound
          const mark = marks.get(pos) ?? { events: [], sound: null };
          if (act.type === 11) mark.sound = act.name;
          else mark.events.push({ name: act.name });
          marks.set(pos, mark);
        }
      }
      if (!marks.size) return null;
      const starts = [...marks.keys()].sort((x, y) => x - y);
      const out = starts[0] > 0 ? [{ duration: starts[0] }] : [];
      starts.forEach((at, i) => {
        const mark = marks.get(at);
        const frame = { duration: Math.max(0, (starts[i + 1] ?? length) - at) };
        if (mark.events.length) frame.events = mark.events;
        if (mark.sound) frame.sound = mark.sound;
        out.push(frame);
      });
      return out;
    };
    const fromArmature = (db) => {
      const arm = db?.armature?.() ?? db?._armature;
      const data = arm?.armatureData ?? arm?._armatureData;
      const anims = data?.animations ?? arm?.animation?._animations;
      if (!anims) return null;
      const fps = data?.frameRate || RIG_FPS;
      const clips = [];
      for (const name of data?.animationNames ?? Object.keys(anims)) {
        const anim = anims[name];
        if (!anim || typeof anim !== `object`) continue;
        const length = Math.max(1, Math.round(anim.frameCount ?? (anim.duration ?? 1) * fps));
        let frame = null;
        try {
          frame = eventFrames(anim, length);
        } catch (err) { /* no events read */ }
        clips.push({ name, duration: length, playTimes: anim.playTimes ?? 1, frame });
      }
      return clips.length ? { fps, clips, from: `armature` } : null;
    };
    // Kept per plant kind: once a rig is on, the loaded armature is the rig's.
    const templates = new Map();
    const vanillaClips = (plant) => {
      const codename = plant ? codenameOf(plant) : null;
      if (codename && templates.has(codename)) return templates.get(codename);
      const db = plant?.db ?? plant?.anmControl?.db;
      let found = null;
      try {
        found = fromJson(plant, db);
      } catch (err) { /* try the armature */ }
      const own = plant?.__gtWasSkeleton === undefined;
      if (!found?.clips.some((c) => c.frame) && own) {
        try {
          found = fromArmature(db) ?? found;
        } catch (err) { /* stock clips */ }
      }
      if (found && codename && (own || found.from === `json`)) {
        templates.set(codename, found);
        const fired = found.clips.filter((c) => c.frame?.some((f) => f.events?.length));
        e.log.info(`[Textures] ${codename}: ${found.clips.length} clips read from its ${found.from}, events in ${fired.map((c) => c.name).join(`|`) || `none`}.`);
      }
      return found;
    };
    const DEFAULT_CLIPS = [
      { name: `Idle`, duration: 0, playTimes: 0, frame: null },
      { name: `Shoot`, duration: 16, playTimes: 1, frame: null },
      { name: `Food`, duration: 0, playTimes: 1, frame: null },
    ];
    // When the game plays a clip, by name, in plain words.
    const CLIP_NOTES = [
      [/^idle$/i, `Standing about. Plays over and over.`],
      [/^rand\d*$/i, `A fidget, played now and then instead of Idle.`],
      [/^attackempty$/i, `A bite at nothing: the zombie got away or was too big.`],
      [/^attackchewstart$/i, `Starts chewing a zombie it caught.`],
      [/^chewing$/i, `Chewing, over and over, while a zombie is in its mouth.`],
      [/^chewend$/i, `Swallows, then goes back to Idle.`],
      [/^(attack|shoot|fire)$/i, `Attacking. The game acts on its events, so land the hit on them.`],
      [/^food/i, `Plant Food: plays while it's powered up.`],
      [/^water/i, `Being watered in the Zen Garden.`],
      [/^(death|die|dead)/i, `Dying. The plant is removed when it ends.`],
      [/^(spawn|plant|grow)/i, `Being planted or growing in.`],
    ];
    const clipNote = (name, codename) => {
      const act = (globalThis.GreenhouseActs?.[codename] ?? []).find((a) => a?.name === name);
      if (act?.when) return `${act.by ?? `Another pack`} plays this when ${act.when}.`;
      return CLIP_NOTES.find(([test]) => test.test(name))?.[1] ?? null;
    };
    const clipKind = (name) => (/die|death|dead/i.test(name) ? `death`
      : /food|special|power|plantfood/i.test(name) ? `food`
        : /shoot|attack|fire|lob|throw|stab|smash|bite|chomp|launch|kick|charge|spit|blow/i.test(name) ? `attack`
          : `idle`);
    // Loops a piece can run. Each is a curve over one cycle; the rig's speed
    // sets how long a cycle is, "How much" how big.
    const MOTIONS = [`sway`, `bob`, `pulse`, `squash`, `wiggle`, `float`, `bounce`, `shake`, `spin`, `flap`, `nod`, `custom`, `still`];
    const MOTION_LABELS = {
      sway: `Sways side to side`,
      bob: `Bobs up and down`,
      pulse: `Breathes in and out`,
      squash: `Squashes and stretches`,
      wiggle: `Wiggles`,
      float: `Floats`,
      bounce: `Bounces`,
      shake: `Shakes`,
      spin: `Spins round`,
      flap: `Flaps`,
      nod: `Nods`,
      custom: `My own keyframes`,
      still: `Holds still`,
    };
    // What each loop does to a turn (degrees), a move (x, y) and a size
    // (x, y), at angle t through the cycle for a strength a. freq is how
    // many times it repeats per cycle, so fast loops still close cleanly.
    const LOOPS = {
      sway: { freq: 1, rotate: (t, a) => a * Math.cos(t) },
      bob: { freq: 1, move: (t, a) => [0, 3 * a * Math.cos(t)] },
      pulse: { freq: 1, size: (t, a) => [1 + 0.02 * a * Math.cos(t), 1 + 0.02 * a * Math.cos(t)] },
      squash: { freq: 1, size: (t, a) => [1 + 0.03 * a * Math.cos(t), 1 - 0.03 * a * Math.cos(t)] },
      wiggle: { freq: 3, rotate: (t, a) => 0.6 * a * Math.cos(t) },
      float: { freq: 1, move: (t, a) => [0, 2.5 * a * Math.cos(t)], rotate: (t, a) => 0.4 * a * Math.sin(t) },
      bounce: { freq: 1, move: (t, a) => [0, -6 * a * Math.abs(Math.sin(t / 2))] },
      shake: { freq: 4, move: (t, a) => [1.5 * a * Math.cos(t), 0] },
      spin: { freq: 1, rotate: (t) => (t * 180) / Math.PI },
      flap: { freq: 2, rotate: (t, a) => 1.25 * a * (1 + Math.cos(t)) },
      nod: { freq: 1, rotate: (t, a) => 0.75 * a * (1 - Math.cos(t)) },
    };
    const TURNS = new Set([`sway`, `wiggle`, `float`, `spin`, `flap`, `nod`, `custom`]);
    const HOPS = new Set([`bob`, `bounce`, `shake`]);

    // A keyframe loop: keys at t from 0 to 1, each a pose on top of the rest
    // pose (turn, move x/y, stretch w/h), linear between keys and wrapping
    // from the last back to the first.
    const REST_KEY = { rotate: 0, x: 0, y: 0, sx: 1, sy: 1 };
    const keyAt = (keys, t) => {
      if (!keys?.length) return REST_KEY;
      const sorted = [...keys].sort((a, b) => a.t - b.t);
      const u = ((t % 1) + 1) % 1;
      let before = sorted[sorted.length - 1];
      let after = sorted[0];
      for (const key of sorted) {
        if (key.t <= u) before = key;
      }
      for (const key of sorted) {
        if (key.t > u) {
          after = key;
          break;
        }
      }
      const span = ((after.t - before.t) + 1) % 1 || 1;
      const k = sorted.length === 1 ? 0 : (((u - before.t) + 1) % 1) / span;
      const mix = (field) => (before[field] ?? REST_KEY[field]) + ((after[field] ?? REST_KEY[field]) - (before[field] ?? REST_KEY[field])) * k;
      return { rotate: mix(`rotate`), x: mix(`x`), y: mix(`y`), sx: mix(`sx`), sy: mix(`sy`) };
    };

    // Rows are [frame, ...values]; one row per sample.
    const loopRows = (duration, cycles, sample) => {
      const steps = Math.max(1, cycles) * 8;
      const rows = [];
      for (let k = 0; k <= steps; k++) {
        const frame = Math.round((k * duration) / steps);
        if (rows.length && rows[rows.length - 1][0] === frame) continue;
        rows.push([frame, ...[].concat(sample((k / steps) * Math.max(1, cycles) * Math.PI * 2))]);
      }
      return rows;
    };
    // A keyframe loop laid over a clip: a row at every key, every cycle,
    // shifted by the piece's phase, so nothing between keys is rounded off.
    const keyRows = (duration, cycles, keys, shift, strength, pick) => {
      const times = new Set([0, 1]);
      for (const key of keys) times.add((((key.t - shift) % 1) + 1) % 1);
      const once = [...times].sort((a, b) => a - b);
      const rows = [];
      for (let c = 0; c < cycles; c++) {
        for (const t of once) {
          if (c > 0 && t === 0) continue;
          const frame = Math.round(((c + t) / cycles) * duration);
          if (rows.length && rows[rows.length - 1][0] === frame) continue;
          rows.push([frame, ...pick(keyAt(keys, t + shift), strength)]);
        }
      }
      return rows;
    };

    // Everything a clip does, in the editor's own terms (y down, degrees
    // clockwise): per piece, keyframes for turn, move and size. Both the
    // skeleton and the editor's preview are made from this, so what plays
    // in the editor is what plays in the game.
    const rigMotion = (pieces, { sway = 3, speed = 1, style = `alternate`, template = null, anim = null, clips: ownClips = null } = {}) => {
      const fps = template?.fps ?? RIG_FPS;
      const period = Math.max(4, Math.round((2 / Math.max(0.25, speed)) * fps));
      const parents = parentsOf(pieces);
      // Pieces in a sync group share one timing: the phase of the first of
      // them, or half a cycle off it for a piece set to mirror the rest. A
      // keyframe loop keeps its own timing unless it is synced.
      const ownPhase = (index) => {
        if (pieces[index]?.motion === `custom`) return 0;
        return style === `wave` ? index * 0.7 : (index % 2) * Math.PI;
      };
      const phases = pieces.map((piece, index) => {
        if (!piece.sync) return ownPhase(index);
        const leader = pieces.findIndex((other) => other.sync === piece.sync);
        return ownPhase(leader) + (piece.syncOpposite ? Math.PI : 0);
      });
      // The plant's own clips, then any made in the editor. Those are played by
      // name: by the game if it has a clip of that name, or by another pack
      // (see GreenhouseActs: a plant pack can list clips it plays).
      const base = template?.clips ?? DEFAULT_CLIPS;
      const taken = new Set(base.map((c) => c.name));
      const extra = (ownClips ?? []).filter((c) => c?.name && !taken.has(c.name))
        .map((c) => ({ name: c.name, duration: Math.max(2, Math.round(c.length ?? RIG_FPS)), playTimes: c.loops ? 0 : 1, frame: null, custom: true }));
      const clips = [...base, ...extra].map((clip) => {
        const kind = clipKind(clip.name);
        const loops = clip.playTimes === 0;
        // A loop with nothing timed in it takes the editor's speed. Anything
        // with events, or played once, keeps the length the game expects.
        let duration = clip.duration;
        if (!clip.custom && (!duration || (loops && !clip.frame && kind === `idle`))) duration = kind === `food` ? Math.round(period / 2) : period;
        // A length set in the editor, for a clip the game doesn't time by its
        // events: those keep the length their events are placed in.
        const own = anim?.[clip.name];
        if (own?.length && !clip.frame) duration = Math.max(2, Math.round(own.length));
        const cycles = Math.max(1, Math.round(duration / period));
        const bones = pieces.map((piece, index) => {
          const motion = MOTIONS.includes(piece.motion) ? piece.motion : `sway`;
          const amount = sway * (piece.amount ?? 1);
          const phase = phases[index];
          const out = {};
          if (motion === `still`) return out;
          const root = parents[index] < 0;
          if (kind === `idle` || kind === `food`) {
            const food = kind === `food`;
            const count = food ? cycles * 2 : cycles;
            if (motion === `custom`) {
              const keys = piece.keys ?? [];
              if (!keys.length) return out;
              const k = (piece.amount ?? 1) * (food ? 1.5 : 1);
              const shift = phase / (Math.PI * 2);
              out.rotate = keyRows(duration, count, keys, shift, k, (p, s) => [p.rotate * s]);
              out.move = keyRows(duration, count, keys, shift, k, (p, s) => [p.x * s, p.y * s]);
              out.size = keyRows(duration, count, keys, shift, k, (p, s) => [1 + (p.sx - 1) * s, 1 + (p.sy - 1) * s]);
              return out;
            }
            const loop = LOOPS[motion];
            if (!loop || !amount) return out;
            const a = amount * (food ? 2.5 : 1);
            const n = count * loop.freq;
            if (loop.rotate) out.rotate = loopRows(duration, n, (t) => loop.rotate(t + phase, a));
            if (loop.move) out.move = loopRows(duration, n, (t) => loop.move(t + phase, a));
            if (loop.size) out.size = loopRows(duration, n, (t) => loop.size(t + phase, a));
          } else if (kind === `attack`) {
            // A lean back and a snap forward from the base, what hangs off
            // it following through a beat later; a hop for pieces that move
            // rather than turn; a squash for pieces that breathe.
            const d = duration;
            const a = amount || sway;
            if (TURNS.has(motion)) {
              out.rotate = root
                ? [[0, 0], [Math.round(d * 0.25), -a * 3], [Math.round(d * 0.5), a], [d, 0]]
                : [[0, 0], [Math.round(d * 0.35), a * 1.5], [d, 0]];
            } else if (HOPS.has(motion)) {
              out.move = [[0, 0, 0], [Math.round(d * 0.25), 0, -2 * a], [d, 0, 0]];
            } else {
              const k = 0.03 * a;
              out.size = [[0, 1, 1], [Math.round(d * 0.25), 1 + k, 1 - k], [d, 1, 1]];
            }
          } else if (kind === `death` && root) {
            out.size = [[0, 1, 1], [duration, 0.05, 0.05]];
            out.rotate = [[0, 0], [duration, 15]];
          }
          return out;
        });
        // Then the clip's triggers, on top of each piece's loop, or on
        // their own where the loop is switched off in this clip.
        const triggers = clipTriggers(own, pieces);
        const off = loopsOff(own);
        pieces.forEach((piece, index) => {
          const base = off.has(piece.id) ? {} : bones[index];
          const mine = triggers.filter((t) => t.targets?.includes(piece.id));
          bones[index] = mine.length ? triggerBone(mine, duration, !!piece.hidden, base) : base;
        });
        return { name: clip.name, duration, playTimes: clip.playTimes ?? 1, frame: clip.frame, bones };
      });
      return { fps, clips, parents };
    };

    // One value of one track at a frame: column 1 is the first value.
    const sampleTrack = (rows, frame, rest, column = 1) => {
      if (!rows?.length) return rest;
      if (frame <= rows[0][0]) return rows[0][column];
      for (let i = 1; i < rows.length; i++) {
        const f1 = rows[i][0];
        if (frame <= f1) {
          const f0 = rows[i - 1][0];
          const v0 = rows[i - 1][column];
          const v1 = rows[i][column];
          if (rows[i - 1].step) return frame < f1 ? v0 : v1;
          return f1 === f0 ? v1 : v0 + ((v1 - v0) * (frame - f0)) / (f1 - f0);
        }
      }
      return rows[rows.length - 1][column];
    };

    // ---- triggers: what a clip does, Geometry Dash style ----
    // A clip is a list of triggers. Each starts on a frame, lasts some
    // frames, has an easing, and acts on one or more pieces:
    //   Move    by x, y (in the piece's parent's space)
    //   Rotate  by r degrees
    //   Scale   by sx, sy
    //   Alpha   to a, from wherever it was
    //   Show, Hide, Picture: on their frame, no duration
    // Move, Rotate and Scale add up like GD's do: two Moves at once move by
    // both. They also add to the piece's loop (sway, bob...) unless the loop
    // is switched off in that clip.
    // It all bakes to a row a frame, so any ease the editor draws is one the
    // game plays. DragonBones only tweens in straight lines between rows.
    const TRIGGERS = [`move`, `rotate`, `scale`, `alpha`, `show`, `hide`, `picture`];
    const TRIGGER_LABELS = { move: `Move`, rotate: `Rotate`, scale: `Scale`, alpha: `Alpha`, show: `Show`, hide: `Hide`, picture: `Picture` };
    const TRIGGER_REST = { move: { x: 0, y: 0 }, rotate: { r: 0 }, scale: { sx: 1, sy: 1 }, alpha: { a: 0 }, show: {}, hide: {}, picture: { img: null } };
    // A slot showing nothing: DragonBones' display index -1.
    const HIDE = `!hide`;
    const INSTANT = new Set([`show`, `hide`, `picture`]);
    // Move, Rotate and Scale on a parent carry its children along, so those
    // only need the top piece. The rest act on each slot by itself.
    const CARRIES = new Set([`move`, `rotate`, `scale`]);
    const EASES = [
      `none`, `inout`, `in`, `out`,
      `sineinout`, `sinein`, `sineout`,
      `expoinout`, `expoin`, `expoout`,
      `elasticinout`, `elasticin`, `elasticout`,
      `bounceinout`, `bouncein`, `bounceout`,
      `backinout`, `backin`, `backout`,
    ];
    const EASE_LABELS = {
      none: `None`, inout: `Ease In Out`, in: `Ease In`, out: `Ease Out`,
      sineinout: `Sine In Out`, sinein: `Sine In`, sineout: `Sine Out`,
      expoinout: `Exponential In Out`, expoin: `Exponential In`, expoout: `Exponential Out`,
      elasticinout: `Elastic In Out`, elasticin: `Elastic In`, elasticout: `Elastic Out`,
      bounceinout: `Bounce In Out`, bouncein: `Bounce In`, bounceout: `Bounce Out`,
      backinout: `Back In Out`, backin: `Back In`, backout: `Back Out`,
    };
    // The plain eases take a rate, as GD's do: 2 is a gentle curve.
    const RATED = new Set([`in`, `out`, `inout`]);
    const bounceOut = (u) => {
      const n = 7.5625;
      const d = 2.75;
      if (u < 1 / d) return n * u * u;
      if (u < 2 / d) return n * (u - 1.5 / d) ** 2 + 0.75;
      if (u < 2.5 / d) return n * (u - 2.25 / d) ** 2 + 0.9375;
      return n * (u - 2.625 / d) ** 2 + 0.984375;
    };
    const BACK = 1.70158;
    const ELASTIC = (2 * Math.PI) / 3;
    const eased = (ease, u, rate = 2) => {
      const k = Math.max(0.1, rate || 2);
      switch (ease) {
        case `in`: return u ** k;
        case `out`: return 1 - (1 - u) ** k;
        case `inout`: return u < 0.5 ? (2 * u) ** k / 2 : 1 - (2 * (1 - u)) ** k / 2;
        case `sinein`: return 1 - Math.cos((u * Math.PI) / 2);
        case `sineout`: return Math.sin((u * Math.PI) / 2);
        case `sineinout`: return (1 - Math.cos(Math.PI * u)) / 2;
        case `expoin`: return u <= 0 ? 0 : 2 ** (10 * u - 10);
        case `expoout`: return u >= 1 ? 1 : 1 - 2 ** (-10 * u);
        case `expoinout`:
          if (u <= 0 || u >= 1) return u <= 0 ? 0 : 1;
          return u < 0.5 ? 2 ** (20 * u - 10) / 2 : (2 - 2 ** (-20 * u + 10)) / 2;
        case `elasticin`:
          if (u <= 0 || u >= 1) return u <= 0 ? 0 : 1;
          return -(2 ** (10 * u - 10)) * Math.sin((u * 10 - 10.75) * ELASTIC);
        case `elasticout`:
          if (u <= 0 || u >= 1) return u <= 0 ? 0 : 1;
          return 2 ** (-10 * u) * Math.sin((u * 10 - 0.75) * ELASTIC) + 1;
        case `elasticinout`: return u < 0.5 ? (1 - eased(`elasticout`, 1 - 2 * u)) / 2 : (1 + eased(`elasticout`, 2 * u - 1)) / 2;
        case `bouncein`: return 1 - bounceOut(1 - u);
        case `bounceout`: return bounceOut(u);
        case `bounceinout`: return u < 0.5 ? (1 - bounceOut(1 - 2 * u)) / 2 : (1 + bounceOut(2 * u - 1)) / 2;
        case `backin`: return (BACK + 1) * u ** 3 - BACK * u * u;
        case `backout`: return 1 + (BACK + 1) * (u - 1) ** 3 + BACK * (u - 1) ** 2;
        case `backinout`: return u < 0.5 ? (1 - eased(`backout`, 1 - 2 * u)) / 2 : (1 + eased(`backout`, 2 * u - 1)) / 2;
        default: return u;
      }
    };
    // How far through a trigger is at a frame, eased: 0 before, 1 after.
    const progressOf = (t, frame) => {
      if (frame < t.f) return 0;
      if (!(t.d > 0) || frame >= t.f + t.d) return 1;
      return eased(t.ease, (frame - t.f) / t.d, t.rate);
    };
    const byStart = (list) => [...list].sort((a, b) => a.f - b.f);
    // Alpha goes to a value, so each fade starts from what the fades before
    // it left, on its first frame.
    const alphaAt = (fades, frame) => {
      const from = [];
      let a = 1;
      fades.forEach((t, i) => {
        let start = 1;
        for (let j = 0; j < i; j++) {
          if (t.f >= fades[j].f) start = from[j] + ((fades[j].a ?? 1) - from[j]) * progressOf(fades[j], t.f);
        }
        from.push(start);
        if (frame >= t.f) a = start + ((t.a ?? 1) - start) * progressOf(t, frame);
      });
      return a;
    };
    // Where a piece's triggers have it at a frame, on top of its layout.
    const triggerState = (list, frame, restHidden = false) => {
      const s = { x: 0, y: 0, r: 0, sx: 1, sy: 1, a: 1, hidden: !!restHidden, img: null };
      const sorted = byStart(list);
      for (const t of sorted) {
        if (frame < t.f || t.type === `alpha`) continue;
        const p = progressOf(t, frame);
        if (t.type === `move`) {
          s.x += (t.x ?? 0) * p;
          s.y += (t.y ?? 0) * p;
        } else if (t.type === `rotate`) {
          s.r += (t.r ?? 0) * p;
        } else if (t.type === `scale`) {
          s.sx *= 1 + ((t.sx ?? 1) - 1) * p;
          s.sy *= 1 + ((t.sy ?? 1) - 1) * p;
        } else if (t.type === `hide`) {
          s.hidden = true;
        } else if (t.type === `show`) {
          s.hidden = false;
        } else if (t.type === `picture`) {
          s.img = t.img ?? null;
        }
      }
      s.a = alphaAt(sorted.filter((t) => t.type === `alpha`), frame);
      return s;
    };
    // A row flagged step holds its value until the next row: an instant
    // trigger jumps rather than sliding over a frame.
    const tidy = (rows) => {
      if (rows.length < 3) return rows;
      const out = [rows[0]];
      for (let i = 1; i < rows.length - 1; i++) {
        const a = out[out.length - 1];
        const b = rows[i];
        const c = rows[i + 1];
        const k = (b[0] - a[0]) / (c[0] - a[0]);
        const inLine = !a.step && !b.step && b.every((v, j) => j === 0 || Math.abs(a[j] + (c[j] - a[j]) * k - v) < 1e-6);
        if (!inLine) out.push(b);
      }
      out.push(rows[rows.length - 1]);
      return out;
    };
    // One piece's triggers in a clip, as the rows the preview and the
    // skeleton are both made from, laid over its loop (base).
    const triggerBone = (list, duration, restHidden = false, base = {}) => {
      const out = { ...base };
      const frames = Array.from({ length: duration + 1 }, (_, f) => f);
      const states = frames.map((f) => triggerState(list, f, restHidden));
      const uses = (...types) => list.some((t) => types.includes(t.type));
      const bake = (types, value) => {
        const jumps = new Set(list.filter((t) => types.includes(t.type) && !(t.d > 0) && t.f > 0).map((t) => t.f));
        return tidy(frames.map((f) => {
          const row = [f, ...value(f, states[f])];
          if (jumps.has(f + 1)) row.step = true;
          return row;
        }));
      };
      if (uses(`rotate`)) out.rotate = bake([`rotate`], (f, s) => [sampleTrack(base.rotate, f, 0) + s.r]);
      if (uses(`move`)) out.move = bake([`move`], (f, s) => [sampleTrack(base.move, f, 0, 1) + s.x, sampleTrack(base.move, f, 0, 2) + s.y]);
      if (uses(`scale`)) out.size = bake([`scale`], (f, s) => [sampleTrack(base.size, f, 1, 1) * s.sx, sampleTrack(base.size, f, 1, 2) * s.sy]);
      if (uses(`alpha`)) out.alpha = bake([`alpha`], (f, s) => [s.a]);
      if (uses(`show`, `hide`, `picture`)) {
        const value = (s) => (s.hidden ? HIDE : s.img);
        const rows = [[0, value(states[0])]];
        for (const f of frames) if (value(states[f]) !== rows[rows.length - 1][1]) rows.push([f, value(states[f])]);
        if (rows.length > 1 || rows[0][1] !== (restHidden ? HIDE : null)) out.show = rows;
      }
      return out;
    };

    // Keys from before triggers (0.16 and 0.17): a pose per key, eased into
    // the next. The same motion as triggers, one per change between keys.
    const KEY_REST = { x: 0, y: 0, r: 0, sx: 1, sy: 1, a: 1 };
    const OLD_EASE = { linear: `none`, in: `in`, out: `out`, inout: `sineinout` };
    const keysToTriggers = (keys, id, restHidden = false, tag = `k`) => {
      const list = byStart(keys ?? []);
      const out = [];
      if (!list.length) return out;
      const get = (k, field) => k[field] ?? KEY_REST[field];
      const add = (type, f, d, ease, fields) => out.push({ id: `${tag}${out.length}`, type, targets: [id], f, d, ease, rate: 2, ...fields });
      const ratio = (from, to) => (Math.abs(from) < 1e-6 ? to : to / from);
      const shift = (from, to, f, d, ease) => {
        const dx = get(to, `x`) - get(from, `x`);
        const dy = get(to, `y`) - get(from, `y`);
        if (dx || dy) add(`move`, f, d, ease, { x: dx, y: dy });
        const dr = get(to, `r`) - get(from, `r`);
        if (dr) add(`rotate`, f, d, ease, { r: dr });
        const sx = ratio(get(from, `sx`), get(to, `sx`));
        const sy = ratio(get(from, `sy`), get(to, `sy`));
        if (sx !== 1 || sy !== 1) add(`scale`, f, d, ease, { sx, sy });
        if (get(to, `a`) !== get(from, `a`)) add(`alpha`, f, d, ease, { a: get(to, `a`) });
      };
      shift(KEY_REST, list[0], 0, 0, `none`);
      let hidden = !!restHidden;
      let img = null;
      list.forEach((k, i) => {
        const at = i === 0 ? 0 : k.f;
        const hide = !!(k.hide ?? restHidden);
        if (hide !== hidden) add(hide ? `hide` : `show`, at, 0, `none`, {});
        hidden = hide;
        if ((k.img ?? null) !== img) add(`picture`, at, 0, `none`, { img: k.img ?? null });
        img = k.img ?? null;
        const next = list[i + 1];
        if (!next) return;
        const ease = k.ease ?? `linear`;
        if (ease === `hold`) shift(k, next, next.f, 0, `none`);
        else shift(k, next, k.f, next.f - k.f, OLD_EASE[ease] ?? `none`);
      });
      return out;
    };
    // A clip's triggers, with any old keys read as triggers too.
    const clipTriggers = (own, pieces) => {
      const out = [...(own?.triggers ?? [])];
      for (const [id, keys] of Object.entries(own?.tracks ?? {})) {
        const piece = pieces.find((p) => p.id === id);
        if (piece && keys?.length) out.push(...keysToTriggers(keys, id, !!piece.hidden, `k_${id}_`));
      }
      return out;
    };
    // Pieces whose loop doesn't play in a clip. Old keys replaced the loop,
    // so a piece that had them keeps it off.
    const loopsOff = (own) => new Set([
      ...(own?.loopOff ?? []),
      ...Object.keys(own?.tracks ?? {}).filter((id) => own.tracks[id]?.length),
    ]);
    // What a picture track says at a frame: the last change at or before it.
    const pictureAt = (rows, frame) => {
      if (!rows?.length) return null;
      let now = rows[0][1];
      for (const row of rows) if (row[0] <= frame) now = row[1];
      return now;
    };

    // No tweenEasing is DragonBones for "hold until the next frame".
    const toFrames = (rows, make) => rows.map((row, i) => ({
      duration: i + 1 < rows.length ? rows[i + 1][0] - row[0] : 0,
      ...(row.step ? {} : { tweenEasing: 0 }),
      ...make(row),
    }));

    // How a piece's picture is sized: overall size, then stretched wide or
    // tall on its own, then mirrored.
    const pictureScale = (piece) => {
      const size = piece.scale ?? 1;
      return { x: size * (piece.scaleX ?? 1) * (piece.flip ? -1 : 1), y: size * (piece.scaleY ?? 1) };
    };

    // One bone and one slot per piece. The bone sits at the pivot, in its
    // parent's space; the picture hangs off it, sized and flipped there, so
    // bones never carry scale and a child's offset means what it says. The
    // root bone carries the whole plant's size.
    const buildRigJson = (input, { name = `gtRig`, sway = 3, speed = 1, style = `alternate`, template = null, sizeX = 1, sizeY = 1, anim = null, clips = null } = {}) => {
      const pieces = keyPieces(input);
      const s = rigYSign;
      const motion = rigMotion(pieces, { sway, speed, style, template, anim, clips });
      // Pictures a slot swaps to, after its own: display 0 is its own.
      const swaps = pieces.map((piece, index) => {
        const ids = new Set();
        for (const clip of motion.clips) for (const row of clip.bones[index]?.show ?? []) if (row[1] && row[1] !== HIDE && row[1] !== piece.id) ids.add(row[1]);
        return [...ids].map((id) => pieces.find((other) => other.id === id)).filter(Boolean);
      });
      const rest = pieces.map((piece) => M.at(piece.x ?? 0, piece.y ?? 0, piece.rotation ?? 0));
      const bones = [(sizeX !== 1 || sizeY !== 1) ? { name: `root`, transform: { scX: sizeX, scY: sizeY } } : { name: `root` }];
      for (const index of boneOrder(motion.parents)) {
        const piece = pieces[index];
        const parent = motion.parents[index];
        const local = parent >= 0 ? M.mul(M.inv(rest[parent]), rest[index]) : rest[index];
        const turn = M.angle(local);
        bones.push({
          name: piece.key,
          parent: parent >= 0 ? pieces[parent].key : `root`,
          transform: { x: local[4], y: local[5] * s, skX: turn * s, skY: turn * s },
        });
      }
      // A piece hidden until an animation shows it starts with no display.
      const slots = pieces.map((piece, index) => ({ name: piece.key, parent: piece.key, displayIndex: piece.hidden ? -1 : 0, z: index }));
      const skinSlots = pieces.map((piece, index) => {
        const scale = pictureScale(piece);
        const pivot = pivotOf(piece);
        // Another piece's picture hangs off this bone the same way: this
        // piece's pivot and size, that picture's width and height.
        const display = (shown) => {
          const w = shown.box?.width ?? 0;
          const h = shown.box?.height ?? 0;
          return {
            name: shown.key,
            transform: {
              x: (0.5 - pivot.x) * w * scale.x,
              y: (0.5 - pivot.y) * h * scale.y * s,
              scX: scale.x,
              scY: scale.y,
            },
          };
        };
        return { name: piece.key, display: [piece, ...swaps[index]].map(display) };
      });
      const animation = motion.clips.map((clip) => {
        const out = { name: clip.name, duration: clip.duration, playTimes: clip.playTimes };
        if (clip.frame) out.frame = clip.frame;
        out.bone = clip.bones.map((track, index) => {
          const bone = { name: pieces[index].key };
          if (track.rotate) bone.rotateFrame = toFrames(track.rotate, (row) => ({ rotate: row[1] * s }));
          if (track.move) bone.translateFrame = toFrames(track.move, (row) => ({ x: row[1], y: row[2] * s }));
          if (track.size) bone.scaleFrame = toFrames(track.size, (row) => ({ x: row[1], y: row[2] }));
          return bone;
        }).filter((bone) => bone.rotateFrame || bone.translateFrame || bone.scaleFrame);
        // Fades and picture swaps go on the slot.
        const slotLines = clip.bones.map((track, index) => {
          const line = { name: pieces[index].key };
          if (track.alpha) line.colorFrame = toFrames(track.alpha, (row) => ({ value: { aM: Math.round(Math.max(0, Math.min(1, row[1])) * 100) } }));
          if (track.show) {
            const list = [pieces[index].id, ...swaps[index].map((other) => other.id)];
            line.displayFrame = track.show.map((row, i) => ({
              duration: i + 1 < track.show.length ? track.show[i + 1][0] - row[0] : 0,
              value: row[1] === HIDE ? -1 : Math.max(0, list.indexOf(row[1] ?? pieces[index].id)),
            }));
          }
          return line;
        }).filter((line) => line.colorFrame || line.displayFrame);
        if (slotLines.length) out.slot = slotLines;
        return out;
      });
      const first = animation.find((clip) => clipKind(clip.name) === `idle`) ?? animation[0];
      return {
        frameRate: motion.fps,
        name,
        version: `5.5`,
        compatibleVersion: `5.5`,
        armature: [{
          name,
          type: `Armature`,
          frameRate: motion.fps,
          aabb: { x: -100, y: -100, width: 200, height: 200 },
          bone: bones,
          slot: slots,
          skin: [{ name: ``, slot: skinSlots }],
          animation,
          defaultActions: first ? [{ gotoAndPlay: first.name }] : [],
        }],
      };
    };

    const buildRigAtlas = (pieces, imageSize, name = `gtRig`) => ({
      name,
      imagePath: `${name}.png`,
      width: imageSize?.width ?? 0,
      height: imageSize?.height ?? 0,
      SubTexture: keyPieces(pieces).map((piece) => ({
        name: piece.key,
        x: piece.box.x,
        y: piece.box.y,
        width: piece.box.width,
        height: piece.box.height,
      })),
    });

    // Same constructor-or-clone dance as the atlas: not every build exposes
    // the DragonBones asset classes, and the plant is already holding one.
    const skeletonAsset = (plant, json) => {
      const text = JSON.stringify(json);
      const db = plant?.db ?? plant?.anmControl?.db;
      let asset = null;
      try {
        if (dragonBones?.DragonBonesAsset) asset = new dragonBones.DragonBonesAsset();
      } catch (err) { /* clone instead */ }
      const source = db?.dragonAsset ?? db?._dragonAsset;
      if (!asset && source) {
        asset = Object.create(Object.getPrototypeOf(source));
        Object.assign(asset, source);
      }
      if (!asset) return null;
      asset._uuid = `gt-ske-${Date.now()}`;
      try {
        asset.dragonBonesJson = text;
      } catch (err) { /* read-only, the field below is what a clone kept */ }
      asset._dragonBonesJson = text;
      asset._dragonBonesJsonData = null;
      return asset;
    };

    // What a rig is doing, read off the armature: which clip, whether it's
    // playing, and where in the clip it is. Taken twice a second apart, it
    // says whether the plant is actually moving.
    const rigHealth = (plant) => {
      const db = plant?.db ?? plant?.anmControl?.db;
      let arm = null;
      try {
        arm = db?.armature?.() ?? null;
      } catch (err) {
        arm = null;
      }
      const anim = arm?.animation;
      const state = anim?.lastAnimationState;
      const baked = !!db?.isAnimationCached?.();
      const clock = baked ? db._accTime : state?.currentTime;
      return {
        armature: db?.armatureName,
        clip: (baked ? db.animationName : anim?.lastAnimationName) ?? db?.animationName ?? `-`,
        playing: baked ? !db._isAniComplete : anim?.isPlaying,
        time: typeof clock === `number` ? Math.round(clock * 100) / 100 : null,
        timeScale: db?.timeScale,
        clipScale: anim?.timeScale,
        cache: db?._cacheMode ?? db?.cacheMode,
        bones: arm?.getBones?.()?.length,
        clips: clipsOf(db),
        shown: db?.node?.activeInHierarchy,
        clocked: baked || !!arm?.clock,
      };
    };
    const rigChecked = new Set();
    const checkRig = (plant, force = false) => new Promise((resolve) => {
      const codename = codenameOf(plant);
      if (!force && rigChecked.has(codename)) {
        resolve(null);
        return;
      }
      rigChecked.add(codename);
      const first = rigHealth(plant);
      setTimeout(() => {
        const now = rigHealth(plant);
        const moving = now.time !== null && now.time !== first.time;
        resolve({ moving, first, now });
        e.log.info(`[Textures] ${codename} rig check: ${moving ? `animating` : `NOT animating`}.`
          + ` clip=${now.clip} playing=${now.playing} time ${first.time}->${now.time}`
          + ` speed=${now.timeScale}/${now.clipScale} cache=${now.cache} bones=${now.bones} shown=${now.shown}`
          + ` armature=${now.armature} clips=${now.clips.join(`|`) || `none`} clocked=${now.clocked}`
          );
      }, 1000);
    });

    // The same check in words, for the animation maker to show.
    const rigVerdict = (result, label) => {
      if (!result) return `No ${label} on the lawn to check. Plant one and press Build and wear again to see it checked.`;
      const { moving, now } = result;
      if (moving) return `In game: moving. ${label} is playing "${now.clip}". If it still looks still, turn Sway or How much up: the game draws plants at under half their pixel size.`;
      if (!now.bones) return `In game: the rig didn't build on the plant (no bones). If you report it, include: "rig check: no bones".`;
      if (now.playing === false) return `In game: the rig is on but no animation is playing (it was on "${now.clip}"). If you report it, include: "rig check: not playing, ${now.clip}".`;
      if (!now.timeScale || !now.clipScale) return `In game: the rig is on but its speed is ${now.timeScale}/${now.clipScale}, so the game has it paused. If you report it, include: "rig check: speed ${now.timeScale}/${now.clipScale}".`;
      return `In game: the rig is on and "${now.clip}" is playing, but its clock didn't move in a second (cache ${now.cache}). If you report it, include: "rig check: clock stuck, cache ${now.cache}".`;
    };

    // The rig goes on the plant's own armature; see Wearing a look.
    const wearRig = (plant, json, atlasJson, tex) => {
      const db = plant?.db ?? plant?.anmControl?.db;
      if (!db) return null;
      try {
        const made = sharedAssets(tex, `rig:${idOf(json)}:${idOf(atlasJson)}`, () => ({
          ske: skeletonAsset(plant, json),
          atlas: newAtlas(atlasOf(plant), JSON.stringify(uniqueAtlas(atlasJson)), tex),
        }));
        if (!made?.ske) {
          e.log.error(`[Textures] No way to build a skeleton on this build.`);
          return null;
        }
        const clips = made.atlas && wearOn(plant, { ske: made.ske, atlas: made.atlas, armatureName: json.armature?.[0]?.name ?? `gtRig` });
        if (!clips) return null;
        checkRig(plant);
        return clips.length ? `rig (${clips.length} clips)` : `rig`;
      } catch (err) {
        e.log.error(`[Textures] Couldn't put the rig on: ${err.message}`);
        return null;
      }
    };

    const rigSets = new Map();
    const applyRig = (codename, layout, dataUrl, imageSize, options = {}) => imageFrom(dataUrl).then((imageAsset) => {
      const tex = textureFrom(imageAsset);
      const row = plantRows().find((r) => r.codename === codename);
      const template = vanillaClips(row?.plants?.[0]);
      const json = buildRigJson(layout, { name: `gt_${codename}`, ...options, template });
      const atlasJson = buildRigAtlas(layout, imageSize, `gt_${codename}`);
      let count = 0;
      for (const plant of row?.plants ?? []) {
        const how = wearRig(plant, json, atlasJson, tex);
        if (how) {
          routes[`rig:${codename}`] = how;
          count++;
        }
      }
      if (count) {
        const set = { layout, dataUrl, imageSize, options, json, atlasJson, tex };
        rigSets.set(codename, set);
        for (const plant of row?.plants ?? []) plant.__gtRig = set;
        onStored(`rig:${codename}`);
      }
      return count;
    });

    // Mirrors every rig top to bottom and keeps the choice.
    const flipRigs = () => {
      rigYSign = -rigYSign;
      remember(`option:rigysign`, String(rigYSign));
      for (const set of rigSets.values()) set.json = null;
      version++;
      for (const [codename, set] of rigSets) applyRig(codename, set.layout, set.dataUrl, set.imageSize, set.options).catch(() => { /* next arrival */ });
      e.log.info(`[Textures] Rigs flipped top to bottom. If they were upside down they're the right way up now.`);
      return rigYSign;
    };

    // ==================================================================
    // The panel
    // ==================================================================

    let panel = null;
    let tab = `plants`;
    let filter = ``;
    let confirming = null;

    const style = (node, css) => Object.assign(node.style, css);
    const el = (tag, css, text) => {
      const node = doc.createElement(tag);
      if (css) style(node, css);
      if (text !== undefined) node.textContent = text;
      return node;
    };
    const button = (label, onClick, kind) => {
      const b = el(`button`, {
        font: `11px system-ui, sans-serif`, padding: `4px 9px`, marginLeft: `4px`,
        background: kind === `quiet` ? `#3a3a3a` : kind === `warn` ? `#7d452f` : `#2f7d32`,
        color: `#fff`, border: `0`, borderRadius: `3px`, cursor: `pointer`, whiteSpace: `nowrap`,
      }, label);
      b.onclick = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        onClick();
      };
      // A button that keeps focus eats the editors' keys (Space would
      // press it again), and one re-rendered away drops focus to the page.
      b.onmousedown = (ev) => ev.preventDefault?.();
      return b;
    };

    const openPreview = (tex, title) => {
      const url = pictureOf(tex, 0);
      const shade = el(`div`, {
        position: `fixed`, inset: `0`, zIndex: `100000`, background: `rgba(0,0,0,0.78)`,
        display: `flex`, alignItems: `center`, justifyContent: `center`, flexDirection: `column`,
      });
      shade.onclick = () => shade.remove();
      shade.appendChild(el(`div`, { font: `12px system-ui, sans-serif`, color: `#eee`, marginBottom: `8px` },
        `${title}  ${tex.width}x${tex.height}  (click anywhere to close)`));
      if (url) {
        const frame = el(`div`, {
          maxWidth: `84vw`, maxHeight: `76vh`, overflow: `auto`, padding: `8px`,
          background: `repeating-conic-gradient(#666 0% 25%, #999 0% 50%) 50% / 20px 20px`,
        });
        const img = el(`img`);
        img.src = url;
        style(img, { display: `block`, imageRendering: `pixelated` });
        frame.appendChild(img);
        shade.appendChild(frame);
      } else {
        shade.appendChild(el(`div`, { font: `12px system-ui, sans-serif`, color: `#f99` },
          `No readable image on this one.`));
      }
      doc.body.appendChild(shade);
    };

    const thumb = (tex, onClick) => {
      const url = pictureOf(tex, 44);
      const node = el(`div`, {
        width: `44px`, height: `44px`, flex: `0 0 44px`, cursor: `pointer`, borderRadius: `3px`,
        background: url
          ? `url(${url}) center/contain no-repeat, repeating-conic-gradient(#555 0% 25%, #777 0% 50%) 50% / 11px 11px`
          : `#333`,
      });
      node.title = `Click to see the whole sheet`;
      node.onclick = onClick;
      return node;
    };

    const tabButton = (key, label) => {
      const b = button(label, () => {
        tab = key;
        drawPanel();
      }, tab === key ? `go` : `quiet`);
      b.style.marginLeft = `0`;
      b.style.marginRight = `4px`;
      return b;
    };

    const drawPlants = (list, overrides) => {
      const rows = plantRows().filter((r) => !filter || r.label.toLowerCase().includes(filter.toLowerCase()));
      if (!rows.length) {
        list.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, opacity: `0.75`, padding: `12px 0` },
          `No plants on the lawn. Art loads with the plants using it, so plant one and open this again.`));
        return;
      }
      for (const row of rows) {
        const key = `plant:${row.codename}`;
        const art = row.textures[0];
        const line = el(`div`, {
          display: `flex`, alignItems: `center`, gap: `8px`, padding: `6px 0`, borderBottom: `1px solid #333`,
        });
        line.appendChild(thumb(art.tex, () => openPreview(art.tex, row.label)));
        const text = el(`div`, { flex: `1`, minWidth: `0` });
        const title = el(`div`, { font: `12px system-ui, sans-serif` });
        title.appendChild(el(`span`, {}, row.label));
        title.appendChild(el(`span`, {
          font: `10px system-ui, sans-serif`, marginLeft: `6px`, padding: `1px 5px`, borderRadius: `8px`,
          background: row.modded ? `#2f7d32` : `#444`, color: `#fff`,
        }, row.modded ? `modded` : `vanilla`));
        if (overrides[key]) title.appendChild(el(`span`, { font: `10px system-ui, sans-serif`, marginLeft: `6px`, opacity: `0.7` }, `replaced`));
        text.appendChild(title);
        const shared = sharersOf(art.tex);
        text.appendChild(el(`div`, { font: `10px system-ui, sans-serif`, opacity: `0.6` },
          `${row.plants.length} on the lawn  ${art.tex.width}x${art.tex.height}${routes[key] ? `  via ${routes[key]}` : ``}${shared.vanilla.length ? `  sheet shared with ${shared.vanilla.join(`, `)}` : ``}`));
        // Size controls, only for what this plant actually has: a still
        // image is measured in tiles tall, a packet picture as a multiple of
        // the packet's own art box.
        const sizer = (label, value, unit, step, set) => {
          const group = el(`span`, { display: `inline-flex`, alignItems: `center`, gap: `3px`, marginRight: `10px` });
          group.appendChild(el(`span`, { font: `10px system-ui, sans-serif`, opacity: `0.75` }, label));
          const minus = button(`-`, () => {
            set(value - step);
            drawPanel();
          }, `quiet`);
          minus.style.marginLeft = `2px`;
          group.appendChild(minus);
          group.appendChild(el(`span`, { font: `10px system-ui, sans-serif`, minWidth: `34px`, textAlign: `center` },
            `${Math.round(value * 100) / 100}${unit}`));
          const plus = button(`+`, () => {
            set(value + step);
            drawPanel();
          }, `quiet`);
          plus.style.marginLeft = `0`;
          group.appendChild(plus);
          return group;
        };
        // A slider moves the picture as it's dragged. It doesn't redraw the
        // panel, which would drop the slider out from under the mouse.
        const slider = (label, value, range, set) => {
          const group = el(`span`, { display: `inline-flex`, alignItems: `center`, gap: `3px`, marginRight: `8px` });
          group.appendChild(el(`span`, { font: `10px system-ui, sans-serif`, opacity: `0.75` }, label));
          const input = doc.createElement(`input`);
          input.type = `range`;
          input.min = String(-range);
          input.max = String(range);
          input.step = `1`;
          input.value = String(value);
          style(input, { width: `80px` });
          const shown = el(`span`, { font: `10px system-ui, sans-serif`, minWidth: `24px`, textAlign: `right` }, `${value}`);
          input.oninput = () => {
            set(Number(input.value));
            shown.textContent = input.value;
          };
          input.onkeydown = (ev) => ev.stopPropagation();
          input.onmousedown = (ev) => ev.stopPropagation();
          group.appendChild(input);
          group.appendChild(shown);
          return group;
        };
        const hasStill = !!overrides[`still:${row.codename}`];
        const hasPacket = !!overrides[`packet:${row.codename}`];
        if (hasStill || hasPacket) {
          const sizes = el(`div`, { marginTop: `3px` });
          if (hasStill) {
            const line1 = el(`div`, { marginTop: `2px` });
            line1.appendChild(sizer(`still size`, stillScales.get(row.codename) ?? STILL_FIT, ` tiles`, STILL_STEP,
              (v) => setStillScale(row.codename, v)));
            const at = stillOffsets.get(row.codename) ?? { x: 0, y: 0 };
            line1.appendChild(slider(`x`, at.x, OFFSET_RANGE.still,
              (v) => setStillOffset(row.codename, v, (stillOffsets.get(row.codename) ?? at).y)));
            line1.appendChild(slider(`y`, at.y, OFFSET_RANGE.still,
              (v) => setStillOffset(row.codename, (stillOffsets.get(row.codename) ?? at).x, v)));
            sizes.appendChild(line1);
          }
          if (hasPacket) {
            const line2 = el(`div`, { marginTop: `2px` });
            line2.appendChild(sizer(`packet size`, packetScales.get(row.codename) ?? 1, `x`, PACKET_STEP,
              (v) => setPacketScale(row.codename, v)));
            const at = packetOffsets.get(row.codename) ?? { x: 0, y: 0 };
            line2.appendChild(slider(`x`, at.x, OFFSET_RANGE.packet,
              (v) => setPacketOffset(row.codename, v, (packetOffsets.get(row.codename) ?? at).y)));
            line2.appendChild(slider(`y`, at.y, OFFSET_RANGE.packet,
              (v) => setPacketOffset(row.codename, (packetOffsets.get(row.codename) ?? at).x, v)));
            sizes.appendChild(line2);
          }
          text.appendChild(sizes);
        }
        line.appendChild(text);
        const buttons = el(`span`, { whiteSpace: `nowrap` });
        buttons.appendChild(button(`Save PNG`, () => exportTexture(art.tex, row.codename), `quiet`));
        buttons.appendChild(button(`This plant only`, () => replace(key, row.label)));
        buttons.appendChild(button(`Still image`, () => replace(`still:${row.codename}`, `${row.label} (still)`), `quiet`));
        buttons.appendChild(button(`Fit to rig`, () => fitArt(row)));
        buttons.appendChild(button(`Packet`, () => openPacketEditor(row.codename, row.label), `quiet`));
        buttons.appendChild(button(`Animate`, () => rigArt(row)));
        // Repainting a shared sheet takes the vanilla plant with it, so that
        // button says whose art it is about to change and asks twice.
        const sheetKey = `sheet:${uuidOf(art.tex)}`;
        const sheetLabel = shared.vanilla.length ? `Also ${shared.vanilla.join(`, `)}` : `Every user`;
        const sheetButton = button(sheetLabel, () => {
          if (shared.vanilla.length && confirming !== sheetKey) {
            confirming = sheetKey;
            drawPanel();
            return;
          }
          confirming = null;
          replace(sheetKey, `${row.label}'s sheet`);
        }, shared.vanilla.length ? `warn` : `quiet`);
        if (confirming === sheetKey) sheetButton.textContent = `Sure? changes ${shared.vanilla.join(`, `)}`;
        buttons.appendChild(sheetButton);
        buttons.appendChild(button(`Full art`, () => dressFromSet(row.codename, row.label), `quiet`));
        if (overrides[key]) buttons.appendChild(button(`Undo`, () => undo(key, row.label), `warn`));
        line.appendChild(buttons);
        list.appendChild(line);
      }
    };

    // Every plant the game knows, not just the ones on the lawn, since a
    // packet is wanted in the chooser before any of it is planted.
    const drawPacketList = (list, overrides) => {
      const reg = plantRegistry();
      const codes = new Set(reg?.defaultPlantChooserOrder ?? []);
      for (const r of plantRows()) codes.add(r.codename);
      for (const key of Object.keys(overrides)) {
        const [scope, id] = key.split(`:`);
        if ([`packet`, `packetback`, `packetfront`, `still`, `rig`, `packetproj`].includes(scope)) codes.add(id);
      }
      const want = filter.toLowerCase();
      const rows = [...codes].map((code) => {
        let feature = null;
        try {
          feature = reg?.getPlantFeature?.(reg?.getPlantEnumByCodename?.(code));
        } catch (err) { /* unknown plant */ }
        return { code, label: feature?.NAME?.en ?? code };
      })
        .filter((r) => !want || r.label.toLowerCase().includes(want) || r.code.includes(want))
        .sort((a, b) => (Number(!!overrides[`packet:${b.code}`]) - Number(!!overrides[`packet:${a.code}`])) || a.label.localeCompare(b.label))
        .slice(0, 80);
      if (!rows.length) {
        list.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, opacity: `0.75`, padding: `12px 0` }, `No plant by that name.`));
      }
      for (const r of rows) {
        const line = el(`div`, { display: `flex`, alignItems: `center`, justifyContent: `space-between`, padding: `5px 0`, borderBottom: `1px solid #333` });
        line.appendChild(el(`div`, { font: `12px system-ui, sans-serif` }, `${r.label}${overrides[`packet:${r.code}`] ? `  (custom packet)` : ``}`));
        line.appendChild(button(`Edit packet`, () => openPacketEditor(r.code, r.label), `quiet`));
        list.appendChild(line);
      }
    };

    const drawAll = (list, overrides) => {
      const rows = allTextures()
        .filter((r) => !filter
          || r.uuid.includes(filter)
          || r.users.some((u) => u.toLowerCase().includes(filter.toLowerCase())))
        .slice(0, 40);
      for (const row of rows) {
        const key = `sheet:${row.uuid}`;
        const label = row.users.length ? row.users.join(`, `) : `${row.uuid.slice(0, 8)}`;
        const line = el(`div`, {
          display: `flex`, alignItems: `center`, gap: `8px`, padding: `6px 0`, borderBottom: `1px solid #333`,
        });
        line.appendChild(thumb(row.tex, () => openPreview(row.tex, label)));
        const text = el(`div`, { flex: `1`, minWidth: `0` });
        text.appendChild(el(`div`, {
          font: `12px system-ui, sans-serif`, overflow: `hidden`, textOverflow: `ellipsis`, whiteSpace: `nowrap`,
        }, `${label}${overrides[key] ? `  (replaced)` : ``}`));
        text.appendChild(el(`div`, { font: `10px system-ui, sans-serif`, opacity: `0.6` },
          `${row.tex.width}x${row.tex.height}  ${row.uuid.slice(0, 12)}`));
        line.appendChild(text);
        const buttons = el(`span`, { whiteSpace: `nowrap` });
        buttons.appendChild(button(`Save PNG`, () => exportTexture(row.tex, row.users[0] ?? row.uuid.slice(0, 8)), `quiet`));
        buttons.appendChild(button(`Replace`, () => replace(key, label)));
        if (overrides[key]) buttons.appendChild(button(`Undo`, () => undo(key, label), `warn`));
        line.appendChild(buttons);
        list.appendChild(line);
      }
      if (!rows.length) {
        list.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, opacity: `0.75`, padding: `12px 0` },
          `Nothing loaded matches.`));
      }
    };

    const drawPanel = () => {
      if (!panel) return;
      const overrides = saved();
      panel.innerHTML = ``;

      const head = el(`div`, { display: `flex`, alignItems: `center`, justifyContent: `space-between` });
      head.appendChild(el(`div`, { font: `600 13px system-ui, sans-serif` }, `Greenhouse Textures`));
      head.appendChild(el(`span`, {}, ``));
      const headButtons = el(`span`, { whiteSpace: `nowrap` });
      loadLocal();
      const local = Object.keys(savedCache).filter((key) => !key.startsWith(OFF) && inFolder(key));
      if (mainHome() && local.length) {
        headButtons.appendChild(button(`Move ${local.length} to mod folder`, () => {
          moveToFolder().then(() => drawPanel());
        }, `quiet`));
      }
      headButtons.appendChild(button(`Turn everything off`, () => {
        stopped = true;
        clear();
      }, `warn`));
      headButtons.appendChild(button(`Close`, togglePanel, `quiet`));
      head.appendChild(headButtons);
      panel.appendChild(head);

      panel.appendChild(homePicker());
      panel.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, opacity: `0.75`, margin: `6px 0` },
        tab === `plants`
          ? `"This plant only" changes the one plant. The other button repaints the sheet it borrows, which changes the vanilla plant too, and says whose. Art that isn't a repaint needs its skeleton: that's "Full art".`
          : `Every texture the game has loaded. Replacing one changes everything drawing from it.`));

      const tabs = el(`div`, { marginBottom: `6px` });
      tabs.appendChild(tabButton(`plants`, `Plants on the lawn`));
      tabs.appendChild(tabButton(`packets`, `Seed packets`));
      tabs.appendChild(tabButton(`all`, `All textures`));
      tabs.appendChild(tabButton(`replaced`, `Replaced (${Object.keys(overrides).length})`));
      panel.appendChild(tabs);

      const search = el(`input`, {
        width: `100%`, boxSizing: `border-box`, marginBottom: `6px`, padding: `5px`,
        font: `11px system-ui, sans-serif`, border: `1px solid #555`, borderRadius: `3px`,
        background: `#111`, color: `#eee`,
      });
      search.value = filter;
      search.placeholder = `filter by plant name`;
      search.oninput = () => {
        filter = search.value;
        drawPanel();
        const again = panel.querySelector(`input`);
        again?.focus();
        again?.setSelectionRange(filter.length, filter.length);
      };
      search.onkeydown = (ev) => ev.stopPropagation();
      panel.appendChild(search);

      const list = el(`div`, { maxHeight: `340px`, overflowY: `auto` });
      if (tab === `plants`) drawPlants(list, overrides);
      else if (tab === `packets`) drawPacketList(list, overrides);
      else if (tab === `all`) drawAll(list, overrides);
      else {
        const keys = Object.keys(overrides);
        if (!keys.length) {
          list.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, opacity: `0.75`, padding: `12px 0` },
            `Nothing replaced yet.`));
        }
        for (const key of keys) {
          const line = el(`div`, {
            display: `flex`, alignItems: `center`, justifyContent: `space-between`,
            padding: `6px 0`, borderBottom: `1px solid #333`,
          });
          const [scope, id] = key.split(`:`);
          line.appendChild(el(`div`, { font: `12px system-ui, sans-serif` },
            `${scope === `plant` ? id : `sheet ${id.slice(0, 10)}`}${routes[key] ? `  via ${routes[key]}` : ``}`));
          line.appendChild(button(`Undo`, () => undo(key, id), `warn`));
          list.appendChild(line);
        }
      }
      panel.appendChild(list);
    };

    // Where new art goes for plants whose own pack isn't known (vanilla
    // plants, mostly): any pack with a textures folder.
    const homePicker = () => {
      const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px`, font: `11px system-ui, sans-serif`, margin: `6px 0 2px` });
      line.appendChild(el(`span`, { opacity: `0.8`, whiteSpace: `nowrap` }, `Keep new art in`));
      const select = doc.createElement(`select`);
      style(select, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `2px`, font: `11px system-ui, sans-serif` });
      const options = [...homeChoices.map((p) => [p.uuid, `${p.name} (${packNameOf(p.folder)}/textures)`])];
      if (ownFolder) options.push([OWN_UUID, `this pack (a new version replaces it)`]);
      if (!options.length) options.push([``, `local storage (no pack has a textures folder)`]);
      const current = homeChoices.find((p) => p.folder === homeFolder)?.uuid ?? (ownFolder ? OWN_UUID : ``);
      for (const [value, text] of options) {
        const opt = doc.createElement(`option`);
        opt.value = value;
        opt.textContent = text;
        if (value === current) opt.selected = true;
        select.appendChild(opt);
      }
      select.onchange = () => {
        remember(`option:homepack`, select.value);
        readAll().then(afterFolders).then(() => drawPanel());
      };
      select.onkeydown = (ev) => ev.stopPropagation();
      line.appendChild(select);
      const wrap = el(`div`, {});
      wrap.appendChild(line);
      if (!homeFolder && ownFolder) {
        wrap.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, color: `#ffb35c`, lineHeight: `1.35`, marginBottom: `4px` },
          homeChoices.length
            ? `Pick a pack to keep new art in. In this pack's own folder it's lost when a new version of this pack is installed.`
            : `No other pack has a textures folder, so new art goes in this pack's, and a new version of this pack replaces it. Give a pack a textures folder (with saved and removed inside) and pick it here.`));
      }
      return wrap;
    };

    const togglePanel = () => {
      if (panel) {
        panel.remove();
        panel = null;
        return;
      }
      panel = el(`div`, {
        position: `fixed`, top: `60px`, right: `20px`, width: `500px`, zIndex: `99999`,
        background: `rgba(16,16,16,0.95)`, color: `#eee`, padding: `12px`,
        border: `1px solid #444`, borderRadius: `6px`, boxShadow: `0 4px 20px rgba(0,0,0,0.5)`,
      });
      doc.body.appendChild(panel);
      drawPanel();
    };

    // ---- the fitter window -------------------------------------------
    // Sheet on the left with every lump boxed, the rig's pieces listed on the
    // right. Click a piece, click its box. Apply rewrites the atlas.
    let fitter = null;

    const openFitter = (row, dataUrl) => {
      const plant = row.plants[0];
      const pieces = rigPieces(plant);
      if (!pieces.length) {
        e.log.error(`[Textures] ${row.label}: couldn't read that rig's piece list, so there's nothing to fit to.`);
        return;
      }
      const img = new Image();
      img.onerror = () => e.log.error(`[Textures] ${row.label}: couldn't read that image.`);
      img.onload = () => {
        let boxes = [];
        try {
          boxes = boxesInImage(img);
        } catch (err) {
          e.log.error(`[Textures] Couldn't scan that sheet: ${err.message}`);
          return;
        }
        if (!boxes.length) {
          e.log.error(`[Textures] Nothing opaque found on that sheet.`);
          return;
        }
        const saveKey = `fit:${row.codename}`;
        let pairs = {};
        try {
          pairs = JSON.parse(saved()[saveKey] ?? `null`)?.pairs ?? autoPair(pieces, boxes);
        } catch (err) {
          pairs = autoPair(pieces, boxes);
        }
        let picked = pieces[0]?.name ?? null;

        fitter?.remove();
        fitter = el(`div`, {
          position: `fixed`, inset: `4vh 4vw`, zIndex: `100001`, display: `flex`, gap: `10px`,
          background: `rgba(14,14,14,0.97)`, color: `#eee`, padding: `12px`,
          border: `1px solid #444`, borderRadius: `6px`, boxShadow: `0 6px 30px rgba(0,0,0,0.6)`,
        });

        const left = el(`div`, { flex: `1`, overflow: `auto`, position: `relative`, background: `repeating-conic-gradient(#555 0% 25%, #777 0% 50%) 50% / 16px 16px` });
        const canvas = doc.createElement(`canvas`);
        canvas.width = img.width;
        canvas.height = img.height;
        style(canvas, { display: `block`, maxWidth: `100%`, cursor: `crosshair` });
        left.appendChild(canvas);

        const right = el(`div`, { width: `300px`, display: `flex`, flexDirection: `column` });

        const draw = () => {
          const ctx = canvas.getContext(`2d`);
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);
          boxes.forEach((box, index) => {
            const taken = Object.entries(pairs).find(([, i]) => i === index);
            const mine = taken && taken[0] === picked;
            ctx.lineWidth = Math.max(2, img.width / 400);
            ctx.strokeStyle = mine ? `#4cd964` : taken ? `#3a7d3f` : `#ff9f0a`;
            ctx.strokeRect(box.x, box.y, box.width, box.height);
            if (taken) {
              ctx.fillStyle = mine ? `#4cd964` : `#8fce92`;
              ctx.font = `${Math.max(11, img.width / 90)}px system-ui, sans-serif`;
              ctx.fillText(taken[0], box.x + 2, Math.max(12, box.y - 3));
            }
          });
        };

        canvas.onclick = (ev) => {
          if (!picked) return;
          const rect = canvas.getBoundingClientRect();
          const x = (ev.clientX - rect.left) * (canvas.width / rect.width);
          const y = (ev.clientY - rect.top) * (canvas.height / rect.height);
          const hit = boxes.findIndex((box) => x >= box.x && x <= box.x + box.width && y >= box.y && y <= box.y + box.height);
          if (hit < 0) return;
          // A box belongs to one piece, so hand it over rather than share it.
          for (const [name, index] of Object.entries(pairs)) if (index === hit) delete pairs[name];
          pairs[picked] = hit;
          const order = pieces.map((p) => p.name);
          const next = order[order.indexOf(picked) + 1];
          picked = next ?? picked;
          drawFitter();
        };

        const drawFitter = () => {
          right.innerHTML = ``;
          right.appendChild(el(`div`, { font: `600 13px system-ui, sans-serif`, marginBottom: `4px` },
            `Fit art to ${row.label}`));
          right.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, opacity: `0.75`, marginBottom: `6px` },
            `${boxes.length} pieces found on the sheet, ${pieces.length} the rig wants. Click a name, then click its piece in the picture.`));

          const list = el(`div`, { flex: `1`, overflowY: `auto`, border: `1px solid #333`, borderRadius: `4px` });
          for (const piece of pieces) {
            const index = pairs[piece.name];
            const line = el(`div`, {
              display: `flex`, justifyContent: `space-between`, alignItems: `center`, gap: `6px`,
              padding: `4px 6px`, cursor: `pointer`, font: `11px system-ui, sans-serif`,
              background: piece.name === picked ? `#2f7d32` : `transparent`,
              borderBottom: `1px solid #2a2a2a`,
            });
            line.onclick = () => {
              picked = piece.name;
              drawFitter();
            };
            line.appendChild(el(`span`, { overflow: `hidden`, textOverflow: `ellipsis`, whiteSpace: `nowrap` }, piece.name));
            line.appendChild(el(`span`, { opacity: `0.65`, whiteSpace: `nowrap` },
              typeof index === `number` ? `box ${index + 1}` : `unset`));
            list.appendChild(line);
          }
          right.appendChild(list);

          const done = Object.keys(pairs).length;
          right.appendChild(el(`div`, { font: `11px system-ui, sans-serif`, opacity: `0.7`, margin: `6px 0` },
            `${done} of ${pieces.length} paired. Anything left unset keeps pointing at the old sheet.`));

          const buttons = el(`div`, {});
          buttons.appendChild(button(`Apply to ${row.label}`, () => {
            const json = atlasJsonOf(plant);
            if (!json) {
              e.log.error(`[Textures] ${row.label}: its atlas json can't be read back, so there's nothing to rewrite.`);
              return;
            }
            const live = plantRows().find((r) => r.codename === row.codename);
            const targets = live?.plants ?? row.plants;
            e.log.info(`[Textures] ${row.label}: fitting ${Object.keys(pairs).length} paired piece(s) onto ${targets.length} plant(s).`);
            const { json: fitted, moved } = rewriteAtlas(json, pairs, boxes, { width: img.width, height: img.height });
            imageFrom(dataUrl)
              .then((imageAsset) => {
                const tex = textureFrom(imageAsset);
                let count = 0;
                for (const one of targets) if (fitToRig(one, fitted, tex)) count++;
                if (!count) {
                  e.log.error(`[Textures] ${row.label}: the fit didn't go on any plant. Is one still on the lawn?`);
                  return;
                }
                routes[`fit:${row.codename}`] = `fitted (${moved} pieces)`;
                const set = { atlas: fitted, dataUrl, pairs: { ...pairs }, boxes, size: { width: img.width, height: img.height }, tex };
                for (const one of targets) one.__gtFitted = set;
                fittedSets.set(row.codename, set);
                remember(saveKey, JSON.stringify({ pairs }));
                remember(`fitart:${row.codename}`, dataUrl);
                e.log.info(`[Textures] ${row.label}: ${moved} piece(s) repointed at the new sheet.`);
                drawPanel();
              })
              .catch((err) => e.log.error(`[Textures] ${row.label}: ${err.message}`));
          }));
          buttons.appendChild(button(`Auto pair`, () => {
            pairs = autoPair(pieces, boxes);
            drawFitter();
          }, `quiet`));
          buttons.appendChild(button(`Clear`, () => {
            pairs = {};
            drawFitter();
          }, `quiet`));
          buttons.appendChild(button(`Close`, () => {
            fitter?.remove();
            fitter = null;
          }, `warn`));
          right.appendChild(buttons);
          draw();
        };

        fitter.appendChild(left);
        fitter.appendChild(right);
        doc.body.appendChild(fitter);
        drawFitter();
      };
      img.src = dataUrl;
    };

    // What each fit needs to go back on: the pairs, the boxes they point at
    // and the picture. The atlas itself is worked out from the first plant
    // it meets, since that is where the rig's own rectangles come from.
    const fittedSets = new Map();
    const fittedAtlasFor = (set, plant) => {
      if (set.atlas) return set.atlas;
      const json = atlasJsonOf(plant);
      if (!json || !set.pairs || !set.boxes) return null;
      set.atlas = rewriteAtlas(json, set.pairs, set.boxes, set.size).json;
      return set.atlas;
    };

    const fitArt = (row) => pickFile((dataUrl) => openFitter(row, dataUrl));

    // ---- the animation maker -----------------------------------------
    // Two steps in one window. Cut out: the picture, with a box round every
    // piece; draw your own, drag them, resize them from the corners, name
    // them. Build: the pieces stood up as the plant, attached to each other,
    // each told how to move, with the animation playing as it will in game.
    // Nothing on either canvas but the art and the handles you are using.
    let rigWindow = null;

    const CHECKER = `repeating-conic-gradient(#2a2a2a 0% 25%, #333 0% 50%) 50% / 16px 16px`;

    const openRig = (row, dataUrl, opened = {}) => {
      const img = new Image();
      img.onerror = () => e.log.error(`[Textures] ${row.label}: couldn't read that image.`);
      img.onload = () => {
        const saveKey = `rig:${row.codename}`;
        const draftKey = `rigdraft:${row.codename}`;
        let scanned = null;
        const scan = () => {
          if (!scanned) {
            try {
              scanned = boxesInImage(img);
            } catch (err) {
              scanned = [];
            }
          }
          return scanned;
        };
        let draft = opened.draft ?? null;
        if (!draft) {
          try {
            draft = JSON.parse(stored(draftKey) ?? stored(saveKey) ?? `null`);
          } catch (err) {
            draft = null;
          }
        }

        // ---- state ----
        let nextId = 1;
        const makePiece = (p = {}) => {
          const id = p.id ?? `p${nextId}`;
          const n = Number(/^p(\d+)$/.exec(id)?.[1]);
          nextId = Math.max(nextId, Number.isFinite(n) ? n + 1 : nextId + 1);
          return {
            id,
            name: p.name ?? `piece ${n || nextId - 1}`,
            box: { x: p.box.x, y: p.box.y, width: p.box.width, height: p.box.height },
            x: p.x ?? 0,
            y: p.y ?? 0,
            rotation: p.rotation ?? 0,
            scale: p.scale ?? 1,
            flip: !!p.flip,
            pivotX: p.pivotX ?? 0.5,
            pivotY: p.pivotY ?? p.pivot ?? 1,
            parent: p.parent ?? null,
            motion: MOTIONS.includes(p.motion) ? p.motion : `sway`,
            amount: p.amount ?? 1,
            scaleX: p.scaleX ?? 1,
            scaleY: p.scaleY ?? 1,
            keys: Array.isArray(p.keys) ? p.keys.map((k) => ({ ...REST_KEY, ...k })) : [],
            sync: p.sync ?? null,
            syncOpposite: !!p.syncOpposite,
            hidden: !!p.hidden,
            fresh: !!p.fresh,
          };
        };
        let pieces = (draft?.layout ?? [])
          .map((p, i) => {
            const box = p.box ?? scan()[p.boxIndex ?? i];
            return box ? makePiece({ ...p, box, id: p.id, name: p.name }) : null;
          })
          .filter(Boolean);
        const options = { sway: 6, speed: 1, style: `alternate`, ...(draft?.options ?? {}) };
        if (opened.sheets && !options.sheets?.length) options.sheets = opened.sheets;
        let mode = opened.mode === `animate` ? `build` : opened.mode ?? (pieces.length ? `build` : `cut`);
        const firstTime = !pieces.length;
        if (!pieces.length) pieces = scan().slice(0, 16).map((box) => makePiece({ box, fresh: true }));
        // Sheets just added: every lump found on them becomes a new piece.
        else if (opened.newRegions?.length) {
          const inside = (box) => opened.newRegions.some((r) => box.x >= r.x && box.y >= r.y
            && box.x + box.width <= r.x + r.width + 1 && box.y + box.height <= r.y + r.height + 1);
          for (const box of scan().filter(inside).slice(0, 32)) pieces.push(makePiece({ box, fresh: true }));
        }
        // The clip being animated, or null for the layout; and the trigger
        // picked in it.
        let onClip = null;
        let triggerSel = null;
        // One piece is the one being edited; Ctrl+click adds more to the
        // selection, and moving, cloning, deleting and syncing act on all.
        let selected = pieces[0]?.id ?? null;
        let picked = new Set(selected ? [selected] : []);
        const selectOnly = (id) => {
          selected = id;
          picked = new Set(id ? [id] : []);
          if (triggerSel && !triggerById(triggerSel)?.targets.includes(id)) triggerSel = null;
        };
        const toggle = (id) => {
          if (picked.has(id) && picked.size > 1) {
            picked.delete(id);
            if (selected === id) selected = [...picked][0];
          } else {
            picked.add(id);
            selected = id;
          }
        };
        let clean = false;
        let pivoting = false;
        let status = opened.status ?? (firstTime
          ? `Every lump of art found on the picture has a box. Fix the boxes, add your own, name the pieces, then go to step 2.`
          : ``);
        const byId = (id) => pieces.find((p) => p.id === id) ?? null;
        const current = () => byId(selected);
        const pickedPieces = () => pieces.filter((p) => picked.has(p.id));

        // Everything below a piece, so moving it takes its attachments along.
        const descendantsOf = (id) => {
          const out = [];
          const walk = (parent) => {
            for (const p of pieces) {
              if (p.parent === parent && !out.includes(p)) {
                out.push(p);
                walk(p.id);
              }
            }
          };
          walk(id);
          return out;
        };

        // Keys from before 0.18 become triggers: the same motion, as bars.
        let triggerCounter = 0;
        const nextTriggerId = () => `t${++triggerCounter}`;
        for (const own of Object.values(options.anim ?? {})) {
          for (const t of own?.triggers ?? []) triggerCounter = Math.max(triggerCounter, Number(/^t(\d+)$/.exec(t.id ?? ``)?.[1]) || 0);
        }
        let migrated = 0;
        for (const own of Object.values(options.anim ?? {})) {
          if (!own?.tracks) continue;
          const ids = Object.keys(own.tracks).filter((id) => own.tracks[id]?.length && byId(id));
          own.triggers = [...(own.triggers ?? []), ...clipTriggers({ tracks: own.tracks }, pieces).map((t) => ({ ...t, id: nextTriggerId() }))];
          own.loopOff = [...new Set([...(own.loopOff ?? []), ...ids])];
          delete own.tracks;
          migrated += ids.length;
        }
        if (migrated && !status) status = `Keys made before this version are triggers now: the same motion, as bars on the timeline under each clip.`;

        // ---- history ----
        const snapshot = () => JSON.stringify({ pieces, options });
        let history = [snapshot()];
        let future = [];
        let motionCache = null;
        const template = vanillaClips(row.plants?.[0]);
        const motionNow = () => motionCache ?? (motionCache = rigMotion(pieces, { ...options, template }));
        const changed = () => {
          motionCache = null;
        };
        const saveDraft = () => {
          try {
            setLocal(draftKey, JSON.stringify({ layout: pieces, options }));
          } catch (err) { /* the draft is a convenience */ }
        };
        const commit = () => {
          changed();
          const now = snapshot();
          if (history[history.length - 1] === now) return;
          history.push(now);
          if (history.length > 150) history.shift();
          future = [];
          saveDraft();
        };
        const restore = (text) => {
          const state = JSON.parse(text);
          pieces = state.pieces;
          // Every key goes first, so undoing a clip's first trigger takes
          // the clip's entry with it rather than leaving it behind.
          for (const key of Object.keys(options)) delete options[key];
          Object.assign(options, state.options);
          picked = new Set([...picked].filter((id) => byId(id)));
          if (triggerSel && !triggerById(triggerSel)) triggerSel = null;
          if (!byId(selected)) selected = [...picked][0] ?? pieces[0]?.id ?? null;
          if (selected) picked.add(selected);
          changed();
          saveDraft();
          render();
        };
        const undo = () => {
          if (history.length < 2) return;
          future.push(history.pop());
          restore(history[history.length - 1]);
        };
        const redo = () => {
          if (!future.length) return;
          const next = future.pop();
          history.push(next);
          restore(next);
        };
        // What the plant in the game has on, to say when there's more.
        // Editor-only visibility doesn't count as a change to the plant.
        const builtState = () => JSON.stringify({ pieces, options: { ...options, viewOff: null } });
        let builtAs = !opened.draft && !stored(draftKey) && stored(saveKey) ? builtState() : null;
        const unbuilt = () => builtAs !== builtState();

        // ---- window ----
        rigWindow?.__close?.();
        rigWindow = el(`div`, {
          position: `fixed`, inset: `3vh 3vw`, zIndex: `100001`, display: `flex`, flexDirection: `column`,
          background: `rgba(16,16,16,0.98)`, color: `#eee`, padding: `10px`, gap: `8px`,
          border: `1px solid #444`, borderRadius: `8px`, boxShadow: `0 8px 40px rgba(0,0,0,0.7)`,
          font: `12px system-ui, sans-serif`, outline: `none`,
        });
        rigWindow.tabIndex = 0;
        // The game listens on the document; nothing in here should reach it.
        for (const type of [`keydown`, `keyup`, `keypress`, `wheel`, `mousedown`, `mouseup`, `click`, `pointerdown`, `pointerup`, `touchstart`, `touchend`]) {
          rigWindow.addEventListener(type, (ev) => ev.stopPropagation());
        }
        const head = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px`, flexWrap: `wrap` });
        const body = el(`div`, { flex: `1`, display: `flex`, gap: `10px`, minHeight: `0` });
        // The stage on top, and under it the dock: clips, the timeline and
        // the edit buttons, where the GD editor keeps its own.
        const stageWrap = el(`div`, { flex: `1`, display: `flex`, flexDirection: `column`, minWidth: `0`, borderRadius: `6px`, overflow: `hidden`, border: `1px solid #333` });
        const stage = el(`div`, { flex: `1`, position: `relative`, minHeight: `0`, background: CHECKER });
        const canvas = doc.createElement(`canvas`);
        style(canvas, { position: `absolute`, inset: `0`, width: `100%`, height: `100%`, display: `block` });
        stage.appendChild(canvas);
        const dock = el(`div`, { flex: `0 0 auto`, display: `flex`, flexDirection: `column`, background: `#141414`, borderTop: `1px solid #333` });
        stageWrap.appendChild(stage);
        stageWrap.appendChild(dock);
        const side = el(`div`, { width: `330px`, display: `flex`, flexDirection: `column`, gap: `8px`, overflowY: `auto`, minHeight: `0` });
        body.appendChild(stageWrap);
        body.appendChild(side);
        rigWindow.appendChild(head);
        rigWindow.appendChild(body);

        // ---- small controls ----
        const section = (title) => {
          const box = el(`div`, { border: `1px solid #333`, borderRadius: `6px`, padding: `8px`, display: `flex`, flexDirection: `column`, gap: `6px` });
          if (title) box.appendChild(el(`div`, { font: `600 12px system-ui, sans-serif`, opacity: `0.9` }, title));
          side.appendChild(box);
          return box;
        };
        const labelled = (label, control) => {
          const line = el(`label`, { display: `flex`, alignItems: `center`, gap: `8px` });
          line.appendChild(el(`span`, { width: `92px`, flex: `0 0 auto`, opacity: `0.8` }, label));
          line.appendChild(control);
          return line;
        };
        const range = (value, min, max, step, onInput, shown = (v) => `${v}`, onDone = null) => {
          const wrap = el(`span`, { display: `flex`, alignItems: `center`, gap: `6px`, flex: `1`, minWidth: `0` });
          const input = doc.createElement(`input`);
          input.type = `range`;
          input.min = String(min);
          input.max = String(max);
          input.step = String(step);
          input.value = String(value);
          style(input, { flex: `1`, minWidth: `0` });
          const readout = el(`span`, { width: `42px`, textAlign: `right`, opacity: `0.7` }, shown(value));
          input.oninput = () => {
            onInput(Number(input.value));
            readout.textContent = shown(Number(input.value));
            changed();
            drawCanvas();
          };
          input.onchange = () => (onDone ? onDone() : commit());
          wrap.appendChild(input);
          wrap.appendChild(readout);
          return wrap;
        };
        const choose = (value, choices, onChange) => {
          const select = doc.createElement(`select`);
          style(select, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `3px` });
          for (const [v, text] of choices) {
            const opt = doc.createElement(`option`);
            opt.value = v;
            opt.textContent = text;
            if (v === value) opt.selected = true;
            select.appendChild(opt);
          }
          select.onchange = () => {
            onChange(select.value);
            commit();
            render();
          };
          return select;
        };
        const textBox = (value, onChange) => {
          const input = doc.createElement(`input`);
          input.value = value;
          style(input, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `4px` });
          input.oninput = () => onChange(input.value);
          input.onchange = () => {
            commit();
            render();
          };
          return input;
        };
        const buttonRow = (...buttons) => {
          const line = el(`div`, { display: `flex`, flexWrap: `wrap`, gap: `4px` });
          for (const b of buttons) {
            b.style.marginLeft = `0`;
            line.appendChild(b);
          }
          return line;
        };
        const thumb = (box, size = 36) => {
          const c = doc.createElement(`canvas`);
          c.width = size;
          c.height = size;
          const k = Math.min(size / Math.max(1, box.width), size / Math.max(1, box.height));
          const w = box.width * k;
          const h = box.height * k;
          try {
            c.getContext(`2d`).drawImage(img, box.x, box.y, box.width, box.height, (size - w) / 2, (size - h) / 2, w, h);
          } catch (err) { /* blank thumbnail */ }
          style(c, { width: `${size}px`, height: `${size}px`, background: CHECKER, borderRadius: `4px`, flex: `0 0 auto` });
          return c;
        };

        // ---- views ----
        // Each step keeps its own zoom and pan: x, y are where the origin sits
        // on the canvas, z is pixels per image pixel.
        const views = { cut: null, build: null };
        const fitCut = () => {
          const z = Math.min(canvas.width / img.width, canvas.height / img.height) * 0.92 || 1;
          views.cut = { z, x: (canvas.width - img.width * z) / 2, y: (canvas.height - img.height * z) / 2 };
        };
        const fitBuild = () => {
          views.build = { z: 1, x: canvas.width / 2, y: canvas.height * 0.82 };
        };
        // The game draws a plant at CharacterScale of its pixel size, so
        // "game size" is that, and a lawn tile is its width divided by it.
        const GAME_SCALE = getModule(`Character`)?.CharacterScale ?? 0.42;
        const TILE = { w: (Square?.SquareWidth ?? 68) / GAME_SCALE, h: (Square?.SquareHeight ?? 80) / GAME_SCALE };
        const view = () => views[mode];
        const sizeCanvas = () => {
          const rect = canvas.getBoundingClientRect?.() ?? { width: 800, height: 600 };
          const w = Math.max(200, Math.round(rect.width));
          const h = Math.max(120, Math.round(rect.height));
          if (canvas.width !== w || canvas.height !== h) {
            // The dock grows and shrinks with the clip picked: keep the
            // ground line where it was, as a share of the stage.
            if (views.build && canvas.height) views.build.y *= h / canvas.height;
            canvas.width = w;
            canvas.height = h;
          }
          if (!views.cut) fitCut();
          if (!views.build) fitBuild();
        };
        const toWorld = (ev) => {
          const rect = canvas.getBoundingClientRect();
          const v = view();
          const sx = (ev.clientX - rect.left) * (canvas.width / rect.width);
          const sy = (ev.clientY - rect.top) * (canvas.height / rect.height);
          return { x: (sx - v.x) / v.z, y: (sy - v.y) / v.z, sx, sy };
        };

        // ---- poses ----
        const restOf = (p) => M.at(p.x, p.y, p.rotation);
        const posesAt = (frame) => {
          const motion = motionNow();
          const clip = motion.clips.find((c) => c.name === onClip);
          const rest = pieces.map(restOf);
          const world = new Array(pieces.length);
          for (const i of boneOrder(motion.parents)) {
            const parent = motion.parents[i];
            const local = parent >= 0 ? M.mul(M.inv(rest[parent]), rest[i]) : rest[i];
            const track = frame === null ? null : clip?.bones?.[i];
            const turn = sampleTrack(track?.rotate, frame, 0);
            const mx = sampleTrack(track?.move, frame, 0, 1);
            const my = sampleTrack(track?.move, frame, 0, 2);
            const gx = sampleTrack(track?.size, frame, 1, 1);
            const gy = sampleTrack(track?.size, frame, 1, 2);
            const m = M.scale(M.at(local[4] + mx, local[5] + my, M.angle(local) + turn), gx, gy);
            world[i] = parent >= 0 ? M.mul(world[parent], m) : M.mul(plantSize(), m);
          }
          return world;
        };
        // The whole plant's size sits on the root, so everything is laid out
        // in root space and a drag is turned back into it.
        const plantSize = () => [options.sizeX ?? 1, 0, 0, options.sizeY ?? 1, 0, 0];
        const rootPoint = (at) => ({ ...at, x: at.x / (options.sizeX || 1), y: at.y / (options.sizeY || 1) });
        const pictureMatrix = (p, world) => {
          const scale = pictureScale(p);
          return M.scale(world, scale.x, scale.y);
        };
        let dragging = null;
        // The layout is the rest pose; a clip shows the frame at the red line.
        const frameNow = () => (mode === `build` && onClip ? liveFrame() : null);
        const pieceAt = (pt, poses) => {
          for (let i = pieces.length - 1; i >= 0; i--) {
            const p = pieces[i];
            if (viewOff(p.id)) continue;
            const local = M.mul(M.inv(pictureMatrix(p, poses[i])), [1, 0, 0, 1, pt.x, pt.y]);
            const pivot = pivotOf(p);
            const lx = local[4] + pivot.x * p.box.width;
            const ly = local[5] + pivot.y * p.box.height;
            if (lx >= 0 && ly >= 0 && lx <= p.box.width && ly <= p.box.height) return i;
          }
          return -1;
        };

        // ---- drawing ----
        const drawCut = (ctx) => {
          const v = view();
          ctx.setTransform(v.z, 0, 0, v.z, v.x, v.y);
          ctx.imageSmoothingEnabled = v.z < 1;
          ctx.drawImage(img, 0, 0);
          const line = 1 / v.z;
          // Where each sheet sits in the combined picture.
          if ((options.sheets?.length ?? 0) > 1) {
            ctx.setLineDash([6 * line, 4 * line]);
            ctx.lineWidth = line;
            ctx.strokeStyle = `rgba(100,210,255,0.5)`;
            for (const r of options.sheets) ctx.strokeRect(r.x - 1, r.y - 1, r.width + 2, r.height + 2);
            ctx.setLineDash([]);
          }
          for (const p of pieces) {
            const on = p.id === selected;
            const also = !on && picked.has(p.id);
            ctx.lineWidth = (on || also ? 2 : 1) * line;
            ctx.strokeStyle = on ? `#4cd964` : also ? `#8fce92` : `rgba(255,255,255,0.55)`;
            ctx.strokeRect(p.box.x, p.box.y, p.box.width, p.box.height);
            if (on) {
              ctx.fillStyle = `#4cd964`;
              const r = 4 * line;
              for (const [cx, cy] of corners(p.box)) ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
            }
          }
          if (dragging?.kind === `draw`) {
            const b = dragging.box;
            ctx.lineWidth = 1.5 * line;
            ctx.setLineDash([4 * line, 3 * line]);
            ctx.strokeStyle = `#ffd60a`;
            ctx.strokeRect(b.x, b.y, b.width, b.height);
            ctx.setLineDash([]);
          }
        };
        const drawBuild = (ctx) => {
          const v = view();
          const frame = frameNow();
          const poses = posesAt(frame);
          const looks = looksAt(frame);
          if (!clean) {
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.strokeStyle = `rgba(255,255,255,0.18)`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(0, v.y);
            ctx.lineTo(canvas.width, v.y);
            ctx.stroke();
            // One lawn tile, standing on the ground line: how big the plant
            // is next to the squares it'll be planted in.
            ctx.setLineDash([5, 4]);
            ctx.strokeStyle = `rgba(255,255,255,0.14)`;
            ctx.strokeRect(v.x - (TILE.w * v.z) / 2, v.y - TILE.h * v.z, TILE.w * v.z, TILE.h * v.z);
            ctx.setLineDash([]);
          }
          if (onClip && onion && frame !== null) drawOnion(ctx, frame);
          pieces.forEach((p, i) => {
            if (!viewOff(p.id)) drawPiece(ctx, p, poses[i], lookFor(p, looks[i]), 1);
          });
          if (clean) return;
          if (onClip && showBones) drawBones(ctx, poses);
          // The rest of the selection, outlined more faintly.
          pieces.forEach((q, j) => {
            if (q.id === selected || !picked.has(q.id)) return;
            const mq = pictureMatrix(q, poses[j]);
            const pq = pivotOf(q);
            ctx.setTransform(v.z * mq[0], v.z * mq[1], v.z * mq[2], v.z * mq[3], v.x + v.z * mq[4], v.y + v.z * mq[5]);
            ctx.lineWidth = 1.5 / (v.z * Math.abs(q.scale || 1));
            ctx.strokeStyle = `#8fce92`;
            ctx.strokeRect(-pq.x * q.box.width, -pq.y * q.box.height, q.box.width, q.box.height);
          });
          const i = pieces.findIndex((p) => p.id === selected);
          if (i < 0) return;
          const p = pieces[i];
          const m = pictureMatrix(p, poses[i]);
          const pivot = pivotOf(p);
          const s = Math.abs(p.scale || 1);
          ctx.setTransform(v.z * m[0], v.z * m[1], v.z * m[2], v.z * m[3], v.x + v.z * m[4], v.y + v.z * m[5]);
          ctx.lineWidth = 1.5 / (v.z * s);
          ctx.strokeStyle = `#4cd964`;
          ctx.strokeRect(-pivot.x * p.box.width, -pivot.y * p.box.height, p.box.width, p.box.height);
          ctx.fillStyle = pivoting ? `#ffd60a` : `#4cd964`;
          ctx.beginPath();
          ctx.arc(0, 0, 4.5 / (v.z * s), 0, Math.PI * 2);
          ctx.fill();
        };
        const drawCanvas = () => {
          if (!rigWindow) return;
          sizeCanvas();
          const ctx = canvas.getContext(`2d`);
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          if (mode === `cut`) drawCut(ctx);
          else drawBuild(ctx);
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          drawTimeline();
        };

        // ---- cut: boxes ----
        const corners = (b) => [[b.x, b.y], [b.x + b.width, b.y], [b.x, b.y + b.height], [b.x + b.width, b.y + b.height]];
        const clampBox = (b) => {
          const x = Math.max(0, Math.min(img.width - 1, Math.round(b.x)));
          const y = Math.max(0, Math.min(img.height - 1, Math.round(b.y)));
          return {
            x,
            y,
            width: Math.max(1, Math.min(img.width - x, Math.round(b.width))),
            height: Math.max(1, Math.min(img.height - y, Math.round(b.height))),
          };
        };
        const boxFrom = (a, b) => ({ x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), width: Math.abs(a.x - b.x), height: Math.abs(a.y - b.y) });
        let alpha = null;
        const alphaAt = (x, y) => {
          if (!alpha) {
            const c = doc.createElement(`canvas`);
            c.width = img.width;
            c.height = img.height;
            const ctx = c.getContext(`2d`);
            ctx.drawImage(img, 0, 0);
            alpha = ctx.getImageData(0, 0, img.width, img.height).data;
          }
          return alpha[((y * img.width) + x) * 4 + 3] ?? 0;
        };
        // Shrink a box to the opaque pixels inside it.
        const trim = (p) => {
          const b = p.box;
          let minX = Infinity;
          let minY = Infinity;
          let maxX = -1;
          let maxY = -1;
          for (let y = b.y; y < b.y + b.height; y++) {
            for (let x = b.x; x < b.x + b.width; x++) {
              if (alphaAt(x, y) > 16) {
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
              }
            }
          }
          if (maxX < 0) return false;
          p.box = { x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1 };
          return true;
        };
        const overlap = (a, b) => {
          const w = Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x);
          const h = Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y);
          if (w <= 0 || h <= 0) return 0;
          return (w * h) / Math.min(a.width * a.height, b.width * b.height);
        };
        const findPieces = () => {
          let added = 0;
          for (const box of scan()) {
            if (pieces.some((p) => overlap(p.box, box) > 0.4)) continue;
            pieces.push(makePiece({ box, fresh: true }));
            added++;
          }
          status = added ? `Found ${added} more piece(s).` : `Nothing new found: every lump already has a box.`;
          commit();
          render();
        };
        // Anything hanging off a deleted piece moves up to what that piece
        // hung off, rather than falling to the ground.
        const removePieces = (ids) => {
          const gone = new Set(ids);
          if (!gone.size) return;
          for (const p of pieces) {
            let parent = p.parent;
            while (parent && gone.has(parent)) parent = byId(parent)?.parent ?? null;
            p.parent = parent;
          }
          pieces = pieces.filter((p) => !gone.has(p.id));
          selectOnly(pieces[0]?.id ?? null);
          status = `${gone.size === 1 ? `Piece` : `${gone.size} pieces`} deleted. Ctrl+Z brings ${gone.size === 1 ? `it` : `them`} back.`;
          commit();
          render();
        };
        const removePiece = (id) => removePieces([id]);

        // A copy uses the same art, so one drawing of a leaf can be three
        // leaves. Copies land just beside the originals, keep their motion
        // and sync, and anything copied along with its parent stays attached
        // to the copy.
        const freeName = (base, taken) => {
          const stem = String(base).replace(/ \d+$/, ``);
          let n = 2;
          while (taken.has(`${stem} ${n}`)) n++;
          taken.add(`${stem} ${n}`);
          return `${stem} ${n}`;
        };
        const clonePieces = (ids) => {
          const originals = pieces.filter((p) => ids.includes(p.id));
          if (!originals.length) return;
          const map = new Map();
          const taken = new Set(pieces.map((p) => p.name));
          const copies = originals.map((p) => {
            const copy = makePiece({ ...p, id: undefined, name: freeName(p.name, taken), x: p.x + (mode === `build` ? 18 : 0), y: p.y });
            map.set(p.id, copy.id);
            return copy;
          });
          for (const copy of copies) if (map.has(copy.parent)) copy.parent = map.get(copy.parent);
          const at = Math.max(...originals.map((p) => pieces.indexOf(p))) + 1;
          pieces.splice(at, 0, ...copies);
          picked = new Set(copies.map((c) => c.id));
          selected = copies[0].id;
          status = mode === `cut`
            ? `Copied. The copy uses the same art; in step 2 it's a separate piece you can place anywhere.`
            : `Copied, just to the right of the original${copies.length > 1 ? `s` : ``}.`;
          commit();
          render();
        };

        // Sync groups: pieces whose motion shares one timing.
        let syncCount = pieces.reduce((n, p) => Math.max(n, Number(/^s(\d+)$/.exec(p.sync ?? ``)?.[1]) || 0), 0);
        const syncPieces = (list, opposite) => {
          if (list.length < 2) return;
          const group = `s${++syncCount}`;
          list.forEach((p, k) => {
            p.sync = group;
            p.syncOpposite = opposite && k % 2 === 1;
          });
          status = opposite
            ? `${list.length} pieces now move as mirror images of each other.`
            : `${list.length} pieces now move together, in time.`;
          commit();
          render();
        };
        const unsyncPieces = (list) => {
          for (const p of list) {
            p.sync = null;
            p.syncOpposite = false;
          }
          commit();
          render();
        };
        const SYNC_COLOURS = [`#ff9f0a`, `#64d2ff`, `#bf5af2`, `#ff375f`, `#ffd60a`, `#30d158`];
        const syncColour = (group) => {
          const groups = [...new Set(pieces.map((p) => p.sync).filter(Boolean))];
          return SYNC_COLOURS[groups.indexOf(group) % SYNC_COLOURS.length];
        };

        // Fresh pieces are stood in a column above the ground when first
        // seen in the build step, biggest at the bottom.
        const standFresh = () => {
          const fresh = pieces.filter((p) => p.fresh);
          if (!fresh.length) return;
          let top = 0;
          for (const p of pieces) {
            if (!p.fresh) top = Math.min(top, p.y - p.box.height * (p.scale ?? 1));
          }
          fresh.sort((a, b) => (b.box.width * b.box.height) - (a.box.width * a.box.height));
          let y = top;
          for (const p of fresh) {
            p.x = 0;
            p.y = y;
            y -= p.box.height * 0.55;
            p.fresh = false;
          }
          commit();
        };

        // ---- mouse ----
        const endDrag = () => {
          doc.removeEventListener?.(`mousemove`, onMove, true);
          doc.removeEventListener?.(`mouseup`, onUp, true);
          if (!dragging) return;
          const was = dragging;
          dragging = null;
          if (was.kind === `draw`) {
            const b = clampBox(was.box);
            if (b.width >= 3 && b.height >= 3) {
              const p = makePiece({ box: b, fresh: true });
              pieces.push(p);
              selectOnly(p.id);
              status = `New piece. Give it a name on the right, or press Trim to fit it to the art.`;
            }
          }
          if (was.kind !== `pan`) commit();
          render();
        };
        const onMove = (ev) => {
          if (!dragging) return;
          const at = toWorld(ev);
          const d = dragging;
          const v = view();
          if (d.kind === `pan`) {
            v.x = d.vx + (at.sx - d.sx);
            v.y = d.vy + (at.sy - d.sy);
          } else if (d.kind === `draw`) {
            d.box = boxFrom(d.from, at);
          } else if (d.kind === `movebox`) {
            d.piece.box = clampBox({ ...d.box, x: d.box.x + at.x - d.from.x, y: d.box.y + at.y - d.from.y });
          } else if (d.kind === `resize`) {
            const [ox, oy] = d.anchor;
            d.piece.box = clampBox(boxFrom({ x: ox, y: oy }, at));
          } else if (d.kind === `move`) {
            const to = rootPoint(at);
            const dx = Math.round(to.x - d.from.x);
            const dy = Math.round(to.y - d.from.y);
            for (const [p, x, y] of d.start) {
              p.x = x + dx;
              p.y = y + dy;
            }
            changed();
          } else if (triggerDrag(d, at)) {
            // a trigger, in a clip
          } else if (d.kind === `turn`) {
            const p = d.piece;
            const to = rootPoint(at);
            const a0 = Math.atan2(d.from.y - p.y, d.from.x - p.x);
            const a1 = Math.atan2(to.y - p.y, to.x - p.x);
            const by = ((a1 - a0) * 180) / Math.PI;
            const spin = M.at(p.x, p.y, by);
            for (const [q, x, y, r] of d.start) {
              const moved = M.mul(M.mul(spin, M.at(-p.x, -p.y, 0)), [1, 0, 0, 1, x, y]);
              q.x = Math.round(moved[4]);
              q.y = Math.round(moved[5]);
              q.rotation = Math.round((r + by) * 10) / 10;
            }
            changed();
          }
          drawCanvas();
        };
        const onUp = () => endDrag();
        canvas.onmousedown = (ev) => {
          ev.preventDefault();
          rigWindow.focus?.();
          const at = toWorld(ev);
          const v = view();
          // On the document, in the capture phase: the window stops every
          // event from bubbling out to the game, which would include these.
          const listen = () => {
            doc.addEventListener?.(`mousemove`, onMove, true);
            doc.addEventListener?.(`mouseup`, onUp, true);
          };
          if (ev.button !== 0 || ev.altKey) {
            dragging = { kind: `pan`, sx: at.sx, sy: at.sy, vx: v.x, vy: v.y };
            listen();
            return;
          }
          if (mode === `cut`) {
            const p = current();
            const grab = 7 / v.z;
            if (p) {
              const hit = corners(p.box).findIndex(([cx, cy]) => Math.abs(cx - at.x) < grab && Math.abs(cy - at.y) < grab);
              if (hit >= 0) {
                const [ax, ay] = corners(p.box)[3 - hit];
                dragging = { kind: `resize`, piece: p, anchor: [ax, ay] };
                listen();
                return;
              }
            }
            // Smallest box under the pointer, so a piece inside another can
            // still be picked.
            const under = pieces
              .filter((q) => at.x >= q.box.x && at.y >= q.box.y && at.x <= q.box.x + q.box.width && at.y <= q.box.y + q.box.height)
              .sort((a, b) => (a.box.width * a.box.height) - (b.box.width * b.box.height))[0];
            if (under) {
              if (ev.ctrlKey || ev.metaKey) toggle(under.id);
              else if (!picked.has(under.id)) selectOnly(under.id);
              else selected = under.id;
              dragging = { kind: `movebox`, piece: under, box: { ...under.box }, from: at };
              render();
            } else {
              dragging = { kind: `draw`, from: at, box: { x: at.x, y: at.y, width: 0, height: 0 } };
            }
            listen();
            return;
          }
          if (onClip) {
            clipDown(ev, at, listen);
            return;
          }
          const poses = posesAt(null);
          if (pivoting) {
            const i = pieces.findIndex((p) => p.id === selected);
            if (i >= 0) setPivotAt(pieces[i], poses[i], at);
            pivoting = false;
            commit();
            render();
            return;
          }
          const i = pieceAt(at, poses);
          if (i < 0) {
            dragging = { kind: `pan`, sx: at.sx, sy: at.sy, vx: v.x, vy: v.y };
            listen();
            return;
          }
          const p = pieces[i];
          if (ev.ctrlKey || ev.metaKey) {
            toggle(p.id);
            render();
            return;
          }
          if (!picked.has(p.id)) selectOnly(p.id);
          else selected = p.id;
          // Everything picked moves together, with whatever hangs off it.
          const group = [];
          for (const q of [p, ...pickedPieces()]) {
            for (const r of [q, ...descendantsOf(q.id)]) if (!group.includes(r)) group.push(r);
          }
          dragging = ev.shiftKey
            ? { kind: `turn`, piece: p, from: rootPoint(at), start: group.map((q) => [q, q.x, q.y, q.rotation]) }
            : { kind: `move`, from: rootPoint(at), start: group.map((q) => [q, q.x, q.y]) };
          render();
          listen();
        };
        canvas.onwheel = (ev) => {
          ev.preventDefault();
          const at = toWorld(ev);
          const v = view();
          const z = Math.min(12, Math.max(0.1, v.z * (ev.deltaY < 0 ? 1.15 : 1 / 1.15)));
          v.x = at.sx - at.x * z;
          v.y = at.sy - at.y * z;
          v.z = z;
          drawCanvas();
        };
        canvas.oncontextmenu = (ev) => ev.preventDefault();
        canvas.ondblclick = () => {
          side.querySelector?.(`input[data-name="${selected}"]`)?.focus?.();
        };

        // Moving the pivot keeps the picture where it is: the piece's
        // position is the pivot, so it moves by the same amount.
        const setPivotAt = (p, world, at) => {
          const local = M.mul(M.inv(pictureMatrix(p, world)), [1, 0, 0, 1, at.x, at.y]);
          const pivot = pivotOf(p);
          const nx = Math.min(1, Math.max(0, pivot.x + local[4] / p.box.width));
          const ny = Math.min(1, Math.max(0, pivot.y + local[5] / p.box.height));
          movePivot(p, nx, ny);
        };
        const movePivot = (p, nx, ny) => {
          const pivot = pivotOf(p);
          const shift = M.mul(pictureMatrix(p, restOf(p)), [1, 0, 0, 1, (nx - pivot.x) * p.box.width, (ny - pivot.y) * p.box.height]);
          p.x = Math.round(shift[4]);
          p.y = Math.round(shift[5]);
          p.pivotX = Math.round(nx * 100) / 100;
          p.pivotY = Math.round(ny * 100) / 100;
          changed();
        };

        // ---- keys ----
        rigWindow.addEventListener(`keydown`, (ev) => {
          const typing = /^(INPUT|SELECT|TEXTAREA)$/.test(ev.target?.tagName ?? ``) && ev.target.type !== `range` && ev.target.type !== `checkbox`;
          const ctrl = ev.ctrlKey || ev.metaKey;
          if (ctrl && (ev.key === `z` || ev.key === `Z`)) {
            ev.preventDefault();
            if (ev.shiftKey) redo();
            else undo();
            return;
          }
          if (ctrl && (ev.key === `y` || ev.key === `Y`)) {
            ev.preventDefault();
            redo();
            return;
          }
          if (typing) return;
          if (mode === `build` && onClip && clipKey(ev)) return;
          const p = current();
          const step = ev.shiftKey ? 10 : 1;
          const laying = mode === `build` && !onClip;
          const act = (fn) => {
            ev.preventDefault();
            fn();
            commit();
            render();
          };
          const nudge = (dx, dy) => {
            if (mode === `cut`) {
              for (const q of pickedPieces()) q.box = clampBox({ ...q.box, x: q.box.x + dx, y: q.box.y + dy });
              return;
            }
            layoutNudge(dx, dy);
          };
          switch (ev.key) {
            case `Delete`:
            case `Backspace`:
              if (picked.size) {
                ev.preventDefault();
                removePieces([...picked]);
              }
              break;
            case `d`:
            case `D`:
              if (ctrl && picked.size) {
                ev.preventDefault();
                clonePieces([...picked]);
              }
              break;
            case `a`:
            case `A`:
              if (ctrl) {
                ev.preventDefault();
                picked = new Set(pieces.map((q) => q.id));
                render();
              }
              break;
            case `ArrowLeft`: act(() => nudge(-step, 0)); break;
            case `ArrowRight`: act(() => nudge(step, 0)); break;
            case `ArrowUp`: act(() => nudge(0, -step)); break;
            case `ArrowDown`: act(() => nudge(0, step)); break;
            case `q`: case `Q`: if (p && laying) act(() => turnPiece(p, -5 * step)); break;
            case `e`: case `E`: if (p && laying) act(() => turnPiece(p, 5 * step)); break;
            case `+`: case `=`: if (p && laying) act(() => { p.scale = Math.min(4, Math.round((p.scale + 0.05) * 100) / 100); }); break;
            case `-`: case `_`: if (p && laying) act(() => { p.scale = Math.max(0.1, Math.round((p.scale - 0.05) * 100) / 100); }); break;
            case `f`: case `F`: if (p && laying) act(() => { p.flip = !p.flip; }); break;
            case `[`: if (p && (mode === `cut` || laying)) act(() => layer(p, -1)); break;
            case `]`: if (p && (mode === `cut` || laying)) act(() => layer(p, 1)); break;
            case `t`: case `T`: if (p && mode === `cut`) act(() => trim(p)); break;
            case `Tab`: {
              ev.preventDefault();
              const i = pieces.findIndex((q) => q.id === selected);
              selectOnly(pieces[(i + (ev.shiftKey ? pieces.length - 1 : 1)) % Math.max(1, pieces.length)]?.id ?? null);
              render();
              break;
            }
            case `Escape`:
              pivoting = false;
              render();
              break;
            default:
          }
        });
        const layer = (p, by) => {
          if (!p) return;
          const i = pieces.indexOf(p);
          const j = Math.max(0, Math.min(pieces.length - 1, i + by));
          pieces.splice(i, 1);
          pieces.splice(j, 0, p);
        };
        // Moving a piece in the layout takes whatever hangs off it along.
        const layoutGroup = () => {
          const group = [];
          for (const q of pickedPieces()) {
            for (const r of [q, ...descendantsOf(q.id)]) if (!group.includes(r)) group.push(r);
          }
          return group;
        };
        const layoutNudge = (dx, dy) => {
          for (const q of layoutGroup()) {
            q.x += dx;
            q.y += dy;
          }
        };
        // Only the top of each picked branch, so nothing is turned twice.
        const topmost = (list) => list.filter((p) => !list.some((q) => q !== p && descendantsOf(q.id).includes(p)));
        const turnPiece = (p, by) => {
          const spin = M.at(p.x, p.y, by);
          for (const q of descendantsOf(p.id)) {
            const moved = M.mul(M.mul(spin, M.at(-p.x, -p.y, 0)), [1, 0, 0, 1, q.x, q.y]);
            q.x = Math.round(moved[4]);
            q.y = Math.round(moved[5]);
            q.rotation = Math.round((q.rotation + by) * 10) / 10;
          }
          p.rotation = Math.round((p.rotation + by) * 10) / 10;
        };
        const layoutTurn = (by) => {
          for (const p of topmost(pickedPieces())) turnPiece(p, by);
        };
        const layoutScale = (k) => {
          for (const p of pickedPieces()) p.scale = Math.min(4, Math.max(0.1, Math.round(p.scale * k * 100) / 100));
        };

        // ---- building ----
        const build = () => {
          if (!pieces.length) {
            status = `There are no pieces to build from yet.`;
            render();
            return;
          }
          standFresh();
          const layout = pieces.map(({ fresh, ...p }) => p);
          const building = builtState();
          status = `Building...`;
          render();
          applyRig(row.codename, layout, dataUrl, { width: img.width, height: img.height }, { ...options })
            .then((count) => {
              if (!count) {
                status = `Built, but there was no ${row.label} on the lawn to put it on. It goes on the next one planted.`;
              } else {
                const clips = motionNow().clips.map((c) => c.name);
                status = `Wearing it on ${count} plant(s), with ${clips.length} animation(s): ${clips.join(`, `)}.`
                  + (stored(`still:${row.codename}`) ? ` Its still image is kept, but not shown while it has a rig.` : ``);
              }
              remember(saveKey, JSON.stringify({ layout, options }));
              builtAs = building;
              remember(`rigart:${row.codename}`, dataUrl);
              dropLocal(draftKey);
              e.log.info(`[Textures] ${row.label}: ${status}`);
              render();
              drawPanel();
              // Then check it really moves on the lawn, and say so here.
              const live = plantRows().find((r) => r.codename === row.codename)?.plants?.[0];
              const built = status;
              (live ? checkRig(live, true) : Promise.resolve(null)).then((result) => {
                status = `${built} ${rigVerdict(result, row.label)}`;
                render();
              });
            })
            .catch((err) => {
              status = `Couldn't build it: ${err.message}`;
              e.log.error(`[Textures] ${row.label}: ${err.message}`);
              render();
            });
        };

        // ---- the side panel ----
        const tabButton = (which, label) => {
          const b = button(label, () => {
            if (which === `build`) standFresh();
            playAnim(false);
            if (mode !== which) status = ``;
            mode = which;
            pivoting = false;
            render();
          }, mode === which ? undefined : `quiet`);
          b.style.marginLeft = `0`;
          return b;
        };
        const renderHead = () => {
          head.innerHTML = ``;
          head.appendChild(el(`div`, { font: `600 14px system-ui, sans-serif`, marginRight: `8px` }, `Animation maker: ${row.label}`));
          head.appendChild(tabButton(`cut`, `1  Cut out pieces`));
          head.appendChild(tabButton(`build`, `2  Build and animate`));
          head.appendChild(el(`span`, { flex: `1` }));
          // Nothing here reaches the lawn until this is pressed, so it says
          // when there's something it hasn't put on yet.
          const waiting = unbuilt();
          const wear = button(waiting ? `Build and wear *` : `Build and wear`, build);
          wear.title = waiting
            ? `There are changes the plant in the game doesn't have yet. This puts them on it.`
            : `Puts it on the plant in the game.`;
          head.appendChild(wear);
          const undoButton = button(`Undo`, undo, `quiet`);
          const redoButton = button(`Redo`, redo, `quiet`);
          undoButton.disabled = history.length < 2;
          redoButton.disabled = !future.length;
          undoButton.style.opacity = undoButton.disabled ? `0.4` : `1`;
          redoButton.style.opacity = redoButton.disabled ? `0.4` : `1`;
          head.appendChild(undoButton);
          head.appendChild(redoButton);
          head.appendChild(button(libraryOpen ? `Back to editing` : `Saved`, () => {
            libraryOpen = !libraryOpen;
            render();
          }, libraryOpen ? undefined : `quiet`));
          head.appendChild(button(`Fit view`, () => {
            if (mode === `cut`) fitCut();
            else fitBuild();
            drawCanvas();
          }, `quiet`));
          if (mode === `build`) {
            // What it will actually look like on the lawn: the game shrinks
            // plants, so small motions that read here can vanish there.
            head.appendChild(button(`Game size`, () => {
              fitBuild();
              views.build.z = GAME_SCALE * 1.5;
              drawCanvas();
            }, `quiet`));
            head.appendChild(button(clean ? `Show handles` : `Just the art`, () => {
              clean = !clean;
              render();
            }, `quiet`));
          }
          head.appendChild(button(`Close`, () => rigWindow?.__close?.(), `warn`));
        };

        const pieceRow = (p, depth, extra) => {
          const line = el(`div`, {
            display: `flex`, alignItems: `center`, gap: `6px`, padding: `3px 4px`, paddingLeft: `${4 + depth * 14}px`,
            borderRadius: `4px`, cursor: `pointer`,
            background: p.id === selected ? `#24502a` : picked.has(p.id) ? `#1c3a20` : `transparent`,
          });
          line.onclick = (ev) => {
            if (ev?.ctrlKey || ev?.metaKey) toggle(p.id);
            else selectOnly(p.id);
            render();
          };
          line.appendChild(thumb(p.box, 30));
          if (p.sync) line.appendChild(el(`span`, { width: `8px`, height: `8px`, borderRadius: `50%`, flex: `0 0 auto`, background: syncColour(p.sync) }));
          if (extra) extra(line);
          else line.appendChild(el(`span`, { flex: `1`, overflow: `hidden`, textOverflow: `ellipsis`, whiteSpace: `nowrap`, opacity: viewOff(p.id) ? `0.45` : `1` },
            `${p.name}${p.hidden ? ` (hidden in game)` : ``}`));
          // Editor-only visibility, to get at pieces behind others.
          const eye = button(viewOff(p.id) ? `Show` : `Hide`, () => toggleView(p.id), `quiet`);
          eye.title = `Show or hide it here while you work. The game still draws it.`;
          eye.style.padding = `2px 6px`;
          line.appendChild(eye);
          return line;
        };

        // More sheets: packed in beside this picture, which is saved at once
        // so nothing already cut loses its art, and the editor opens again
        // on the combined picture with every lump on the new sheets boxed.
        const addSheets = () => pickFiles((urls, names) => {
          status = `Adding ${names.join(`, `)}...`;
          render();
          combineSheets([dataUrl, ...urls])
            .then((out) => {
              const before = options.sheets?.length ? options.sheets : [{ x: 0, y: 0, width: img.width, height: img.height }];
              const added = out.regions.slice(1);
              options.sheets = [...before, ...added];
              saveDraft();
              remember(`rigart:${row.codename}`, out.dataUrl);
              rigWindow?.__close?.();
              openRig(row, out.dataUrl, {
                mode: `cut`,
                newRegions: added,
                status: `Added ${names.length} sheet${names.length === 1 ? `` : `s`} (${names.join(`, `)}). `
                  + `The dashed outlines show where each sheet sits; the new pieces have boxes, ready to name.`,
              });
            })
            .catch((err) => {
              status = `Couldn't add ${names.length === 1 ? `that sheet` : `those sheets`}: ${err.message}.`;
              render();
            });
        });

        const renderCut = () => {
          const help = section(`Cut out pieces`);
          help.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.45` },
            `Drag on an empty part of the picture to draw a box. Drag a box to move it, drag its corners to resize. `
            + `Scroll to zoom, right-drag to pan. Each box becomes one moving part.`));
          const p = current();
          help.appendChild(buttonRow(
            button(`Add sprite sheets`, addSheets),
            button(`Find pieces`, findPieces, `quiet`),
            button(`Trim to fit`, () => {
              if (p && trim(p)) {
                commit();
                render();
              }
            }, `quiet`),
            button(`Copy`, () => clonePieces([...picked]), `quiet`),
            button(`Delete`, () => removePieces([...picked]), `warn`),
            button(`Clear all`, () => {
              pieces = [];
              selectOnly(null);
              commit();
              render();
            }, `warn`),
          ));
          const list = section(`Pieces (${pieces.length})`);
          if (!pieces.length) list.appendChild(el(`div`, { opacity: `0.7` }, `No pieces yet. Draw a box round each part, or press Find pieces.`));
          for (const piece of pieces) {
            list.appendChild(pieceRow(piece, 0, (line) => {
              const name = textBox(piece.name, (value) => {
                piece.name = value;
              });
              name.dataset.name = piece.id;
              name.onfocus = () => {
                if (!picked.has(piece.id)) selectOnly(piece.id);
                else selected = piece.id;
                drawCanvas();
              };
              line.appendChild(name);
              const cross = button(`x`, () => removePiece(piece.id), `warn`);
              cross.style.padding = `2px 7px`;
              line.appendChild(cross);
            }));
          }
          const next = section();
          next.appendChild(buttonRow(button(`Next: build the plant`, () => {
            standFresh();
            status = ``;
            mode = `build`;
            render();
          })));
          next.appendChild(el(`div`, { opacity: `0.6` }, `Keys: Delete removes, arrows nudge (Shift for 10), T trims, Tab picks the next piece, Ctrl+Z undoes.`));
        };

        // ---- layout: the plant standing still ----
        // Loops a piece can run in every clip. "My own keyframes" from before
        // 0.18 still plays, but is only offered to a piece that has it.
        const loopChoices = (now) => MOTIONS
          .filter((m) => m !== `custom` || now === `custom`)
          .map((m) => [m, m === `custom` ? `My own loop (from before)` : MOTION_LABELS[m]]);
        const renderPieceList = () => {
          const list = section(`Pieces`);
          if (!pieces.length) list.appendChild(el(`div`, { opacity: `0.7` }, `No pieces. Go back to step 1 and cut some out.`));
          const parents = parentsOf(pieces);
          const depth = (i) => {
            let d = 0;
            for (let at = parents[i]; at >= 0 && d < pieces.length; at = parents[at]) d++;
            return d;
          };
          // Listed as a tree, roots first, each followed by what hangs off it.
          const shown = new Set();
          const listFrom = (i) => {
            if (shown.has(i)) return;
            shown.add(i);
            list.appendChild(pieceRow(pieces[i], depth(i)));
            pieces.forEach((_, j) => {
              if (parents[j] === i) listFrom(j);
            });
          };
          pieces.forEach((_, i) => {
            if (parents[i] < 0) listFrom(i);
          });
          pieces.forEach((_, i) => listFrom(i));
        };

        const renderLayout = () => {
          const p = current();
          const motion = motionNow();
          const tools = section();
          tools.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4` },
            `This is the plant standing still. Drag a piece to move it, Shift+drag to turn it, or use the buttons under the stage. `
            + `To animate, pick a clip under the stage: Idle, Attack and the rest.`));
          tools.appendChild(buttonRow(
            button(`Add piece`, () => {
              mode = `cut`;
              pivoting = false;
              status = `Draw a box round the new piece on the picture (or pick one and press Copy). It's waiting in step 2 when you come back.`;
              render();
            }, `quiet`),
            button(picked.size > 1 ? `Copy ${picked.size}` : `Copy`, () => clonePieces([...picked]), `quiet`),
            button(picked.size > 1 ? `Delete ${picked.size}` : `Delete`, () => removePieces([...picked]), `warn`),
          ));
          tools.appendChild(el(`div`, { opacity: `0.6` }, `Ctrl+click to pick more than one. Ctrl+D copies, Delete deletes, Ctrl+A picks everything.`));

          if (picked.size > 1) {
            // Several at once: sync them, or set them all the same.
            const group = pickedPieces();
            const box = section(`${group.length} pieces picked`);
            const strip = el(`div`, { display: `flex`, flexWrap: `wrap`, gap: `4px` });
            for (const q of group) strip.appendChild(thumb(q.box, 30));
            box.appendChild(strip);
            const synced = group.every((q) => q.sync && q.sync === group[0].sync);
            box.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4` }, synced
              ? group.some((q) => q.syncOpposite)
                ? `Their loops are mirror images: when one swings left the other swings right, on the same beat.`
                : `Their loops run together, on the same beat.`
              : `Sync makes their loops run on one shared beat instead of each keeping its own.`));
            box.appendChild(buttonRow(
              button(`Move together`, () => syncPieces(group, false), synced && !group.some((q) => q.syncOpposite) ? undefined : `quiet`),
              button(`Mirror each other`, () => syncPieces(group, true), synced && group.some((q) => q.syncOpposite) ? undefined : `quiet`),
              button(`Stop syncing`, () => unsyncPieces(group), `quiet`),
            ));
            const same = (field) => group.every((q) => q[field] === group[0][field]);
            box.appendChild(labelled(`All loop`, choose(same(`motion`) ? group[0].motion : ``,
              [...(same(`motion`) ? [] : [[``, `(mixed)`]]), ...loopChoices(group[0].motion)],
              (value) => {
                if (!value) return;
                for (const q of group) q.motion = value;
              })));
            box.appendChild(labelled(`All by`, range(group[0].amount, 0, 3, 0.1, (v) => {
              for (const q of group) q.amount = v;
            }, (v) => `${v}x`)));
            const ids = new Set(group.flatMap((q) => [q.id, ...descendantsOf(q.id).map((r) => r.id)]));
            box.appendChild(labelled(`Attach all to`, choose(same(`parent`) ? group[0].parent ?? `` : `-`,
              [...(same(`parent`) ? [] : [[`-`, `(mixed)`]]), [``, `nothing (stand alone)`], ...pieces.filter((q) => !ids.has(q.id)).map((q) => [q.id, q.name])],
              (value) => {
                if (value !== `-`) for (const q of group) q.parent = value || null;
              })));
          } else if (p) {
            const box = section();
            const top = el(`div`, { display: `flex`, alignItems: `center`, gap: `8px` });
            top.appendChild(thumb(p.box, 44));
            const name = textBox(p.name, (value) => {
              p.name = value;
            });
            name.dataset.name = p.id;
            top.appendChild(name);
            box.appendChild(top);
            if (p.sync) {
              const mates = pieces.filter((q) => q.sync === p.sync && q.id !== p.id);
              const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px` });
              line.appendChild(el(`span`, { width: `8px`, height: `8px`, borderRadius: `50%`, background: syncColour(p.sync) }));
              line.appendChild(el(`span`, { flex: `1`, opacity: `0.8` },
                `${p.syncOpposite ? `Mirrors` : `In time with`} ${mates.map((q) => q.name).join(`, `) || `nothing`}`));
              line.appendChild(button(`Unsync`, () => unsyncPieces([p]), `quiet`));
              box.appendChild(line);
            }
            const below = new Set([p.id, ...descendantsOf(p.id).map((q) => q.id)]);
            box.appendChild(labelled(`Attached to`, choose(p.parent ?? ``,
              [[``, `nothing (stands alone)`], ...pieces.filter((q) => !below.has(q.id)).map((q) => [q.id, q.name])],
              (value) => {
                p.parent = value || null;
              })));
            box.appendChild(labelled(`Loop`, choose(p.motion, loopChoices(p.motion), (value) => {
              p.motion = value;
            })));
            box.appendChild(labelled(`How much`, range(p.amount, 0, 3, 0.1, (v) => {
              p.amount = v;
            }, (v) => `${v}x`)));
            box.appendChild(labelled(`Turn`, range(p.rotation, -180, 180, 1, (v) => turnPiece(p, v - p.rotation), (v) => `${v}deg`)));
            box.appendChild(labelled(`Size`, range(p.scale, 0.1, 4, 0.05, (v) => {
              p.scale = v;
            }, (v) => `${v}x`)));
            box.appendChild(labelled(`Stretch wide`, range(p.scaleX ?? 1, 0.2, 3, 0.05, (v) => {
              p.scaleX = v;
            }, (v) => `${v}x`)));
            box.appendChild(labelled(`Stretch tall`, range(p.scaleY ?? 1, 0.2, 3, 0.05, (v) => {
              p.scaleY = v;
            }, (v) => `${v}x`)));
            const mirror = doc.createElement(`input`);
            mirror.type = `checkbox`;
            mirror.checked = p.flip;
            mirror.onchange = () => {
              p.flip = mirror.checked;
              commit();
              drawCanvas();
            };
            box.appendChild(labelled(`Mirror`, mirror));
            const pivotButton = button(pivoting ? `Click the plant...` : `Place by clicking`, () => {
              pivoting = !pivoting;
              render();
            }, pivoting ? undefined : `quiet`);
            box.appendChild(labelled(`Turns about`, buttonRow(
              pivotButton,
              button(`Base`, () => { movePivot(p, 0.5, 1); commit(); render(); }, `quiet`),
              button(`Middle`, () => { movePivot(p, 0.5, 0.5); commit(); render(); }, `quiet`),
              button(`Top`, () => { movePivot(p, 0.5, 0); commit(); render(); }, `quiet`),
            )));
            box.appendChild(labelled(`Layer`, buttonRow(
              button(`Send back`, () => { layer(p, -1); commit(); render(); }, `quiet`),
              button(`Bring forward`, () => { layer(p, 1); commit(); render(); }, `quiet`),
            )));
            const hideBox = doc.createElement(`input`);
            hideBox.type = `checkbox`;
            hideBox.checked = !!p.hidden;
            hideBox.onchange = () => {
              p.hidden = hideBox.checked;
              commit();
              render();
            };
            box.appendChild(labelled(`Hidden`, hideBox));
            box.appendChild(el(`div`, { opacity: `0.65`, lineHeight: `1.4` },
              `Hidden in game until a Show trigger in a clip shows it: a flash, a spit, an extra arm. Drawn faintly here so you can place it.`));
          }

          renderPieceList();

          const loops = section(`Loops`);
          loops.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4` },
            `Each piece's loop (Loop, above) plays in every clip, under any triggers there, unless it's switched off in that clip. These set all of them.`));
          loops.appendChild(labelled(`Sway`, range(options.sway, 0, 20, 0.5, (v) => {
            options.sway = v;
          }, (v) => `${v}`)));
          loops.appendChild(labelled(`Speed`, range(options.speed, 0.25, 4, 0.25, (v) => {
            options.speed = v;
          }, (v) => `${v}x`)));
          loops.appendChild(labelled(`Style`, choose(options.style, [[`alternate`, `Neighbours opposite`], [`wave`, `Wave up the plant`]], (value) => {
            options.style = value;
          })));
          loops.appendChild(el(`div`, { opacity: `0.6`, lineHeight: `1.4` }, template
            ? `${motion.clips.length} clips, copied from ${row.label} itself with their timing, so it attacks and dies on cue.`
            : `Idle, Shoot and Food. ${row.label}'s own clip list couldn't be read, so these stand in.`));

          const whole = section(`Whole plant`);
          whole.appendChild(labelled(`Size`, range(options.sizeX ?? 1, 0.3, 3, 0.05, (v) => {
            options.sizeX = v;
            options.sizeY = v;
          }, (v) => `${v}x`, () => {
            commit();
            render();
          })));
          whole.appendChild(labelled(`Width`, range(options.sizeX ?? 1, 0.3, 3, 0.05, (v) => {
            options.sizeX = v;
          }, (v) => `${v}x`)));
          whole.appendChild(labelled(`Height`, range(options.sizeY ?? 1, 0.3, 3, 0.05, (v) => {
            options.sizeY = v;
          }, (v) => `${v}x`)));

          renderOwnClips();

          const done = section();
          done.appendChild(buttonRow(
            button(`Upside down in game? Flip`, () => {
              flipRigs();
              status = `Flipped. Every rig is rebuilt mirrored top to bottom, and that is remembered.`;
              render();
            }, `quiet`),
            button(`Add sprite sheets`, addSheets, `quiet`),
          ));
          done.appendChild(el(`div`, { opacity: `0.6`, lineHeight: `1.4` },
            `Scroll to zoom, drag the background to pan. Keys: arrows nudge, Q/E turn, +/- size, F mirrors, [ ] layer, Ctrl+Z undoes. `
            + `Build and wear (top right) puts it on the plant.`));
        };

        const render = () => {
          if (!rigWindow) return;
          const scroll = side.scrollTop;
          renderHead();
          renderDock();
          side.innerHTML = ``;
          if (status) side.appendChild(el(`div`, { background: `#1f3a24`, borderRadius: `6px`, padding: `6px 8px`, lineHeight: `1.4` }, status));
          if (libraryOpen) renderLibrary();
          else if (mode === `cut`) renderCut();
          else if (onClip) renderClip();
          else renderLayout();
          side.scrollTop = scroll;
          // Whatever had focus may have just been rebuilt away; the keys
          // only reach the editor while it has focus.
          const active = doc.activeElement;
          if (!active || active === doc.body || active.isConnected === false) rigWindow.focus?.({ preventScroll: true });
          drawCanvas();
        };

        // ---- clips: triggers on a timeline ----
        // Layout is the plant standing still. Pick a clip under the stage and
        // the same stage edits that clip instead, the way the GD editor puts
        // a trigger where its music line is: drag a piece and it gets a Move
        // trigger at the red line, Shift+drag a Rotate, and the red line
        // jumps to where the trigger ends so the next drag carries on from
        // there. Nothing about the layout changes while a clip is picked.
        let playhead = 0;
        let animPlaying = false;
        let animStart = 0;
        let animSpeed = 1;
        let onion = false;
        let showBones = false;
        let nudgeStep = 5;
        let triggerCopy = null;
        let copyTo = null;
        let tlScroll = 0;
        const TRIGGER_LEN = 8;
        const TRIGGER_COLOURS = { move: `#3a8ee6`, rotate: `#e69a3a`, scale: `#a45de6`, alpha: `#9a9a9a`, show: `#3fbf5f`, hide: `#d9534f`, picture: `#e6c63a` };
        const TRIGGER_HELP = {
          move: `Slides the pieces by this much. A piece moves in whatever it's attached to, and takes what's attached to it along.`,
          rotate: `Turns the pieces about their pivots by this many degrees, taking what's attached along.`,
          scale: `Sizes the pieces by this much: 2 is twice as big, 0.5 half.`,
          alpha: `Fades the pieces to this opacity, from whatever it was.`,
          show: `Shows the pieces from this frame on. For pieces hidden in the layout, or hidden by a Hide trigger.`,
          hide: `Hides the pieces from this frame on.`,
          picture: `Swaps each piece's picture for another piece's from this frame on: blinks, mouths, a different leaf.`,
        };
        const currentClip = () => (onClip ? motionNow().clips.find((c) => c.name === onClip) ?? null : null);
        const clipLength = () => Math.max(1, currentClip()?.duration ?? 1);
        const clipAnim = (make, name = onClip) => {
          if (!name) return null;
          if (!options.anim && !make) return null;
          options.anim ??= {};
          if (!options.anim[name] && make) options.anim[name] = {};
          return options.anim[name] ?? null;
        };
        const triggersIn = (name = onClip) => clipAnim(false, name)?.triggers ?? [];
        const triggerById = (id) => (id ? triggersIn().find((t) => t.id === id) ?? null : null);
        const triggersOn = (id) => byStart(triggersIn().filter((t) => t.targets.includes(id)));
        const endOf = (t) => Math.min(clipLength(), t.f + (t.d || 0));
        const liveFrame = () => {
          const clip = currentClip();
          if (!clip) return 0;
          if (!animPlaying) return Math.min(playhead, clip.duration);
          const f = ((Date.now() - animStart) / 1000) * motionNow().fps * animSpeed;
          return f % Math.max(1, clip.duration);
        };
        const playAnim = (on) => {
          if (on === animPlaying) return;
          if (on) animStart = Date.now() - (playhead / (motionNow().fps * animSpeed)) * 1000;
          else playhead = Math.round(liveFrame());
          animPlaying = on;
        };
        const goFrame = (f) => {
          playAnim(false);
          playhead = Math.max(0, Math.min(clipLength(), Math.round(f)));
        };
        const pickClip = (name) => {
          playAnim(false);
          status = ``;
          onClip = name;
          triggerSel = null;
          playhead = 0;
          pivoting = false;
          render();
        };
        const spreadFor = (type, list) => (CARRIES.has(type) ? topmost(list) : list).map((p) => p.id);
        const addTrigger = (type, fields = {}, list = pickedPieces()) => {
          const own = clipAnim(true);
          own.triggers ??= [];
          const length = clipLength();
          const f = Math.max(0, Math.min(length, Math.round(liveFrame())));
          const d = INSTANT.has(type) ? 0 : Math.max(0, Math.min(TRIGGER_LEN, length - f));
          const t = {
            id: nextTriggerId(), type, targets: spreadFor(type, list), f, d,
            ease: type === `alpha` ? `none` : `out`, rate: 2, ...TRIGGER_REST[type], ...fields,
          };
          own.triggers.push(t);
          triggerSel = t.id;
          changed();
          return t;
        };
        const dropTrigger = (t) => {
          const own = clipAnim(false);
          if (!own?.triggers) return;
          own.triggers = own.triggers.filter((other) => other !== t);
          if (triggerSel === t.id) triggerSel = null;
          changed();
        };
        const duplicateTrigger = (t, at = Math.round(liveFrame())) => {
          const own = clipAnim(true);
          own.triggers ??= [];
          const copy = { ...t, id: nextTriggerId(), targets: [...t.targets], f: Math.max(0, Math.min(clipLength(), at)) };
          own.triggers.push(copy);
          triggerSel = copy.id;
          changed();
          return copy;
        };
        // An edit button or arrow key: changes the picked trigger if it's the
        // right kind, or starts a new one at the red line for what's picked.
        const bumpTrigger = (type, change) => {
          let t = triggerById(triggerSel);
          if (!t || t.type !== type) {
            t = addTrigger(type);
            playhead = endOf(t);
          }
          change(t);
          changed();
          return t;
        };

        const eventsOf = (clip) => {
          const out = [];
          let at = 0;
          for (const f of clip?.frame ?? []) {
            for (const ev of f.events ?? []) if (ev?.name) out.push({ f: at, name: ev.name });
            if (f.event) out.push({ f: at, name: f.event });
            if (f.sound) out.push({ f: at, name: `sound: ${f.sound}` });
            at += f.duration ?? 0;
          }
          return out;
        };
        const looksAt = (frame) => {
          const clip = currentClip();
          return pieces.map((p, i) => {
            const track = frame === null ? null : clip?.bones?.[i];
            const shown = track?.show ? pictureAt(track.show, frame) : (p.hidden ? HIDE : null);
            const hidden = shown === HIDE;
            return {
              a: hidden ? 0 : track?.alpha ? sampleTrack(track.alpha, frame, 1) : 1,
              img: hidden ? null : shown,
              hidden,
            };
          });
        };
        // Switched off in the editor only, to get at what's behind: the
        // game never sees it.
        const viewOff = (id) => (options.viewOff ?? []).includes(id);
        const toggleView = (id) => {
          const off = new Set(options.viewOff ?? []);
          if (off.has(id)) off.delete(id);
          else off.add(id);
          options.viewOff = [...off];
          saveDraft();
          render();
        };
        // A piece hidden in game is still drawn faintly, or there'd be no way
        // to see what you're placing or pick it to show it.
        const lookFor = (p, look) => (look.hidden && !clean ? { ...look, a: onClip ? 0.15 : 0.3, img: null } : look);
        const drawPiece = (ctx, p, pose, look, fade) => {
          const shown = (look?.img && byId(look.img)) || p;
          const alpha = Math.max(0, Math.min(1, (look?.a ?? 1) * fade));
          if (alpha <= 0.001) return;
          const v = view();
          const m = pictureMatrix(p, pose);
          ctx.setTransform(v.z * m[0], v.z * m[1], v.z * m[2], v.z * m[3], v.x + v.z * m[4], v.y + v.z * m[5]);
          const pivot = pivotOf(p);
          ctx.globalAlpha = alpha;
          ctx.drawImage(img, shown.box.x, shown.box.y, shown.box.width, shown.box.height,
            -pivot.x * shown.box.width, -pivot.y * shown.box.height, shown.box.width, shown.box.height);
          ctx.globalAlpha = 1;
        };
        const drawBones = (ctx, poses) => {
          const v = view();
          const parents = motionNow().parents;
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.lineWidth = 2;
          pieces.forEach((p, i) => {
            const at = [v.x + v.z * poses[i][4], v.y + v.z * poses[i][5]];
            const parent = parents[i];
            if (parent >= 0) {
              const from = [v.x + v.z * poses[parent][4], v.y + v.z * poses[parent][5]];
              ctx.strokeStyle = picked.has(p.id) ? `rgba(76,217,100,0.9)` : `rgba(100,210,255,0.7)`;
              ctx.beginPath();
              ctx.moveTo(from[0], from[1]);
              ctx.lineTo(at[0], at[1]);
              ctx.stroke();
            }
            ctx.fillStyle = triggersOn(p.id).length ? `#ffd60a` : `#64d2ff`;
            ctx.beginPath();
            ctx.arc(at[0], at[1], 3, 0, Math.PI * 2);
            ctx.fill();
          });
        };
        const drawOnion = (ctx, frame) => {
          const length = clipLength();
          const gap = Math.max(1, Math.round(length / 10));
          for (const off of [-gap, gap]) {
            const f = Math.max(0, Math.min(length, frame + off));
            if (f === frame) continue;
            const poses = posesAt(f);
            const looks = looksAt(f);
            pieces.forEach((p, i) => {
              if (!viewOff(p.id)) drawPiece(ctx, p, poses[i], looks[i], 0.2);
            });
          }
        };

        // ---- the timeline ----
        // A lane a piece. Each trigger is a bar from the frame it starts to
        // the frame it ends, like the lines GD draws for a trigger's
        // duration. Bars that overlap share the lane. Red is the playhead.
        const timeline = doc.createElement(`canvas`);
        style(timeline, { display: `block`, width: `100%`, cursor: `pointer`, background: `#0c0c0c` });
        const TL = { label: 104, ruler: 18, events: 14, row: 20, rows: 8 };
        let tlHits = [];
        const tlRows = () => Math.max(1, Math.min(TL.rows, pieces.length));
        const tlHeight = () => TL.ruler + TL.events + tlRows() * TL.row + 4;
        const tlWidth = () => Math.max(1, timeline.width - TL.label - 12);
        const xOfFrame = (f) => TL.label + (f / clipLength()) * tlWidth();
        const frameOfX = (x) => Math.max(0, Math.min(clipLength(), Math.round(((x - TL.label) / tlWidth()) * clipLength())));
        const laneOfY = (y) => {
          const r = Math.floor((y - TL.ruler - TL.events) / TL.row);
          return r >= 0 && r < tlRows() && r + tlScroll < pieces.length ? r + tlScroll : -1;
        };
        const drawTimeline = () => {
          if (!onClip || mode !== `build`) return;
          const clip = currentClip();
          const w = Math.max(200, Math.round(dock.clientWidth || stageWrap.clientWidth || 600));
          if (timeline.width !== w) timeline.width = w;
          if (timeline.height !== tlHeight()) timeline.height = tlHeight();
          timeline.style.height = `${tlHeight()}px`;
          const ctx = timeline.getContext(`2d`);
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.clearRect(0, 0, timeline.width, timeline.height);
          ctx.font = `10px system-ui, sans-serif`;
          ctx.textBaseline = `middle`;
          const length = clipLength();
          const every = length > 120 ? 10 : length > 40 ? 5 : length > 16 ? 2 : 1;
          for (let f = 0; f <= length; f += every) {
            const x = xOfFrame(f);
            const big = f % (every * 2) === 0;
            ctx.fillStyle = big ? `#888` : `#555`;
            ctx.fillRect(Math.round(x), big ? 9 : 13, 1, big ? 9 : 5);
            if (big) {
              ctx.fillStyle = `#aaa`;
              ctx.fillText(String(f), x + 2, 5);
            }
          }
          ctx.fillStyle = `#ddd`;
          ctx.fillText(`Frame ${Math.round(liveFrame())} / ${length}`, 4, 9);
          // The plant's own events: the game acts on these.
          const eventY = TL.ruler + TL.events / 2;
          ctx.fillStyle = `#777`;
          ctx.fillText(`game events`, 4, eventY);
          for (const ev of eventsOf(clip)) {
            const x = xOfFrame(ev.f);
            ctx.fillStyle = `#ff9f0a`;
            ctx.beginPath();
            ctx.moveTo(x, eventY - 6);
            ctx.lineTo(x + 7, eventY - 3);
            ctx.lineTo(x, eventY);
            ctx.closePath();
            ctx.fill();
            ctx.fillRect(Math.round(x), eventY - 6, 1, 12);
            ctx.fillText(ev.name, x + 9, eventY - 1);
          }
          tlScroll = Math.max(0, Math.min(tlScroll, pieces.length - tlRows()));
          tlHits = [];
          const sel = triggerById(triggerSel);
          for (let r = 0; r < tlRows(); r++) {
            const p = pieces[r + tlScroll];
            if (!p) break;
            const y = TL.ruler + TL.events + r * TL.row;
            ctx.fillStyle = r % 2 ? `#121212` : `#171717`;
            ctx.fillRect(0, y, timeline.width, TL.row);
            if (picked.has(p.id)) {
              ctx.fillStyle = p.id === selected ? `rgba(76,217,100,0.2)` : `rgba(76,217,100,0.09)`;
              ctx.fillRect(0, y, timeline.width, TL.row);
            }
            ctx.fillStyle = viewOff(p.id) ? `#666` : `#bbb`;
            ctx.fillText(p.name.length > 15 ? `${p.name.slice(0, 14)}.` : p.name, 4, y + TL.row / 2);
            const ends = [];
            const placed = triggersOn(p.id).map((t) => {
              let slot = ends.findIndex((end) => end <= t.f);
              if (slot < 0) slot = ends.length;
              ends[slot] = t.f + Math.max(t.d || 0, 1);
              return [t, slot];
            });
            const h = (TL.row - 4) / Math.max(1, ends.length);
            for (const [t, slot] of placed) {
              const x0 = xOfFrame(t.f);
              const x1 = Math.max(x0 + 7, xOfFrame(t.f + (t.d || 0)));
              const y0 = y + 2 + slot * h;
              ctx.globalAlpha = 0.9;
              ctx.fillStyle = TRIGGER_COLOURS[t.type] ?? `#888`;
              ctx.fillRect(x0, y0, x1 - x0, h - 1);
              ctx.globalAlpha = 1;
              if (t === sel) {
                ctx.strokeStyle = `#fff`;
                ctx.lineWidth = 2;
                ctx.strokeRect(x0 + 1, y0 + 1, x1 - x0 - 2, h - 3);
              }
              if (x1 - x0 > 34 && h >= 8) {
                ctx.fillStyle = `#000`;
                ctx.fillText(TRIGGER_LABELS[t.type], x0 + 3, y0 + h / 2);
              }
              tlHits.push({ t, id: p.id, x0, x1, y0, y1: y0 + h, stretch: !INSTANT.has(t.type) });
            }
          }
          if (pieces.length > tlRows()) {
            ctx.fillStyle = `#777`;
            ctx.fillText(`${tlScroll + 1}-${tlScroll + tlRows()} of ${pieces.length}, scroll`, 4, timeline.height - 5);
          }
          ctx.fillStyle = `#ff375f`;
          ctx.fillRect(Math.round(xOfFrame(liveFrame())) - 1, 0, 2, timeline.height);
        };
        const hitTrigger = (x, y) => {
          for (let i = tlHits.length - 1; i >= 0; i--) {
            const hit = tlHits[i];
            if (x >= hit.x0 - 2 && x <= hit.x1 + 3 && y >= hit.y0 && y <= hit.y1) return { ...hit, atEnd: hit.stretch && x >= hit.x1 - 5 };
          }
          return null;
        };
        let tlDrag = null;
        const tlMove = (ev) => {
          if (!tlDrag) return;
          const r = timeline.getBoundingClientRect();
          const f = frameOfX(ev.clientX - r.left);
          const t = tlDrag.t;
          if (tlDrag.kind === `scrub`) {
            playhead = f;
          } else if (tlDrag.kind === `slide`) {
            t.f = Math.max(0, Math.min(clipLength(), tlDrag.f0 + (f - tlDrag.from)));
            playhead = t.f;
            changed();
          } else if (tlDrag.kind === `stretch`) {
            t.d = Math.max(0, Math.min(clipLength() - t.f, tlDrag.d0 + (f - tlDrag.from)));
            playhead = endOf(t);
            changed();
          }
          drawCanvas();
        };
        const tlUp = () => {
          doc.removeEventListener?.(`mousemove`, tlMove, true);
          doc.removeEventListener?.(`mouseup`, tlUp, true);
          if (tlDrag && tlDrag.kind !== `scrub`) commit();
          tlDrag = null;
          render();
        };
        timeline.onmousedown = (ev) => {
          ev.preventDefault?.();
          rigWindow.focus?.();
          const r = timeline.getBoundingClientRect();
          const x = ev.clientX - r.left;
          const y = ev.clientY - r.top;
          playAnim(false);
          const f = frameOfX(x);
          const hit = hitTrigger(x, y);
          if (hit) {
            // A bar: pick it, and the pieces it acts on. Drag it to move it
            // in time, drag its right end to make it longer or shorter.
            if (!(ev.ctrlKey || ev.metaKey)) {
              picked = new Set(hit.t.targets.filter((id) => byId(id)));
              selected = hit.id;
            }
            triggerSel = hit.t.id;
            tlDrag = hit.atEnd
              ? { kind: `stretch`, t: hit.t, d0: hit.t.d, from: f }
              : { kind: `slide`, t: hit.t, f0: hit.t.f, from: f };
            playhead = hit.atEnd ? endOf(hit.t) : hit.t.f;
          } else {
            const lane = laneOfY(y);
            if (lane >= 0) {
              if (ev.ctrlKey || ev.metaKey) toggle(pieces[lane].id);
              else selectOnly(pieces[lane].id);
            }
            triggerSel = null;
            playhead = f;
            tlDrag = { kind: `scrub` };
          }
          doc.addEventListener?.(`mousemove`, tlMove, true);
          doc.addEventListener?.(`mouseup`, tlUp, true);
          render();
        };
        // Double-click a lane to put a Move trigger there, as placing one.
        timeline.ondblclick = (ev) => {
          const r = timeline.getBoundingClientRect();
          const x = ev.clientX - r.left;
          const y = ev.clientY - r.top;
          const lane = laneOfY(y);
          if (lane < 0 || hitTrigger(x, y)) return;
          selectOnly(pieces[lane].id);
          goFrame(frameOfX(x));
          addTrigger(`move`, {}, [pieces[lane]]);
          commit();
          render();
        };
        timeline.onwheel = (ev) => {
          ev.preventDefault?.();
          tlScroll = Math.max(0, Math.min(pieces.length - tlRows(), tlScroll + (ev.deltaY > 0 ? 1 : -1)));
          drawCanvas();
        };

        // ---- dragging on the stage, in a clip ----
        const parentSpace = (poses, i) => {
          const parent = motionNow().parents[i];
          const w = parent >= 0 ? poses[parent] : plantSize();
          return M.inv([w[0], w[1], w[2], w[3], 0, 0]);
        };
        const clipDown = (ev, at, listen) => {
          playAnim(false);
          const v = view();
          const i = pieceAt(at, posesAt(liveFrame()));
          if (i < 0) {
            dragging = { kind: `pan`, sx: at.sx, sy: at.sy, vx: v.x, vy: v.y };
            listen();
            return;
          }
          const p = pieces[i];
          if (ev.ctrlKey || ev.metaKey) {
            toggle(p.id);
            render();
            return;
          }
          if (!picked.has(p.id)) selectOnly(p.id);
          else selected = p.id;
          // Dragging the piece a picked trigger acts on changes that trigger,
          // shown at its end so the piece follows the pointer. Anything else
          // makes a new trigger, but only once the pointer really moves: a
          // click just picks.
          const type = ev.shiftKey ? `rotate` : `move`;
          const sel = triggerById(triggerSel);
          const t = sel && sel.type === type && sel.targets.includes(p.id) ? sel : null;
          if (t) playhead = endOf(t);
          const poses = posesAt(playhead);
          const c = poses[i];
          dragging = {
            kind: `trigger`, type, t, list: pickedPieces(), from: at, into: parentSpace(poses, i),
            cx: c[4], cy: c[5], a0: Math.atan2(at.y - c[5], at.x - c[4]),
            base: t ? (type === `move` ? [t.x, t.y] : [t.r]) : null,
          };
          render();
          listen();
        };
        const triggerDrag = (d, at) => {
          if (d.kind !== `trigger`) return false;
          if (!d.t) {
            if (Math.hypot(at.sx - d.from.sx, at.sy - d.from.sy) < 3) return true;
            d.t = addTrigger(d.type, {}, d.list);
            d.base = d.type === `move` ? [0, 0] : [0];
            playhead = endOf(d.t);
          }
          if (d.type === `move`) {
            const local = M.mul(d.into, [1, 0, 0, 1, at.x - d.from.x, at.y - d.from.y]);
            d.t.x = Math.round(d.base[0] + local[4]);
            d.t.y = Math.round(d.base[1] + local[5]);
          } else {
            const a = Math.atan2(at.y - d.cy, at.x - d.cx);
            let by = ((a - d.a0) * 180) / Math.PI;
            by = ((by + 540) % 360) - 180;
            d.t.r = Math.round((d.base[0] + by) * 10) / 10;
          }
          changed();
          return true;
        };

        // ---- keys, in a clip ----
        const clipKey = (ev) => {
          const ctrl = ev.ctrlKey || ev.metaKey;
          const t = triggerById(triggerSel);
          const halt = () => {
            ev.preventDefault?.();
            return true;
          };
          const done = (fn) => {
            halt();
            fn();
            commit();
            render();
            return true;
          };
          const move = (fn) => {
            if (!picked.size) return halt();
            return done(fn);
          };
          const step = ev.shiftKey ? 10 : 1;
          switch (ev.key) {
            case ` `: playAnim(!animPlaying); render(); return halt();
            case `,`: goFrame(playhead - 1); render(); return halt();
            case `.`: goFrame(playhead + 1); render(); return halt();
            case `Home`: goFrame(0); render(); return halt();
            case `End`: goFrame(clipLength()); render(); return halt();
            case `Escape`: triggerSel = null; render(); return halt();
            case `Delete`: case `Backspace`:
              if (t) return done(() => dropTrigger(t));
              return halt();
            case `d`: case `D`:
              if (!ctrl) return false;
              if (t) return done(() => duplicateTrigger(t));
              return halt();
            case `c`: case `C`:
              if (!ctrl || !t) return false;
              triggerCopy = { ...t, targets: [...t.targets] };
              status = `${TRIGGER_LABELS[t.type]} trigger copied. Ctrl+V puts it at the red line, on the picked pieces.`;
              render();
              return halt();
            case `v`: case `V`:
              if (!ctrl || !triggerCopy) return false;
              return done(() => {
                const copy = duplicateTrigger(triggerCopy);
                if (picked.size) copy.targets = spreadFor(copy.type, pickedPieces());
              });
            case `ArrowLeft`: return move(() => bumpTrigger(`move`, (tr) => { tr.x -= step; }));
            case `ArrowRight`: return move(() => bumpTrigger(`move`, (tr) => { tr.x += step; }));
            case `ArrowUp`: return move(() => bumpTrigger(`move`, (tr) => { tr.y -= step; }));
            case `ArrowDown`: return move(() => bumpTrigger(`move`, (tr) => { tr.y += step; }));
            case `q`: case `Q`: return move(() => bumpTrigger(`rotate`, (tr) => { tr.r -= 5 * step; }));
            case `e`: case `E`: return move(() => bumpTrigger(`rotate`, (tr) => { tr.r += 5 * step; }));
            case `+`: case `=`: return move(() => bumpTrigger(`scale`, (tr) => { tr.sx = Math.round(tr.sx * 110) / 100; tr.sy = Math.round(tr.sy * 110) / 100; }));
            case `-`: case `_`: return move(() => bumpTrigger(`scale`, (tr) => { tr.sx = Math.round((tr.sx / 1.1) * 100) / 100; tr.sy = Math.round((tr.sy / 1.1) * 100) / 100; }));
            default: return false;
          }
        };

        // ---- under the stage ----
        const tick = (label, on, set) => {
          const wrap = el(`label`, { display: `flex`, alignItems: `center`, gap: `4px`, cursor: `pointer` });
          const box = doc.createElement(`input`);
          box.type = `checkbox`;
          box.checked = on;
          box.onchange = () => {
            set(box.checked);
            render();
          };
          wrap.appendChild(box);
          wrap.appendChild(el(`span`, {}, label));
          return wrap;
        };
        const renderDock = () => {
          dock.innerHTML = ``;
          if (mode !== `build` || libraryOpen) {
            dock.style.display = `none`;
            return;
          }
          dock.style.display = `flex`;
          const bar = el(`div`, { display: `flex`, alignItems: `center`, flexWrap: `wrap`, gap: `4px`, padding: `6px 6px 4px` });
          bar.appendChild(el(`span`, { opacity: `0.7`, marginRight: `2px` }, `Clip:`));
          const chip = (name, label) => {
            const b = button(label, () => pickClip(name), onClip === name ? undefined : `quiet`);
            b.style.marginLeft = `0`;
            return b;
          };
          bar.appendChild(chip(null, `Layout`));
          for (const c of motionNow().clips) {
            const n = triggersIn(c.name).length;
            bar.appendChild(chip(c.name, n ? `${c.name} (${n})` : c.name));
          }
          dock.appendChild(bar);
          if (onClip) {
            const play = el(`div`, { display: `flex`, alignItems: `center`, flexWrap: `wrap`, gap: `4px`, padding: `0 6px 4px` });
            const small = (label, title, fn, look = `quiet`) => {
              const b = button(label, fn, look);
              b.title = title;
              b.style.marginLeft = `0`;
              return b;
            };
            play.appendChild(small(animPlaying ? `Pause` : `Play`, `Space`, () => {
              playAnim(!animPlaying);
              render();
            }, undefined));
            play.appendChild(small(`|<`, `First frame (Home)`, () => { goFrame(0); render(); }));
            play.appendChild(small(`<`, `Back a frame (comma)`, () => { goFrame(playhead - 1); render(); }));
            play.appendChild(small(`>`, `On a frame (full stop)`, () => { goFrame(playhead + 1); render(); }));
            play.appendChild(small(`>|`, `Last frame (End)`, () => { goFrame(clipLength()); render(); }));
            play.appendChild(el(`span`, { opacity: `0.7`, marginLeft: `6px` }, `Speed`));
            const speed = choose(String(animSpeed), [[`0.25`, `Quarter`], [`0.5`, `Half`], [`1`, `Normal`], [`2`, `Double`]], (value) => {
              const was = animPlaying;
              playAnim(false);
              animSpeed = Number(value);
              playAnim(was);
            });
            style(speed, { flex: `0 0 auto`, width: `84px` });
            play.appendChild(speed);
            play.appendChild(tick(`Onion skin`, onion, (v) => { onion = v; }));
            play.appendChild(tick(`Bones`, showBones, (v) => { showBones = v; }));
            dock.appendChild(play);
            dock.appendChild(timeline);
          }
          dock.appendChild(renderToolbar());
        };
        // GD's Edit tab: arrows by a step you pick, turns, sizes, copies.
        // In the layout they change the layout; in a clip they change the
        // picked trigger, or start one at the red line.
        const renderToolbar = () => {
          const bar = el(`div`, { display: `flex`, alignItems: `center`, flexWrap: `wrap`, gap: `4px`, padding: `6px`, borderTop: `1px solid #2a2a2a`, background: `#1a1a1a` });
          const inClip = !!onClip;
          const tool = (label, title, fn, look = `quiet`) => {
            const b = button(label, fn, look);
            b.title = title;
            style(b, { marginLeft: `0`, minWidth: `28px`, padding: `5px 8px`, font: `600 12px system-ui, sans-serif` });
            return b;
          };
          const run = (fn) => () => {
            if (!picked.size) {
              status = inClip ? `Pick a piece first: these add a trigger to it, or change the one picked.` : `Pick a piece first.`;
              render();
              return;
            }
            fn();
            commit();
            render();
          };
          const s = nudgeStep;
          const move = (dx, dy) => run(() => (inClip ? bumpTrigger(`move`, (t) => { t.x += dx; t.y += dy; }) : layoutNudge(dx, dy)));
          const turn = (by) => run(() => (inClip ? bumpTrigger(`rotate`, (t) => { t.r = Math.round((t.r + by) * 10) / 10; }) : layoutTurn(by)));
          const size = (k) => run(() => (inClip
            ? bumpTrigger(`scale`, (t) => {
              t.sx = Math.round(t.sx * k * 100) / 100;
              t.sy = Math.round(t.sy * k * 100) / 100;
            })
            : layoutScale(k)));
          bar.appendChild(el(`span`, { opacity: `0.7`, marginRight: `2px` }, inClip ? `Edit triggers:` : `Edit layout:`));
          bar.appendChild(tool(`\u2190`, `Move left by ${s}`, move(-s, 0)));
          bar.appendChild(tool(`\u2191`, `Move up by ${s}`, move(0, -s)));
          bar.appendChild(tool(`\u2193`, `Move down by ${s}`, move(0, s)));
          bar.appendChild(tool(`\u2192`, `Move right by ${s}`, move(s, 0)));
          for (const n of [1, 5, 20]) {
            bar.appendChild(tool(String(n), `Arrow step: ${n}`, () => {
              nudgeStep = n;
              render();
            }, nudgeStep === n ? undefined : `quiet`));
          }
          bar.appendChild(el(`span`, { width: `6px` }));
          bar.appendChild(tool(`\u21BA 15`, `Turn left 15 degrees`, turn(-15)));
          bar.appendChild(tool(`\u21BB 15`, `Turn right 15 degrees`, turn(15)));
          bar.appendChild(tool(`\u21BA 90`, `Turn left 90 degrees`, turn(-90)));
          bar.appendChild(tool(`\u21BB 90`, `Turn right 90 degrees`, turn(90)));
          bar.appendChild(tool(`Smaller`, `Size down a tenth`, size(1 / 1.1)));
          bar.appendChild(tool(`Bigger`, `Size up a tenth`, size(1.1)));
          bar.appendChild(el(`span`, { width: `6px` }));
          if (inClip) {
            const t = triggerById(triggerSel);
            const dup = tool(`Duplicate`, `Copy the picked trigger to the red line (Ctrl+D)`, () => {
              if (!t) return;
              duplicateTrigger(t);
              commit();
              render();
            });
            const del = tool(`Delete`, `Delete the picked trigger (Delete)`, () => {
              if (!t) return;
              dropTrigger(t);
              commit();
              render();
            }, `warn`);
            for (const b of [dup, del]) {
              b.disabled = !t;
              b.style.opacity = t ? `1` : `0.4`;
              bar.appendChild(b);
            }
          } else {
            bar.appendChild(tool(`Flip`, `Mirror (F)`, run(() => {
              for (const q of pickedPieces()) q.flip = !q.flip;
            })));
            bar.appendChild(tool(`Back`, `Send back a layer ([)`, run(() => layer(current(), -1))));
            bar.appendChild(tool(`Front`, `Bring forward a layer (])`, run(() => layer(current(), 1))));
            bar.appendChild(tool(`Duplicate`, `Copy the picked pieces (Ctrl+D)`, () => clonePieces([...picked])));
            bar.appendChild(tool(`Delete`, `Delete the picked pieces (Delete)`, () => removePieces([...picked]), `warn`));
          }
          bar.appendChild(tool(`Deselect`, `Pick nothing (Esc)`, () => {
            triggerSel = null;
            selectOnly(null);
            render();
          }));
          return bar;
        };

        // ---- DragonBones files ----
        const exportDragonBones = () => {
          const layout = pieces.map(({ fresh, ...p }) => p);
          if (!layout.length) {
            status = `Nothing to export yet.`;
            render();
            return;
          }
          const name = `gt_${row.codename}`;
          const ske = buildRigJson(layout, { name, ...options, template });
          const atlas = { ...buildRigAtlas(layout, { width: img.width, height: img.height }, name), imagePath: `${row.codename}_tex.png` };
          const out = [
            [`${row.codename}_ske.json`, new TextEncoder().encode(JSON.stringify(ske, null, 1))],
            [`${row.codename}_tex.json`, new TextEncoder().encode(JSON.stringify(atlas, null, 1))],
            [`${row.codename}_tex.png`, fromDataUrl(dataUrl)],
          ];
          status = `Exporting...`;
          render();
          const home = mainHome();
          const toFolder = home && folderWritable !== false
            ? Promise.all(out.map(([file, bytes]) => writeInto(`${home}/${SAVED}/${file}`, bytes))).then(() => `${packNameOf(home)}/textures/saved`)
            : Promise.reject(new Error(`no folder`));
          toFolder
            .catch(() => {
              // No folder to write to: hand them over as downloads.
              for (const [file, bytes] of out) {
                const a = doc.createElement(`a`);
                a.href = URL.createObjectURL(new Blob([bytes], { type: file.endsWith(`.png`) ? `image/png` : `application/json` }));
                a.download = file;
                doc.body.appendChild(a);
                a.click?.();
                a.remove?.();
              }
              return `your downloads`;
            })
            .then((where) => {
              status = `Exported ${out.map(([file]) => file).join(`, `)} to ${where}. They open in DragonBones Pro (File, Import).`;
              e.log.info(`[Textures] ${row.label}: ${status}`);
              render();
            });
        };

        // ---- clips of your own ----
        let newClipName = ``;
        let newClipLoops = false;
        const addOwnClip = (name, loops, length) => {
          const clean = String(name ?? ``).trim().replace(/\s+/g, ` `).slice(0, 40);
          if (!clean) return;
          if (!motionNow().clips.some((c) => c.name === clean)) {
            options.clips = [...(options.clips ?? []), { name: clean, loops: !!loops, length: Math.max(2, Math.round(length ?? 24)) }];
            changed();
          }
          onClip = clean;
          triggerSel = null;
          playhead = 0;
        };
        const renderOwnClips = () => {
          const box = section(`Clips of your own`);
          const acts = (globalThis.GreenhouseActs?.[row.codename] ?? []).filter((a) => a?.name);
          const have = new Set(motionNow().clips.map((c) => c.name));
          box.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4` },
            `Clips the game doesn't have, for things a plant does that it has no animation for. `
            + `They play when something asks for them by name.`));
          for (const act of acts) {
            const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px` });
            line.appendChild(el(`div`, { flex: `1`, lineHeight: `1.35` }, `${act.name}: when ${act.when}`));
            line.appendChild(have.has(act.name)
              ? el(`span`, { opacity: `0.6` }, `added`)
              : button(`Add`, () => {
                addOwnClip(act.name, act.loops, act.length);
                commit();
                render();
              }));
            box.appendChild(line);
          }
          if (!acts.length) {
            box.appendChild(el(`div`, { opacity: `0.6`, lineHeight: `1.4` },
              `A plant pack can list the clips it plays for its plants here (see GreenhouseActs in the README). None for this plant.`));
          }
          for (const own of options.clips ?? []) {
            const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px` });
            line.appendChild(el(`span`, { flex: `1` }, `${own.name} (${own.loops ? `loops` : `plays once`})`));
            line.appendChild(button(`Delete`, () => {
              options.clips = (options.clips ?? []).filter((c) => c !== own);
              if (options.anim) delete options.anim[own.name];
              if (onClip === own.name) onClip = null;
              changed();
              commit();
              render();
            }, `warn`));
            box.appendChild(line);
          }
          const nameLine = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px` });
          const input = doc.createElement(`input`);
          input.value = newClipName;
          input.placeholder = `new clip name`;
          style(input, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `4px` });
          input.oninput = () => {
            newClipName = input.value;
          };
          nameLine.appendChild(input);
          const loopBox = doc.createElement(`input`);
          loopBox.type = `checkbox`;
          loopBox.checked = newClipLoops;
          loopBox.onchange = () => {
            newClipLoops = loopBox.checked;
          };
          const loopLabel = el(`label`, { display: `flex`, alignItems: `center`, gap: `3px` });
          loopLabel.appendChild(loopBox);
          loopLabel.appendChild(el(`span`, {}, `loops`));
          nameLine.appendChild(loopLabel);
          nameLine.appendChild(button(`New clip`, () => {
            addOwnClip(newClipName, newClipLoops, 24);
            newClipName = ``;
            commit();
            render();
          }));
          box.appendChild(nameLine);
        };

        // ---- the clip panel ----
        // Loops closing: where a piece's triggers leave it when the clip
        // ends, next to where it started. Show, Hide and Picture reset on
        // their own when a clip starts over, so only the rest count.
        const drift = (p) => {
          const list = triggersOn(p.id);
          if (!list.length) return false;
          const s = triggerState(list, clipLength(), !!p.hidden);
          const turn = ((((s.r % 360) + 540) % 360) - 180);
          return Math.abs(s.x) > 0.5 || Math.abs(s.y) > 0.5 || Math.abs(turn) > 0.5
            || Math.abs(s.sx - 1) > 0.01 || Math.abs(s.sy - 1) > 0.01 || Math.abs(s.a - 1) > 0.01;
        };
        const addReturns = (list) => {
          const length = clipLength();
          for (const p of list) {
            const mine = triggersOn(p.id);
            const s = triggerState(mine, length, !!p.hidden);
            const last = Math.max(0, ...mine.map((t) => t.f + (t.d || 0)));
            const f = last < length ? last : Math.max(0, length - 6);
            const d = Math.max(0, length - f);
            const back = (type, fields) => clipAnim(true).triggers.push({ id: nextTriggerId(), type, targets: [p.id], f, d, ease: `inout`, rate: 2, ...fields });
            if (Math.abs(s.x) > 0.5 || Math.abs(s.y) > 0.5) back(`move`, { x: -Math.round(s.x * 10) / 10, y: -Math.round(s.y * 10) / 10 });
            const turn = ((((s.r % 360) + 540) % 360) - 180);
            if (Math.abs(turn) > 0.5) back(`rotate`, { r: -Math.round(turn * 10) / 10 });
            if (Math.abs(s.sx - 1) > 0.01 || Math.abs(s.sy - 1) > 0.01) back(`scale`, { sx: Math.round((1 / (s.sx || 1)) * 1000) / 1000, sy: Math.round((1 / (s.sy || 1)) * 1000) / 1000 });
            if (Math.abs(s.a - 1) > 0.01) back(`alpha`, { a: 1 });
          }
          changed();
        };
        const renderTrigger = (t) => {
          const length = clipLength();
          const box = section(`${TRIGGER_LABELS[t.type]} trigger`);
          box.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4` }, TRIGGER_HELP[t.type]));
          const names = t.targets.map((id) => byId(id)?.name).filter(Boolean);
          const who = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px` });
          who.appendChild(el(`span`, { flex: `1`, lineHeight: `1.35` }, `On: ${names.join(`, `) || `nothing`}`));
          const same = picked.size && [...picked].every((id) => t.targets.includes(id)) && t.targets.every((id) => picked.has(id));
          if (picked.size && !same) {
            who.appendChild(button(`Use picked`, () => {
              t.targets = spreadFor(t.type, pickedPieces());
              commit();
              render();
            }, `quiet`));
          }
          box.appendChild(who);
          box.appendChild(labelled(`Starts at`, range(t.f, 0, length, 1, (v) => {
            t.f = v;
            playhead = v;
          }, (v) => `${v}f`)));
          if (!INSTANT.has(t.type)) {
            box.appendChild(labelled(`Lasts`, range(t.d, 0, length, 1, (v) => {
              t.d = v;
              playhead = Math.min(length, t.f + v);
            }, (v) => (v ? `${v}f` : `instant`))));
            box.appendChild(labelled(`Easing`, choose(t.ease ?? `none`, EASES.map((ease) => [ease, EASE_LABELS[ease]]), (value) => {
              t.ease = value;
            })));
            if (RATED.has(t.ease)) {
              box.appendChild(labelled(`Ease rate`, range(t.rate ?? 2, 1.1, 6, 0.1, (v) => {
                t.rate = v;
              }, (v) => `${v}`)));
            }
          }
          if (t.type === `move`) {
            box.appendChild(labelled(`Move right`, range(t.x, -300, 300, 1, (v) => { t.x = v; })));
            box.appendChild(labelled(`Move up`, range(-t.y, -300, 300, 1, (v) => { t.y = -v; })));
          } else if (t.type === `rotate`) {
            box.appendChild(labelled(`Degrees`, range(t.r, -720, 720, 1, (v) => { t.r = v; }, (v) => `${v}deg`)));
          } else if (t.type === `scale`) {
            box.appendChild(labelled(`Scale wide`, range(t.sx, 0.05, 4, 0.05, (v) => { t.sx = v; }, (v) => `${v}x`)));
            box.appendChild(labelled(`Scale tall`, range(t.sy, 0.05, 4, 0.05, (v) => { t.sy = v; }, (v) => `${v}x`)));
          } else if (t.type === `alpha`) {
            box.appendChild(labelled(`Opacity to`, range(Math.round((t.a ?? 1) * 100), 0, 100, 1, (v) => { t.a = v / 100; }, (v) => `${v}%`)));
          } else if (t.type === `picture`) {
            box.appendChild(labelled(`Shows`, choose(t.img ?? ``, [[``, `Its own picture`], ...pieces.map((q) => [q.id, q.name])], (value) => {
              t.img = value || null;
            })));
          }
          box.appendChild(buttonRow(
            button(`Go to start`, () => { goFrame(t.f); render(); }, `quiet`),
            button(`Go to end`, () => { goFrame(endOf(t)); render(); }, `quiet`),
            button(`Duplicate`, () => { duplicateTrigger(t); commit(); render(); }, `quiet`),
            button(`Delete trigger`, () => { dropTrigger(t); commit(); render(); }, `warn`),
          ));
          if (t.f + (t.d || 0) > length) {
            box.appendChild(el(`div`, { color: `#ffb35c`, lineHeight: `1.4` }, `It runs past the end of the clip, so it gets cut short.`));
          }
        };
        const renderClip = () => {
          const clip = currentClip();
          if (!clip) {
            onClip = null;
            renderLayout();
            return;
          }
          const motion = motionNow();
          const length = clipLength();
          const own = clipAnim(false);
          const top = section(`Clip: ${clip.name}`);
          const note = clipNote(clip.name, row.codename);
          if (note) top.appendChild(el(`div`, { lineHeight: `1.4`, color: `#9fe0a8` }, note));
          const events = eventsOf(clip);
          top.appendChild(el(`div`, { opacity: `0.8`, lineHeight: `1.4` },
            `${length} frames at ${motion.fps} fps, ${clip.playTimes === 0 ? `loops` : `plays once`} in game.`
            + (events.length ? ` Game events: ${events.map((ev) => `${ev.name} at ${ev.f}`).join(`, `)}. The game acts on these, so time the motion to them.` : ``)));
          if (!clip.frame) {
            top.appendChild(labelled(`Length`, range(length, 6, 240, 1, (v) => {
              clipAnim(true).length = v;
              changed();
            }, (v) => `${v}f`, () => {
              commit();
              render();
            })));
          }
          top.appendChild(el(`div`, { opacity: `0.65`, lineHeight: `1.4` },
            `Drag a piece to give it a Move trigger at the red line, Shift+drag for Rotate. The red line jumps to where it ends, so the next drag carries on from there. `
            + `On the timeline, drag a bar to move it in time and its right end to make it longer.`));

          const names = pickedPieces().map((q) => q.name);
          const add = section(`Add a trigger at frame ${Math.round(liveFrame())}`);
          if (!names.length) {
            add.appendChild(el(`div`, { opacity: `0.7` }, `Pick a piece on the stage or its lane on the timeline.`));
          } else {
            add.appendChild(el(`div`, { opacity: `0.8` }, `For ${names.join(`, `)}:`));
            add.appendChild(buttonRow(...TRIGGERS.map((type) => {
              const b = button(TRIGGER_LABELS[type], () => {
                const t = addTrigger(type);
                if (!INSTANT.has(type)) playhead = endOf(t);
                commit();
                render();
              }, `quiet`);
              b.style.borderLeft = `3px solid ${TRIGGER_COLOURS[type]}`;
              return b;
            })));
          }

          const t = triggerById(triggerSel);
          if (t) renderTrigger(t);

          const p = current();
          if (p && picked.size === 1) {
            const box = section(`${p.name} in ${clip.name}`);
            if (p.motion !== `still`) {
              const off = loopsOff(own).has(p.id);
              const loopTick = doc.createElement(`input`);
              loopTick.type = `checkbox`;
              loopTick.checked = !off;
              loopTick.onchange = () => {
                const holder = clipAnim(true);
                const set = new Set(holder.loopOff ?? []);
                if (loopTick.checked) set.delete(p.id);
                else set.add(p.id);
                holder.loopOff = [...set];
                changed();
                commit();
                render();
              };
              box.appendChild(labelled(`Loop plays`, loopTick));
              box.appendChild(el(`div`, { opacity: `0.65`, lineHeight: `1.4` },
                `Its loop (${(MOTION_LABELS[p.motion] ?? p.motion).toLowerCase()}) runs under the triggers. Untick it and only the triggers move it in this clip.`));
            }
            const mine = triggersOn(p.id);
            if (!mine.length) box.appendChild(el(`div`, { opacity: `0.7` }, `No triggers on it in ${clip.name}.`));
            for (const other of mine) {
              const line = el(`div`, {
                display: `flex`, alignItems: `center`, gap: `6px`, padding: `2px 4px`, borderRadius: `4px`, cursor: `pointer`,
                background: other.id === triggerSel ? `#2d3e52` : `transparent`, borderLeft: `3px solid ${TRIGGER_COLOURS[other.type]}`,
              });
              line.onclick = () => {
                triggerSel = other.id;
                goFrame(other.f);
                render();
              };
              const span = INSTANT.has(other.type) || !other.d ? `frame ${other.f}` : `frames ${other.f}-${other.f + other.d}`;
              line.appendChild(el(`span`, { flex: `1` }, `${TRIGGER_LABELS[other.type]}, ${span}`));
              box.appendChild(line);
            }
          }

          if (clip.playTimes === 0) {
            const off = pieces.filter(drift);
            if (off.length) {
              const box = section(`It won't loop smoothly`);
              box.appendChild(el(`div`, { lineHeight: `1.4`, color: `#ffb35c` },
                `${clip.name} starts over when it ends, and ${off.map((q) => q.name).join(`, `)} ${off.length === 1 ? `isn't` : `aren't`} back where ${off.length === 1 ? `it` : `they`} started, so ${off.length === 1 ? `it jumps` : `they jump`}. `
                + `Add a return and they ease back over the last frames.`));
              box.appendChild(buttonRow(button(`Add a return`, () => {
                addReturns(off);
                commit();
                render();
              })));
            }
          }

          const whole = section(`Whole clip`);
          const others = motion.clips.filter((c) => c.name !== clip.name);
          if (!others.some((c) => c.name === copyTo)) copyTo = others[0]?.name ?? null;
          if (copyTo) {
            whole.appendChild(labelled(`Copy to`, choose(copyTo, others.map((c) => [c.name, c.name]), (value) => {
              copyTo = value;
            })));
          }
          whole.appendChild(buttonRow(
            button(`Copy triggers to that clip`, () => {
              const target = motion.clips.find((c) => c.name === copyTo);
              if (!target || !triggersIn().length) return;
              const k = Math.max(1, target.duration) / length;
              const into = clipAnim(true, copyTo);
              into.triggers = [
                ...(into.triggers ?? []),
                ...triggersIn().map((tr) => ({ ...tr, id: nextTriggerId(), targets: [...tr.targets], f: Math.round(tr.f * k), d: Math.round((tr.d || 0) * k) })),
              ];
              if (own?.loopOff?.length) into.loopOff = [...new Set([...(into.loopOff ?? []), ...own.loopOff])];
              status = `${clip.name}'s triggers copied to ${copyTo}, stretched to its length.`;
              changed();
              commit();
              render();
            }, `quiet`),
            button(`Clear this clip`, () => {
              if (options.anim) delete options.anim[clip.name];
              triggerSel = null;
              changed();
              commit();
              render();
            }, `warn`),
            button(`Export for DragonBones`, exportDragonBones, `quiet`),
          ));

          renderOwnClips();
          renderPieceList();
        };

        // ---- saved animations ----
        let libraryOpen = false;
        let library = null; // null: not read yet, `reading`, or the list
        let saveName = `${row.label} ${new Date().toISOString().slice(0, 10)}`;
        const renderLibrary = () => {
          side.appendChild(el(`div`, { font: `600 13px system-ui, sans-serif`, margin: `2px 0 6px` }, `Saved animations`));
          const home = mainHome() && folderWritable !== false
            ? `They're files in ${packNameOf(mainHome())}/textures/saved, so they go wherever that pack goes.`
            : `This install can't write its textures folder, so they're kept in the game's local storage.`;
          side.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4`, marginBottom: `8px` },
            `Kept apart from the plant: building again or taking the rig off never touches these, and a rig is saved here by itself before it's taken off. ${home}`));
          const nameLine = el(`div`, { display: `flex`, gap: `6px`, marginBottom: `10px` });
          const input = doc.createElement(`input`);
          input.value = saveName;
          style(input, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `4px` });
          input.oninput = () => {
            saveName = input.value;
          };
          nameLine.appendChild(input);
          nameLine.appendChild(button(`Save`, () => {
            const layout = pieces.map(({ fresh, ...p }) => p);
            if (!layout.length) {
              status = `Nothing to save yet: cut out some pieces first.`;
              render();
              return;
            }
            status = `Saving...`;
            render();
            saveAnimation({ name: saveName, codename: row.codename, label: row.label, layout, options: { ...options }, sheet: dataUrl })
              .then(({ where, record }) => {
                status = `Saved "${record.name}" in ${where}.`;
                e.log.info(`[Textures] ${row.label}: ${status}`);
                library = null;
                render();
              })
              .catch((err) => {
                status = `Couldn't save: ${err.message}`;
                e.log.error(`[Textures] ${row.label}: ${status}`);
                render();
              });
          }));
          side.appendChild(nameLine);
          if (library === null) {
            library = `reading`;
            listAnimations()
              .then((list) => {
                library = list;
              })
              .catch(() => {
                library = [];
              })
              .finally(() => {
                if (libraryOpen) render();
              });
          }
          if (library === `reading`) {
            side.appendChild(el(`div`, { opacity: `0.7` }, `Reading...`));
            return;
          }
          if (!library.length) {
            side.appendChild(el(`div`, { opacity: `0.7` }, `Nothing saved yet.`));
            return;
          }
          for (const { record } of library) {
            const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px`, padding: `4px`, borderRadius: `4px`,
              background: record.codename === row.codename ? `#1c3a20` : `transparent` });
            const text = el(`div`, { flex: `1`, minWidth: `0` });
            text.appendChild(el(`div`, { overflow: `hidden`, textOverflow: `ellipsis`, whiteSpace: `nowrap` }, record.name));
            text.appendChild(el(`div`, { opacity: `0.6`, fontSize: `11px` },
              `${record.label ?? record.codename}, ${record.layout.length} pieces, ${String(record.saved ?? ``).slice(0, 16).replace(`T`, ` `)}`));
            line.appendChild(text);
            line.appendChild(button(`Open`, () => {
              const other = record.codename && record.codename !== row.codename ? ` It was made for ${record.label ?? record.codename}.` : ``;
              openRig(row, record.sheet, {
                draft: { layout: record.layout, options: record.options ?? {} },
                mode: `build`,
                status: `Opened "${record.name}".${other} Press Build and wear to put it on ${row.label}.`,
              });
            }, `quiet`));
            side.appendChild(line);
          }
        };

        // The preview runs on its own so the animation shows while you work.
        const ticker = setInterval(() => {
          if (!rigWindow) {
            clearInterval(ticker);
            return;
          }
          if (mode === `build` && onClip && animPlaying) drawCanvas();
        }, 40);
        const box = rigWindow;
        box.__close = () => {
          clearInterval(ticker);
          doc.removeEventListener?.(`mousemove`, onMove, true);
          doc.removeEventListener?.(`mouseup`, onUp, true);
          box.remove();
          if (rigWindow === box) rigWindow = null;
        };

        doc.body.appendChild(rigWindow);
        rigWindow.focus?.();
        render();
      };
      img.src = dataUrl;
    };

    const rigArt = (row) => {
      const stored = saved()[`rigart:${row.codename}`];
      if (stored) {
        openRig(row, stored);
        return;
      }
      // The first time, pick as many sheets as the plant is drawn on.
      pickFiles((urls, names) => {
        if (urls.length === 1) {
          openRig(row, urls[0]);
          return;
        }
        combineSheets(urls)
          .then((out) => {
            remember(`rigart:${row.codename}`, out.dataUrl);
            openRig(row, out.dataUrl, {
              sheets: out.regions,
              status: `${names.length} sheets packed into one picture (dashed outlines). Every lump of art has a box: fix them, name the pieces, then go to step 2.`,
            });
          })
          .catch((err) => e.log.error(`[Textures] ${row.label}: ${err.message}`));
      });
    };

    // ==================================================================
    // Packet editor
    //
    // The whole seed packet, in layers, in three parts: a background under
    // the plant art (pictures of your own, or a plain colour), the plant art,
    // and a border over it. The game's own background, sun cost plate and
    // family icon can each be switched off. Drag a layer to move it, its
    // corners to size it, its sides to stretch it, the knob above it to turn
    // it. With Live on the real packets change as you work; closing without
    // saving puts them back.
    //
    // Each part is saved as one picture covering the card and a margin round
    // it, all three the same size and place, into the plant's home folder
    // like the rest of its look. The layers are kept beside them to edit
    // again, and whole designs can be kept in textures/saved.
    // ==================================================================
    const PARTS = [`back`, `plant`, `front`];
    let packetWindow = null;
    const loadPicture = (src) => new Promise((resolve, reject) => {
      const pic = new Image();
      pic.onload = () => resolve(pic);
      pic.onerror = () => reject(new Error(`that picture wouldn't load`));
      pic.src = src;
    });
    // Transparent edges cut off, so a layer's box is the art.
    const trimPicture = (src) => loadPicture(src).then((pic) => {
      try {
        const w = pic.width;
        const h = pic.height;
        const c = doc.createElement(`canvas`);
        c.width = w;
        c.height = h;
        const ctx = c.getContext(`2d`);
        ctx.drawImage(pic, 0, 0);
        const data = ctx.getImageData(0, 0, w, h)?.data;
        if (!data) return src;
        let left = w;
        let top = h;
        let right = -1;
        let bottom = -1;
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            if (data[(y * w + x) * 4 + 3] < 8) continue;
            if (x < left) left = x;
            if (x > right) right = x;
            if (y < top) top = y;
            if (y > bottom) bottom = y;
          }
        }
        if (right < 0 || (left === 0 && top === 0 && right === w - 1 && bottom === h - 1)) return src;
        const out = doc.createElement(`canvas`);
        out.width = right - left + 1;
        out.height = bottom - top + 1;
        out.getContext(`2d`).drawImage(pic, left, top, out.width, out.height, 0, 0, out.width, out.height);
        return out.toDataURL(`image/png`);
      } catch (err) {
        return src;
      }
    });
    // A rig's rest pose as one picture.
    const rigPose = (codename) => {
      let choice = null;
      try {
        choice = JSON.parse(stored(`rig:${codename}`) ?? `null`);
      } catch (err) {
        choice = null;
      }
      const sheet = stored(`rigart:${codename}`);
      if (!choice?.layout?.length || !sheet) return Promise.resolve(null);
      return loadPicture(sheet).then((pic) => {
        const size = [choice.options?.sizeX ?? 1, 0, 0, choice.options?.sizeY ?? 1, 0, 0];
        const parts = choice.layout.filter((p) => p.box && !p.hidden).map((p) => {
          const scale = pictureScale(p);
          const m = M.scale(M.mul(size, M.at(p.x ?? 0, p.y ?? 0, p.rotation ?? 0)), scale.x, scale.y);
          const pivot = pivotOf(p);
          const x0 = -pivot.x * p.box.width;
          const y0 = -pivot.y * p.box.height;
          const pts = [[x0, y0], [x0 + p.box.width, y0], [x0, y0 + p.box.height], [x0 + p.box.width, y0 + p.box.height]]
            .map(([x, y]) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]);
          return { p, m, x0, y0, pts };
        });
        if (!parts.length) return null;
        const xs = parts.flatMap((q) => q.pts.map((pt) => pt[0]));
        const ys = parts.flatMap((q) => q.pts.map((pt) => pt[1]));
        const left = Math.min(...xs);
        const top = Math.min(...ys);
        const w = Math.max(...xs) - left;
        const h = Math.max(...ys) - top;
        const k = Math.min(1, 1024 / Math.max(w, h, 1));
        const canvas = doc.createElement(`canvas`);
        canvas.width = Math.max(1, Math.ceil(w * k));
        canvas.height = Math.max(1, Math.ceil(h * k));
        const ctx = canvas.getContext(`2d`);
        for (const { p, m, x0, y0 } of parts) {
          ctx.setTransform(k * m[0], k * m[1], k * m[2], k * m[3], k * (m[4] - left), k * (m[5] - top));
          ctx.drawImage(pic, p.box.x, p.box.y, p.box.width, p.box.height, x0, y0, p.box.width, p.box.height);
        }
        return canvas.toDataURL(`image/png`);
      });
    };

    // ---- a real card, drawn behind the picture ----
    // Every sprite and label on a card from the game, in the space the
    // packet picture is placed in (the plant art's parent, from the art's
    // position), y down. Those drawn before the plant art go under your
    // picture, those after it over. Anything this can't read is left out.
    const worldOf = (node) => {
      const m = node?.worldMatrix ?? node?._mat;
      if (!m || typeof m.m00 !== `number`) return null;
      return [m.m00, m.m01, m.m04, m.m05, m.m12, m.m13];
    };
    const imageOfFrame = (frame) => {
      const tex = frame?.texture ?? frame?._texture;
      return tex?.image?.data ?? tex?.image?._data ?? tex?.image?.nativeAsset ?? tex?._image?.data ?? null;
    };
    const cardSnapshot = (codename) => {
      const cards = liveCards();
      const card = cards.find((c) => c?.Type === codename) ?? cards[cards.length - 1];
      const art = (card?.ca?._plantDB ?? card?._plantDB)?.node;
      const holder = art?.parent;
      if (!art || !holder) return null;
      let root = card.node ?? holder;
      for (let up = 0; up < 3 && root?.parent && !card.node; up++) root = root.parent;
      const from = worldOf(holder);
      if (!from) return null;
      const pos = art.position ?? { x: 0, y: 0 };
      // holder space, from the art's position, flipped to y down
      const into = M.mul([1, 0, 0, -1, 0, 0], M.mul([1, 0, 0, 1, -pos.x, -pos.y], M.inv(from)));
      const under = [];
      const over = [];
      let passed = false;
      const visit = (node) => {
        if (!node || node.isValid === false || node.activeInHierarchy === false) return;
        if (node === art) {
          passed = true;
          return;
        }
        if (/^gtPacket/.test(node.name ?? ``)) return;
        const world = worldOf(node);
        for (const comp of node.components ?? node._components ?? []) {
          if (!world || comp?.enabled === false) continue;
          const size = node._uiProps?.uiTransformComp?.contentSize ?? node.getComponent?.(cc.UITransform)?.contentSize ?? null;
          const anchor = node._uiProps?.uiTransformComp?.anchorPoint ?? node.getComponent?.(cc.UITransform)?.anchorPoint ?? { x: 0.5, y: 0.5 };
          if (!size) continue;
          const m = M.mul(into, world);
          const alpha = ((comp.color?.a ?? 255) / 255) * (node._uiProps?.opacity ?? 1);
          if (comp.spriteFrame !== undefined && comp.spriteFrame) {
            const src = imageOfFrame(comp.spriteFrame);
            const rect = comp.spriteFrame.rect ?? comp.spriteFrame._rect;
            if (src && rect) (passed ? over : under).push({ kind: `sprite`, m, src, rect, rotated: !!comp.spriteFrame.rotated, w: size.width, h: size.height, ax: anchor.x, ay: anchor.y, alpha });
          } else if (typeof comp.string === `string` && `fontSize` in comp && comp.string) {
            const c = comp.color ?? { r: 255, g: 255, b: 255 };
            (passed ? over : under).push({ kind: `label`, m, text: comp.string, size: comp.fontSize || 20, colour: `rgb(${c.r},${c.g},${c.b})`, w: size.width, h: size.height, ax: anchor.x, ay: anchor.y, alpha });
          }
        }
        for (const child of node.children ?? []) visit(child);
      };
      try {
        visit(root);
      } catch (err) {
        return null;
      }
      return under.length || over.length ? { under, over, plant: card.Type } : null;
    };
    const drawCardParts = (ctx, parts, base) => {
      for (const part of parts) {
        try {
          const m = M.mul(base, part.m);
          // local space is y up; the picture is drawn in a flipped copy of it
          ctx.setTransform(m[0], m[1], m[2], m[3], m[4], m[5]);
          ctx.transform(1, 0, 0, -1, 0, 0);
          ctx.globalAlpha = Math.max(0, Math.min(1, part.alpha));
          const x = -part.ax * part.w;
          const y = -(1 - part.ay) * part.h;
          if (part.kind === `sprite`) {
            const r = part.rect;
            if (part.rotated) {
              ctx.translate(x + part.w / 2, y + part.h / 2);
              ctx.rotate(-Math.PI / 2);
              ctx.drawImage(part.src, r.x, r.y, r.height, r.width, -part.h / 2, -part.w / 2, part.h, part.w);
            } else {
              ctx.drawImage(part.src, r.x, r.y, r.width, r.height, x, y, part.w, part.h);
            }
          } else {
            ctx.fillStyle = part.colour;
            ctx.font = `600 ${part.size}px system-ui, sans-serif`;
            ctx.textAlign = `center`;
            ctx.textBaseline = `middle`;
            ctx.fillText(part.text, x + part.w / 2, y + part.h / 2);
          }
        } catch (err) { /* that part is left out */ }
      }
      ctx.globalAlpha = 1;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
    };

    const openPacketEditor = (codename, label = codename) => {
      packetWindow?.__close?.();
      let layers = [];
      let selected = null;
      let nextId = 1;
      let live = true;
      let trimOnAdd = true;
      let showCard = true;
      let saved = false;
      let status = ``;
      let libraryOpen = false;
      let library = null;
      let saveName = `${label} packet`;
      let card = cardSnapshot(codename);
      // What the game's card shows under and over the pictures.
      const look = { hideBg: false, hidePlate: false, hideFamily: false, ...(packetLooks.get(codename) ?? {}) };
      const before = {
        plant: packetTextures.get(codename) ?? null,
        back: packetBacks.get(codename) ?? null,
        front: packetFronts.get(codename) ?? null,
        scale: packetScales.get(codename),
        offset: packetOffsets.get(codename),
        look: packetLooks.get(codename) ?? null,
      };
      const pictures = new Map(); // layer id -> loaded Image
      const makeLayer = (l) => ({
        id: l.id ?? `L${nextId++}`,
        name: l.name ?? `layer`,
        kind: l.kind === `box` ? `box` : `image`,
        part: PARTS.includes(l.part) ? l.part : `plant`,
        src: l.src ?? null,
        x: l.x ?? 0,
        y: l.y ?? 0,
        scale: l.scale ?? 1,
        sx: l.sx ?? 1,
        rotation: l.rotation ?? 0,
        flip: !!l.flip,
        opacity: l.opacity ?? 1,
        outline: !!l.outline,
        hidden: !!l.hidden,
        color: l.color ?? `#2f7d32`,
        w: l.w ?? 70,
        h: l.h ?? 62,
        round: l.round ?? 8,
      });
      const byId = (id) => layers.find((l) => l.id === id) ?? null;
      const snapshot = () => JSON.stringify({ layers, look });
      let history = [];
      let future = [];
      const commit = () => {
        const now = snapshot();
        if (history[history.length - 1] === now) return;
        history.push(now);
        if (history.length > 100) history.shift();
        future = [];
        preview();
      };
      const restoreFrom = (text) => {
        const state = JSON.parse(text);
        layers = state.layers.map(makeLayer);
        Object.assign(look, state.look);
        if (!byId(selected)) selected = layers[layers.length - 1]?.id ?? null;
        preview();
        render();
      };
      const undo = () => {
        if (history.length < 2) return;
        future.push(history.pop());
        restoreFrom(history[history.length - 1]);
      };
      const redo = () => {
        if (!future.length) return;
        const next = future.pop();
        history.push(next);
        restoreFrom(next);
      };

      // ---- the card ----
      // Its size, in card units from the plant art, y down: measured off a
      // real card when one has been built, or a guess until then. The saved
      // pictures cover the card and a margin round it, so art can hang over
      // the edge a little and nothing inside the card is ever cut off.
      const GUESS = { x: -55, y: -48, w: 110, h: 86 };
      let frame = cardRectSeen ?? GUESS;
      const area = () => {
        const pad = Math.round(Math.max(frame.w, frame.h) * 0.2);
        return { x: frame.x - pad, y: frame.y - pad, w: frame.w + pad * 2, h: frame.h + pad * 2 };
      };
      const measure = () => {
        const cards = liveCards();
        const real = cards.find((c) => c?.Type === codename) ?? cards[cards.length - 1];
        if (real) measureCard(real);
        frame = cardRectSeen ?? GUESS;
        card = cardSnapshot(codename);
      };

      const pictureOfLayer = (l) => {
        if (l.kind !== `image` || !l.src) return null;
        if (!pictures.has(l.id)) {
          pictures.set(l.id, null);
          loadPicture(l.src).then((pic) => {
            pictures.set(l.id, pic);
            render();
            preview();
          }).catch(() => { /* drawn as a gap */ });
        }
        return pictures.get(l.id);
      };
      // Sizes in card units: a picture at size 1 is as tall as the art box,
      // and Stretch wide widens it on its own.
      const sizeOf = (l) => {
        if (l.kind === `box`) return { w: l.w * l.scale * (l.sx ?? 1), h: l.h * l.scale };
        const pic = pictureOfLayer(l);
        const h = PACKET_H * l.scale;
        return { w: (pic ? (h * pic.width) / Math.max(1, pic.height) : h) * (l.sx ?? 1), h };
      };
      const layerMatrix = (l) => M.scale(M.at(l.x, l.y, l.rotation), l.flip ? -1 : 1, 1);
      const inPart = (part) => layers.filter((l) => l.part === part);
      const paintLayers = (ctx, base, list) => {
        for (const l of list) {
          if (l.hidden) continue;
          const { w, h } = sizeOf(l);
          const m = M.mul(base, layerMatrix(l));
          ctx.setTransform(m[0], m[1], m[2], m[3], m[4], m[5]);
          ctx.globalAlpha = Math.max(0, Math.min(1, l.opacity));
          if (l.outline) {
            ctx.shadowColor = `rgba(0,0,0,0.9)`;
            ctx.shadowBlur = 6;
          }
          if (l.kind === `box`) {
            const r = Math.min(l.round, w / 2, h / 2);
            ctx.fillStyle = l.color;
            ctx.beginPath();
            ctx.moveTo(-w / 2 + r, -h / 2);
            ctx.arcTo(w / 2, -h / 2, w / 2, h / 2, r);
            ctx.arcTo(w / 2, h / 2, -w / 2, h / 2, r);
            ctx.arcTo(-w / 2, h / 2, -w / 2, -h / 2, r);
            ctx.arcTo(-w / 2, -h / 2, w / 2, -h / 2, r);
            ctx.closePath();
            ctx.fill();
          } else {
            const pic = pictureOfLayer(l);
            if (pic) ctx.drawImage(pic, -w / 2, -h / 2, w, h);
          }
          ctx.shadowColor = `transparent`;
          ctx.shadowBlur = 0;
          ctx.globalAlpha = 1;
        }
        ctx.setTransform(1, 0, 0, 1, 0, 0);
      };
      // Where the game's card is, when its background is still showing.
      const drawCardShape = (ctx, base) => {
        ctx.setTransform(base[0], base[1], base[2], base[3], base[4], base[5]);
        const r = Math.min(8, frame.w / 6);
        ctx.beginPath();
        ctx.moveTo(frame.x + r, frame.y);
        ctx.arcTo(frame.x + frame.w, frame.y, frame.x + frame.w, frame.y + frame.h, r);
        ctx.arcTo(frame.x + frame.w, frame.y + frame.h, frame.x, frame.y + frame.h, r);
        ctx.arcTo(frame.x, frame.y + frame.h, frame.x, frame.y, r);
        ctx.arcTo(frame.x, frame.y, frame.x + frame.w, frame.y, r);
        ctx.closePath();
        if (!look.hideBg) {
          ctx.fillStyle = `rgba(92,140,60,0.55)`;
          ctx.fill();
        }
        ctx.setTransform(1, 0, 0, 1, 0, 0);
      };
      // The whole card, in the order the game draws it.
      const paintCard = (ctx, base, withCard) => {
        if (withCard) drawCardShape(ctx, base);
        paintLayers(ctx, base, inPart(`back`));
        if (withCard && card) drawCardParts(ctx, card.under, base);
        paintLayers(ctx, base, inPart(`plant`));
        paintLayers(ctx, base, inPart(`front`));
        if (withCard && card) drawCardParts(ctx, card.over, base);
      };
      // One saved picture per part, all the same size and place.
      const PX = 4;
      const compose = (part) => {
        const list = inPart(part).filter((l) => !l.hidden);
        if (!list.length) return null;
        const a = area();
        const out = doc.createElement(`canvas`);
        out.width = Math.round(a.w * PX);
        out.height = Math.round(a.h * PX);
        paintLayers(out.getContext(`2d`), [PX, 0, 0, PX, -a.x * PX, -a.y * PX], list);
        return out.toDataURL(`image/png`);
      };
      // What dressCard needs to put them where the editor had them.
      const placement = () => {
        const a = area();
        return {
          scale: Math.round((a.h / PACKET_H) * 1000) / 1000,
          offset: { x: Math.round((a.x + a.w / 2) * 10) / 10, y: -Math.round((a.y + a.h / 2) * 10) / 10 },
        };
      };
      const showOnPackets = (textures, scale, offset, cardLook) => {
        const put = (map, tex) => (tex ? map.set(codename, tex) : map.delete(codename));
        put(packetTextures, textures.plant);
        put(packetBacks, textures.back);
        put(packetFronts, textures.front);
        if (cardLook) packetLooks.set(codename, { ...cardLook });
        else packetLooks.delete(codename);
        if (scale === undefined) packetScales.delete(codename);
        else packetScales.set(codename, scale);
        if (offset) packetOffsets.set(codename, offset);
        else packetOffsets.delete(codename);
        for (const c of new Set([...dressedCards, ...liveCards()])) {
          if (c?.Type !== codename) continue;
          try {
            if (wantsCardLook(codename)) {
              dressCard(c, textures.plant, scale);
              dressedCards.add(c);
            } else {
              undressCard(c);
              dressedCards.delete(c);
            }
          } catch (err) { /* card is gone */ }
        }
      };
      const restoreBefore = () => showOnPackets(before, before.scale, before.offset, before.look);
      // The three pictures as textures, parts with nothing in them as null.
      const texturesNow = () => Promise.all(PARTS.map((part) => {
        const url = compose(part);
        return url ? imageFrom(url).then((asset) => [part, textureFrom(asset), url]) : Promise.resolve([part, null, null]);
      }));
      let previewTimer = null;
      const preview = () => {
        if (!live) return;
        clearTimeout(previewTimer);
        previewTimer = setTimeout(() => {
          texturesNow()
            .then((made) => {
              const textures = Object.fromEntries(made.map(([part, tex]) => [part, tex]));
              const { scale, offset } = placement();
              showOnPackets(textures, scale, offset, look);
            })
            .catch(() => { /* next change */ });
        }, 200);
      };

      // ---- window ----
      const box = el(`div`, {
        position: `fixed`, top: `3vh`, right: `2vw`, width: `min(900px, 70vw)`, height: `92vh`, zIndex: `100001`,
        display: `flex`, flexDirection: `column`, gap: `8px`, background: `rgba(16,16,16,0.98)`, color: `#eee`,
        padding: `10px`, border: `1px solid #444`, borderRadius: `8px`, boxShadow: `0 8px 40px rgba(0,0,0,0.7)`,
        font: `12px system-ui, sans-serif`, outline: `none`,
      });
      box.tabIndex = 0;
      for (const type of [`keydown`, `keyup`, `keypress`, `wheel`, `mousedown`, `mouseup`, `click`, `pointerdown`, `pointerup`, `touchstart`, `touchend`]) {
        box.addEventListener(type, (ev) => ev.stopPropagation());
      }
      packetWindow = box;
      const head = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px`, flexWrap: `wrap` });
      const body = el(`div`, { flex: `1`, display: `flex`, gap: `10px`, minHeight: `0` });
      const stage = el(`div`, { flex: `1`, position: `relative`, minWidth: `0`, borderRadius: `6px`, overflow: `hidden`, background: CHECKER });
      const canvas = doc.createElement(`canvas`);
      style(canvas, { position: `absolute`, inset: `0`, width: `100%`, height: `100%`, display: `block` });
      stage.appendChild(canvas);
      const side = el(`div`, { width: `310px`, display: `flex`, flexDirection: `column`, gap: `8px`, overflowY: `auto`, minHeight: `0` });
      body.appendChild(stage);
      body.appendChild(side);
      box.appendChild(head);
      box.appendChild(body);

      const view = { z: 3, x: 0, y: 0, fitted: false };
      const fitView = () => {
        const a = area();
        view.z = Math.min(canvas.width / (a.w * 1.1), canvas.height / (a.h * 1.1));
        view.x = canvas.width / 2 - (a.x + a.w / 2) * view.z;
        view.y = canvas.height / 2 - (a.y + a.h / 2) * view.z;
        view.fitted = true;
      };
      const sizeCanvas = () => {
        const rect = canvas.getBoundingClientRect?.() ?? { width: 480, height: 480 };
        const w = Math.max(200, Math.round(rect.width));
        const h = Math.max(200, Math.round(rect.height));
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
          view.fitted = false;
        }
        if (!view.fitted) fitView();
      };
      const toUnits = (ev) => {
        const r = canvas.getBoundingClientRect();
        const sx = ev.clientX - r.left;
        const sy = ev.clientY - r.top;
        return { x: (sx - view.x) / view.z, y: (sy - view.y) / view.z, sx, sy };
      };
      const viewMatrix = () => [view.z, 0, 0, view.z, view.x, view.y];
      // Corner handles, side handles and the turn knob of the picked layer.
      const handlesOf = (l) => {
        const { w, h } = sizeOf(l);
        const m = M.mul(viewMatrix(), layerMatrix(l));
        const at = (x, y) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]];
        return {
          corners: [at(-w / 2, -h / 2), at(w / 2, -h / 2), at(w / 2, h / 2), at(-w / 2, h / 2)],
          sides: [at(-w / 2, 0), at(w / 2, 0)],
          knob: at(0, -h / 2 - 16 / view.z),
          top: at(0, -h / 2),
          centre: at(0, 0),
        };
      };
      const draw = () => {
        if (packetWindow !== box) return;
        sizeCanvas();
        const ctx = canvas.getContext(`2d`);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        paintCard(ctx, viewMatrix(), showCard);
        // The card's edge, and what gets saved round it.
        const a = area();
        ctx.setLineDash([6, 4]);
        ctx.lineWidth = 1;
        ctx.strokeStyle = `rgba(255,255,255,0.3)`;
        ctx.strokeRect(view.x + a.x * view.z, view.y + a.y * view.z, a.w * view.z, a.h * view.z);
        ctx.setLineDash([]);
        ctx.strokeStyle = `rgba(255,214,10,0.7)`;
        ctx.strokeRect(view.x + frame.x * view.z, view.y + frame.y * view.z, frame.w * view.z, frame.h * view.z);
        const l = byId(selected);
        if (l && !l.hidden) {
          const hd = handlesOf(l);
          ctx.strokeStyle = `#4cd964`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          hd.corners.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
          ctx.closePath();
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(hd.top[0], hd.top[1]);
          ctx.lineTo(hd.knob[0], hd.knob[1]);
          ctx.stroke();
          ctx.fillStyle = `#4cd964`;
          for (const [x, y] of hd.corners) ctx.fillRect(x - 5, y - 5, 10, 10);
          ctx.fillStyle = `#64d2ff`;
          for (const [x, y] of hd.sides) ctx.fillRect(x - 4, y - 7, 8, 14);
          ctx.fillStyle = `#4cd964`;
          ctx.beginPath();
          ctx.arc(hd.knob[0], hd.knob[1], 6, 0, Math.PI * 2);
          ctx.fill();
        }
        drawSmall();
      };
      // The packet at about the size it shows in game.
      const small = doc.createElement(`canvas`);
      small.width = 150;
      small.height = 150;
      const drawSmall = () => {
        const ctx = small.getContext(`2d`);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, small.width, small.height);
        const a = area();
        const k = Math.min(small.width / a.w, small.height / a.h);
        paintCard(ctx, [k, 0, 0, k, small.width / 2 - (a.x + a.w / 2) * k, small.height / 2 - (a.y + a.h / 2) * k], true);
      };

      // ---- dragging ----
      let dragging = null;
      const layerAt = (pt) => {
        // Top first: border, then plant, then background.
        const order = [...inPart(`back`), ...inPart(`plant`), ...inPart(`front`)];
        for (let i = order.length - 1; i >= 0; i--) {
          const l = order[i];
          if (l.hidden) continue;
          const { w, h } = sizeOf(l);
          const local = M.mul(M.inv(layerMatrix(l)), [1, 0, 0, 1, pt.x, pt.y]);
          if (Math.abs(local[4]) <= w / 2 && Math.abs(local[5]) <= h / 2) return l;
        }
        return null;
      };
      const near = (a, b, r = 9) => Math.hypot(a[0] - b[0], a[1] - b[1]) <= r;
      // Snaps to the middle of the art box and to the card's middle and edges.
      const snapX = () => [0, frame.x + frame.w / 2];
      const snapY = () => [0, frame.y + frame.h / 2];
      const snap = (v, targets) => {
        const reach = 2.5 / (view.z / 3);
        for (const t of targets) if (Math.abs(v - t) < reach) return t;
        return v;
      };
      const onMove = (ev) => {
        if (!dragging) return;
        const at = toUnits(ev);
        const d = dragging;
        if (d.kind === `pan`) {
          view.x = d.vx + (at.sx - d.sx);
          view.y = d.vy + (at.sy - d.sy);
        } else if (d.kind === `move`) {
          const x = snap(d.x0 + at.x - d.from.x, snapX());
          const y = snap(d.y0 + at.y - d.from.y, snapY());
          d.layer.x = Math.round(x * 2) / 2;
          d.layer.y = Math.round(y * 2) / 2;
        } else if (d.kind === `turn`) {
          const a = Math.atan2(at.y - d.layer.y, at.x - d.layer.x);
          let r = d.r0 + ((a - d.a0) * 180) / Math.PI;
          if (ev.shiftKey) r = Math.round(r / 15) * 15;
          d.layer.rotation = Math.round(((r + 540) % 360) - 180);
        } else if (d.kind === `size`) {
          const dist = Math.hypot(at.x - d.layer.x, at.y - d.layer.y);
          d.layer.scale = Math.max(0.05, Math.min(12, Math.round(((d.s0 * dist) / Math.max(0.01, d.dist0)) * 100) / 100));
        } else if (d.kind === `stretch`) {
          // Along the layer's own width, however it's turned.
          const r = (d.layer.rotation * Math.PI) / 180;
          const along = Math.abs((at.x - d.layer.x) * Math.cos(r) + (at.y - d.layer.y) * Math.sin(r));
          d.layer.sx = Math.max(0.05, Math.min(12, Math.round(((d.sx0 * along) / Math.max(0.01, d.along0)) * 100) / 100));
        }
        draw();
      };
      const onUp = () => {
        doc.removeEventListener?.(`mousemove`, onMove, true);
        doc.removeEventListener?.(`mouseup`, onUp, true);
        if (dragging && dragging.kind !== `pan`) commit();
        dragging = null;
        render();
      };
      const listen = () => {
        doc.addEventListener?.(`mousemove`, onMove, true);
        doc.addEventListener?.(`mouseup`, onUp, true);
      };
      canvas.onmousedown = (ev) => {
        ev.preventDefault?.();
        box.focus?.();
        const at = toUnits(ev);
        if (ev.button !== 0 || ev.altKey) {
          dragging = { kind: `pan`, sx: at.sx, sy: at.sy, vx: view.x, vy: view.y };
          listen();
          return;
        }
        const picked = byId(selected);
        if (picked && !picked.hidden) {
          const hd = handlesOf(picked);
          const pt = [at.sx, at.sy];
          if (near(pt, hd.knob)) {
            dragging = { kind: `turn`, layer: picked, a0: Math.atan2(at.y - picked.y, at.x - picked.x), r0: picked.rotation };
            listen();
            return;
          }
          if (hd.corners.some((c) => near(pt, c))) {
            dragging = { kind: `size`, layer: picked, s0: picked.scale, dist0: Math.hypot(at.x - picked.x, at.y - picked.y) };
            listen();
            return;
          }
          if (hd.sides.some((c) => near(pt, c))) {
            const r = (picked.rotation * Math.PI) / 180;
            dragging = { kind: `stretch`, layer: picked, sx0: picked.sx ?? 1, along0: Math.abs((at.x - picked.x) * Math.cos(r) + (at.y - picked.y) * Math.sin(r)) };
            listen();
            return;
          }
        }
        const l = layerAt(at);
        selected = l?.id ?? null;
        if (l) {
          dragging = ev.shiftKey
            ? { kind: `turn`, layer: l, a0: Math.atan2(at.y - l.y, at.x - l.x), r0: l.rotation }
            : { kind: `move`, layer: l, from: at, x0: l.x, y0: l.y };
        } else {
          dragging = { kind: `pan`, sx: at.sx, sy: at.sy, vx: view.x, vy: view.y };
        }
        listen();
        render();
      };
      canvas.onwheel = (ev) => {
        ev.preventDefault?.();
        const at = toUnits(ev);
        const z = Math.min(20, Math.max(0.3, view.z * (ev.deltaY < 0 ? 1.12 : 1 / 1.12)));
        view.x = at.sx - at.x * z;
        view.y = at.sy - at.y * z;
        view.z = z;
        draw();
      };
      canvas.oncontextmenu = (ev) => ev.preventDefault?.();
      box.addEventListener(`keydown`, (ev) => {
        const typing = /^(INPUT|SELECT|TEXTAREA)$/.test(ev.target?.tagName ?? ``) && ev.target.type !== `range` && ev.target.type !== `checkbox`;
        const ctrl = ev.ctrlKey || ev.metaKey;
        if (ctrl && (ev.key === `z` || ev.key === `Z`)) {
          ev.preventDefault();
          if (ev.shiftKey) redo();
          else undo();
          return;
        }
        if (ctrl && (ev.key === `y` || ev.key === `Y`)) {
          ev.preventDefault();
          redo();
          return;
        }
        if (typing) return;
        const l = byId(selected);
        if (!l) return;
        const step = ev.shiftKey ? 5 : 0.5;
        const act = (fn) => {
          ev.preventDefault();
          fn();
          commit();
          render();
        };
        switch (ev.key) {
          case `ArrowLeft`: act(() => { l.x -= step; }); break;
          case `ArrowRight`: act(() => { l.x += step; }); break;
          case `ArrowUp`: act(() => { l.y -= step; }); break;
          case `ArrowDown`: act(() => { l.y += step; }); break;
          case `Delete`: case `Backspace`: act(() => { removeLayer(l); }); break;
          case `d`: case `D`: if (ctrl) act(() => { duplicate(l); }); break;
          default: break;
        }
      });

      // ---- layers ----
      // A background of your own is meant to replace the game's.
      const firstBack = (layer) => {
        if (layer.part !== `back` || inPart(`back`).some((q) => q !== layer) || look.hideBg) return;
        look.hideBg = true;
        status = `The game's background is switched off under yours. Untick it under The card to have both.`;
      };
      const addLayer = (l) => {
        const layer = makeLayer(l);
        layers.push(layer);
        firstBack(layer);
        selected = layer.id;
        commit();
        render();
        return layer;
      };
      const removeLayer = (l) => {
        layers = layers.filter((q) => q !== l);
        selected = layers[layers.length - 1]?.id ?? null;
      };
      const duplicate = (l) => {
        const copy = makeLayer({ ...l, id: undefined, name: `${l.name} copy`, x: l.x + 4, y: l.y + 4 });
        if (pictures.get(l.id)) pictures.set(copy.id, pictures.get(l.id));
        layers.splice(layers.indexOf(l) + 1, 0, copy);
        selected = copy.id;
      };
      // Moves a layer up or down within its own part.
      const shiftLayer = (l, by) => {
        const same = inPart(l.part);
        const j = same.indexOf(l) + by;
        if (j < 0 || j >= same.length) return;
        const other = same[j];
        const a = layers.indexOf(l);
        const b = layers.indexOf(other);
        [layers[a], layers[b]] = [layers[b], layers[a]];
      };
      // Stretched to cover the card exactly: what a background or a border
      // drawn at the card's shape wants.
      const fillCard = (l) => {
        l.x = Math.round((frame.x + frame.w / 2) * 2) / 2;
        l.y = Math.round((frame.y + frame.h / 2) * 2) / 2;
        l.rotation = 0;
        if (l.kind === `box`) {
          l.w = frame.w;
          l.h = frame.h;
          l.scale = 1;
          l.sx = 1;
          return;
        }
        const pic = pictureOfLayer(l);
        l.scale = Math.round((frame.h / PACKET_H) * 1000) / 1000;
        l.sx = pic ? Math.round(((frame.w / frame.h) * (pic.height / Math.max(1, pic.width))) * 1000) / 1000 : 1;
      };
      // Big enough to fill the art box, and in the middle of it.
      const fitToBox = (l) => {
        const { w, h } = sizeOf({ ...l, scale: 1 });
        l.scale = Math.round(Math.min(1, (PACKET_H * 1.1) / Math.max(1, w)) * (PACKET_H / Math.max(1, h)) * 100) / 100;
        l.x = 0;
        l.y = 0;
        l.rotation = 0;
      };
      const addPicture = (src, name, part = `plant`, fill = false) => (trimOnAdd && part === `plant` ? trimPicture(src) : Promise.resolve(src))
        .then((clean) => loadPicture(clean).then((pic) => {
          const layer = makeLayer({ name, src: clean, part });
          pictures.set(layer.id, pic);
          if (fill) fillCard(layer);
          layers.push(layer);
          firstBack(layer);
          selected = layer.id;
          commit();
          render();
          return layer;
        }));
      const addPictures = (part, fill) => pickFiles((urls, names) => {
        urls.forEach((src, i) => addPicture(src, String(names[i] ?? `picture`).replace(/\.[a-z]+$/i, ``), part, fill));
      });
      const addStored = (key, name) => {
        const src = stored(key);
        if (src) addPicture(src, name);
      };
      const addRigPose = () => rigPose(codename).then((src) => {
        if (src) addPicture(src, `rig pose`);
        else {
          status = `${label} has no rig yet. Make one in the animation maker.`;
          render();
        }
      });

      // ---- saving ----
      // The pictures go where every other look for this plant goes: into the
      // pack that adds it, or the home pack. The layers go beside them,
      // to open again.
      const project = () => ({ kind: `greenhouse-packet`, version: 2, layers, card: { ...look } });
      const save = () => {
        status = `Saving...`;
        render();
        texturesNow()
          .then((made) => {
            const { scale, offset } = placement();
            const keys = { plant: `packet`, back: `packetback`, front: `packetfront` };
            const textures = {};
            for (const [part, tex, url] of made) {
              textures[part] = tex;
              if (url) remember(`${keys[part]}:${codename}`, url);
              else forget(`${keys[part]}:${codename}`);
            }
            remember(`packetscale:${codename}`, String(scale));
            remember(`packetoffset:${codename}`, `${offset.x},${offset.y}`);
            try {
              remember(`packetproj:${codename}`, JSON.stringify(project()));
            } catch (err) {
              e.log.error(`[Textures] ${label}: the packet saved, but its layers were too big to keep for editing again.`);
            }
            showOnPackets(textures, scale, offset, look);
            saved = true;
            const where = homeFor(`packet:${codename}`);
            status = `Saved into ${where ? `${packNameOf(where)}/textures` : `local storage`}. It's on ${label}'s packets now.`;
            e.log.info(`[Textures] ${label}: packet saved from ${layers.length} layer(s).`);
            drawPanel();
            render();
          })
          .catch((err) => {
            status = `Couldn't save: ${err.message}`;
            render();
          });
      };
      box.__close = () => {
        clearTimeout(previewTimer);
        doc.removeEventListener?.(`mousemove`, onMove, true);
        doc.removeEventListener?.(`mouseup`, onUp, true);
        // Unsaved changes come back off the packets.
        if (!saved) restoreBefore();
        box.remove();
        if (packetWindow === box) packetWindow = null;
      };

      // ---- panel ----
      const section = (title) => {
        const s = el(`div`, { background: `#1d1d1d`, borderRadius: `6px`, padding: `8px`, display: `flex`, flexDirection: `column`, gap: `6px` });
        if (title) s.appendChild(el(`div`, { font: `600 12px system-ui, sans-serif` }, title));
        side.appendChild(s);
        return s;
      };
      const labelled = (text, control) => {
        const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px` });
        line.appendChild(el(`span`, { width: `78px`, flex: `0 0 auto`, opacity: `0.8` }, text));
        line.appendChild(control);
        return line;
      };
      const range = (value, min, max, stepBy, onInput, shown = (v) => `${v}`) => {
        const wrap = el(`span`, { display: `flex`, alignItems: `center`, gap: `6px`, flex: `1`, minWidth: `0` });
        const input = doc.createElement(`input`);
        input.type = `range`;
        input.min = String(min);
        input.max = String(max);
        input.step = String(stepBy);
        input.value = String(value);
        style(input, { flex: `1`, minWidth: `0` });
        const readout = el(`span`, { width: `44px`, textAlign: `right`, opacity: `0.7` }, shown(value));
        input.oninput = () => {
          onInput(Number(input.value));
          readout.textContent = shown(Number(input.value));
          draw();
        };
        input.onchange = () => commit();
        wrap.appendChild(input);
        wrap.appendChild(readout);
        return wrap;
      };
      const tick = (text, on, set) => {
        const wrap = el(`label`, { display: `flex`, alignItems: `center`, gap: `4px`, cursor: `pointer` });
        const input = doc.createElement(`input`);
        input.type = `checkbox`;
        input.checked = on;
        input.onchange = () => {
          set(input.checked);
          commit();
          render();
        };
        wrap.appendChild(input);
        wrap.appendChild(el(`span`, {}, text));
        return wrap;
      };
      const row = (...buttons) => {
        const line = el(`div`, { display: `flex`, flexWrap: `wrap`, gap: `4px` });
        for (const b of buttons) {
          b.style.marginLeft = `0`;
          line.appendChild(b);
        }
        return line;
      };
      const swatch = (l) => {
        const c = doc.createElement(`canvas`);
        c.width = 34;
        c.height = 34;
        style(c, { flex: `0 0 auto`, background: CHECKER, borderRadius: `3px` });
        const ctx = c.getContext(`2d`);
        if (l.kind === `box`) {
          ctx.fillStyle = l.color;
          ctx.fillRect(4, 8, 26, 18);
        } else {
          const pic = pictureOfLayer(l);
          if (pic) {
            const k = Math.min(34 / Math.max(1, pic.width), 34 / Math.max(1, pic.height));
            ctx.drawImage(pic, (34 - pic.width * k) / 2, (34 - pic.height * k) / 2, pic.width * k, pic.height * k);
          }
        }
        return c;
      };
      const renderLibrary = () => {
        side.appendChild(el(`div`, { font: `600 13px system-ui, sans-serif`, margin: `2px 0 6px` }, `Saved packet designs`));
        const home = mainHome();
        side.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4`, marginBottom: `8px` },
          `Kept like saved animations: a file each in ${home ? `${packNameOf(home)}/textures/saved` : `local storage`}, with every picture inside. `
          + `Open one on any plant, then Save to put it on that plant's packets.`));
        const nameLine = el(`div`, { display: `flex`, gap: `6px`, marginBottom: `10px` });
        const input = doc.createElement(`input`);
        input.value = saveName;
        style(input, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `4px` });
        input.oninput = () => {
          saveName = input.value;
        };
        nameLine.appendChild(input);
        nameLine.appendChild(button(`Save design`, () => {
          if (!layers.length) {
            status = `Nothing to save yet.`;
            render();
            return;
          }
          saveDesign({ name: saveName, codename, label, layers, card: { ...look } })
            .then(({ where, record }) => {
              status = `Saved "${record.name}" in ${where}.`;
              library = null;
              render();
            })
            .catch((err) => {
              status = `Couldn't save: ${err.message}`;
              render();
            });
        }));
        side.appendChild(nameLine);
        if (library === null) {
          library = `reading`;
          listDesigns()
            .then((list) => { library = list; })
            .catch(() => { library = []; })
            .finally(() => { if (libraryOpen) render(); });
        }
        if (library === `reading`) {
          side.appendChild(el(`div`, { opacity: `0.7` }, `Reading...`));
          return;
        }
        if (!library.length) {
          side.appendChild(el(`div`, { opacity: `0.7` }, `No designs saved yet.`));
          return;
        }
        for (const { record } of library) {
          const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px`, padding: `4px`, borderRadius: `4px`,
            background: record.codename === codename ? `#1c3a20` : `transparent` });
          const text = el(`div`, { flex: `1`, minWidth: `0` });
          text.appendChild(el(`div`, { overflow: `hidden`, textOverflow: `ellipsis`, whiteSpace: `nowrap` }, record.name));
          text.appendChild(el(`div`, { opacity: `0.6`, fontSize: `11px` },
            `${record.label ?? record.codename}, ${record.layers.length} layers, ${String(record.saved ?? ``).slice(0, 16).replace(`T`, ` `)}`));
          line.appendChild(text);
          line.appendChild(button(`Open`, () => {
            pictures.clear();
            layers = record.layers.map((q) => makeLayer({ ...q, id: undefined }));
            Object.assign(look, { hideBg: false, hidePlate: false, hideFamily: false, ...(record.card ?? {}) });
            selected = layers[layers.length - 1]?.id ?? null;
            libraryOpen = false;
            status = `Opened "${record.name}". Save puts it on ${label}'s packets.`;
            commit();
            render();
          }, `quiet`));
          side.appendChild(line);
        }
      };
      const partTitle = { front: `Border (over the plant)`, plant: `Plant`, back: `Background (under the plant)` };
      const render = () => {
        if (packetWindow !== box) return;
        head.innerHTML = ``;
        head.appendChild(el(`div`, { font: `600 14px system-ui, sans-serif`, marginRight: `8px` }, `Packet editor: ${label}`));
        head.appendChild(button(`Background`, () => addPictures(`back`, true)));
        head.appendChild(button(`Border`, () => addPictures(`front`, true)));
        head.appendChild(button(`Plant pictures`, () => addPictures(`plant`, false)));
        head.appendChild(button(`Colour`, () => {
          const layer = makeLayer({ name: `colour`, kind: `box`, part: `back` });
          fillCard(layer);
          addLayer(layer);
        }, `quiet`));
        if (stored(`still:${codename}`)) head.appendChild(button(`Its still`, () => addStored(`still:${codename}`, `still image`), `quiet`));
        if (stored(`rig:${codename}`)) head.appendChild(button(`Its rig`, addRigPose, `quiet`));
        if (stored(`packet:${codename}`)) head.appendChild(button(`Its packet now`, () => addStored(`packet:${codename}`, `packet now`), `quiet`));
        head.appendChild(el(`span`, { flex: `1` }));
        head.appendChild(button(`Undo`, undo, `quiet`));
        head.appendChild(button(`Redo`, redo, `quiet`));
        head.appendChild(button(libraryOpen ? `Back to editing` : `Saved`, () => {
          libraryOpen = !libraryOpen;
          render();
        }, libraryOpen ? undefined : `quiet`));
        head.appendChild(button(`Save`, save));
        head.appendChild(button(`Close`, () => box.__close(), `warn`));

        const scroll = side.scrollTop;
        side.innerHTML = ``;
        if (status) side.appendChild(el(`div`, { background: `#1f3a24`, borderRadius: `6px`, padding: `6px 8px`, lineHeight: `1.4` }, status));
        if (libraryOpen) {
          renderLibrary();
          draw();
          return;
        }

        const lookBox = section(`How it looks`);
        const smallWrap = el(`div`, { display: `flex`, gap: `8px`, alignItems: `center` });
        style(small, { background: CHECKER, borderRadius: `4px`, flex: `0 0 auto`, width: `110px`, height: `110px` });
        smallWrap.appendChild(small);
        smallWrap.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4` }, cardRectSeen
          ? `The yellow line is the card's edge, measured off a real one. The dashed line is the most that's saved: art can hang over the edge that far.`
          : `The card's size is a guess until one has been on screen. Open the seed chooser, then press Measure the card.`));
        lookBox.appendChild(smallWrap);
        lookBox.appendChild(row(
          button(`Measure the card`, () => {
            measure();
            view.fitted = false;
            status = cardRectSeen ? `Card measured: ${frame.w} by ${frame.h}.` : `No packets on screen to measure. Open the seed chooser first.`;
            commit();
            render();
          }, `quiet`),
          button(`Fit view`, () => {
            fitView();
            draw();
          }, `quiet`),
        ));
        lookBox.appendChild(tick(`Show the card behind it`, showCard, (v) => { showCard = v; }));
        lookBox.appendChild(tick(`Live: put it on the real packets as I go`, live, (v) => {
          live = v;
          if (!v) restoreBefore();
        }));
        lookBox.appendChild(tick(`Trim empty edges off plant pictures`, trimOnAdd, (v) => { trimOnAdd = v; }));

        const cardBox = section(`The card`);
        cardBox.appendChild(el(`div`, { opacity: `0.75`, lineHeight: `1.4` },
          `The game's own parts of the packet. The sun cost number always stays: it changes in play.`));
        cardBox.appendChild(tick(`Hide the game's background`, look.hideBg, (v) => { look.hideBg = v; }));
        cardBox.appendChild(tick(`Hide the sun cost plate`, look.hidePlate, (v) => { look.hidePlate = v; }));
        cardBox.appendChild(tick(`Hide the family icon`, look.hideFamily, (v) => { look.hideFamily = v; }));

        for (const part of [`front`, `plant`, `back`]) {
          const list = section(partTitle[part]);
          const mine = inPart(part);
          if (!mine.length) {
            list.appendChild(el(`div`, { opacity: `0.6`, lineHeight: `1.4` }, part === `back`
              ? `Nothing: the game's background shows. Background imports a picture stretched to the card, Colour a plain one.`
              : part === `front`
                ? `Nothing. Border imports a picture stretched over the card: a frame with a clear middle.`
                : `Nothing: the plant's own packet art shows. Plant pictures adds one.`));
          }
          [...mine].reverse().forEach((l) => {
            const line = el(`div`, { display: `flex`, alignItems: `center`, gap: `6px`, padding: `3px 4px`, borderRadius: `4px`, cursor: `pointer`,
              background: l.id === selected ? `#24502a` : `transparent`, opacity: l.hidden ? `0.5` : `1` });
            line.onclick = () => {
              selected = l.id;
              render();
            };
            line.appendChild(swatch(l));
            line.appendChild(el(`span`, { flex: `1`, overflow: `hidden`, textOverflow: `ellipsis`, whiteSpace: `nowrap` }, l.name));
            const eye = button(l.hidden ? `Show` : `Hide`, () => {
              l.hidden = !l.hidden;
              commit();
              render();
            }, `quiet`);
            eye.style.padding = `2px 6px`;
            line.appendChild(eye);
            list.appendChild(line);
          });
        }
        const l = byId(selected);
        if (l) {
          const props = section(`Layer: ${l.name}`);
          props.appendChild(row(
            button(`Up`, () => { shiftLayer(l, 1); commit(); render(); }, `quiet`),
            button(`Down`, () => { shiftLayer(l, -1); commit(); render(); }, `quiet`),
            button(`Copy`, () => { duplicate(l); commit(); render(); }, `quiet`),
            button(`Delete`, () => { removeLayer(l); commit(); render(); }, `warn`),
          ));
          const nameBox = doc.createElement(`input`);
          nameBox.value = l.name;
          style(nameBox, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `4px` });
          nameBox.oninput = () => { l.name = nameBox.value; };
          nameBox.onchange = () => { commit(); render(); };
          props.appendChild(labelled(`Name`, nameBox));
          const partSelect = doc.createElement(`select`);
          style(partSelect, { flex: `1`, minWidth: `0`, background: `#111`, color: `#eee`, border: `1px solid #555`, borderRadius: `3px`, padding: `3px` });
          for (const part of [`back`, `plant`, `front`]) {
            const opt = doc.createElement(`option`);
            opt.value = part;
            opt.textContent = { back: `Background`, plant: `Plant`, front: `Border` }[part];
            if (l.part === part) opt.selected = true;
            partSelect.appendChild(opt);
          }
          partSelect.onchange = () => {
            l.part = partSelect.value;
            commit();
            render();
          };
          props.appendChild(labelled(`Part`, partSelect));
          props.appendChild(row(
            button(`Fill the card`, () => { fillCard(l); commit(); render(); }, `quiet`),
            button(`Fit the art box`, () => { fitToBox(l); commit(); render(); }, `quiet`),
            button(`Centre`, () => { l.x = 0; l.y = 0; commit(); render(); }, `quiet`),
            button(`Straighten`, () => { l.rotation = 0; l.sx = 1; commit(); render(); }, `quiet`),
          ));
          const a = area();
          props.appendChild(labelled(`Size`, range(l.scale, 0.05, 6, 0.01, (v) => { l.scale = v; }, (v) => `${v}x`)));
          props.appendChild(labelled(`Stretch wide`, range(l.sx ?? 1, 0.05, 6, 0.01, (v) => { l.sx = v; }, (v) => `${v}x`)));
          props.appendChild(labelled(`Turn`, range(l.rotation, -180, 180, 1, (v) => { l.rotation = v; }, (v) => `${v}deg`)));
          props.appendChild(labelled(`Across`, range(l.x, Math.floor(a.x), Math.ceil(a.x + a.w), 0.5, (v) => { l.x = v; })));
          props.appendChild(labelled(`Up`, range(-l.y, Math.floor(-(a.y + a.h)), Math.ceil(-a.y), 0.5, (v) => { l.y = -v; })));
          props.appendChild(labelled(`Opacity`, range(Math.round(l.opacity * 100), 0, 100, 1, (v) => { l.opacity = v / 100; }, (v) => `${v}%`)));
          props.appendChild(row(tick(`Mirror`, l.flip, (v) => { l.flip = v; }), tick(`Shadow`, l.outline, (v) => { l.outline = v; })));
          if (l.kind === `box`) {
            const colour = doc.createElement(`input`);
            colour.type = `color`;
            colour.value = l.color;
            colour.oninput = () => {
              l.color = colour.value;
              draw();
            };
            colour.onchange = () => commit();
            props.appendChild(labelled(`Colour`, colour));
            props.appendChild(labelled(`Width`, range(l.w, 4, Math.ceil(a.w), 1, (v) => { l.w = v; })));
            props.appendChild(labelled(`Height`, range(l.h, 4, Math.ceil(a.h), 1, (v) => { l.h = v; })));
            props.appendChild(labelled(`Rounding`, range(l.round, 0, 40, 1, (v) => { l.round = v; })));
          }
        }
        const help = section(`How to`);
        help.appendChild(el(`div`, { opacity: `0.7`, lineHeight: `1.45` },
          `Drag a layer to move it; it snaps to the middle of the card. Green corners size it, the blue side handles stretch it wide, `
          + `the round knob turns it (Shift for 15 degree steps). Scroll to zoom, drag the background or right-drag to pan. `
          + `Arrow keys nudge, Ctrl+D copies, Delete removes, Ctrl+Z undoes. Anything past the dashed line is cut off.`));
        side.scrollTop = scroll;
        draw();
      };

      // ---- starting point ----
      let project0 = null;
      try {
        project0 = JSON.parse(stored(`packetproj:${codename}`) ?? `null`);
      } catch (err) {
        project0 = null;
      }
      if (project0?.layers?.length) {
        layers = project0.layers.map(makeLayer);
        nextId = layers.length + 1;
        Object.assign(look, project0.card ?? {});
        status = `Your layers from last time.`;
      } else if (stored(`packet:${codename}`)) {
        const scale = packetScales.get(codename) ?? 1;
        const at = packetOffsets.get(codename) ?? { x: 0, y: 0 };
        layers = [makeLayer({ name: `packet now`, src: stored(`packet:${codename}`), scale, x: at.x, y: -at.y })];
      } else if (stored(`still:${codename}`)) {
        layers = [makeLayer({ name: `still image`, src: stored(`still:${codename}`) })];
      }
      selected = layers[layers.length - 1]?.id ?? null;
      history = [snapshot()];
      doc.body.appendChild(box);
      box.focus?.();
      render();
      if (layers.length) preview();
      return box;
    };



    // ==================================================================
    // Dressing on arrival
    //
    // Everything the game shows as a plant goes through
    // AnimationController.readCostume right after it is built: the lawn, the
    // plant in hand while placing, the almanac, the seed chooser, the store,
    // the map. Dressing there, in the same tick, means the first frame drawn
    // is already the custom art rather than the vanilla plant for a second.
    // That only works if every picture is a texture before it is wanted, so
    // they are all decoded at startup and kept.
    // ==================================================================
    const LOOK_SCOPES = new Set([`still`, `plant`, `fit`, `fitart`, `rig`, `rigart`, `stillscale`]);
    // Two counters decide whether a plant needs dressing again. version
    // moves when everything must be looked at (the folders were read, a
    // setting that touches every plant changed); each plant kind has its
    // own, which moves only when that kind's look changes. Re-dressing
    // rebuilds the armature, and the game holds on to parts of it (the
    // points shots come from, slots it swaps), so a plant is only ever
    // rebuilt when its own look changed. Rebuilding every plant on every
    // save left the others broken: on the lawn, doing nothing.
    let version = 0;
    const lookVersions = new Map();
    const bumpLook = (codename) => {
      if (codename) lookVersions.set(codename, (lookVersions.get(codename) ?? 0) + 1);
    };
    const stampOf = (codename) => `${version}.${lookVersions.get(codename) ?? 0}`;
    // Anything saved for this kind of plant, so one with nothing is left alone.
    const wantsLook = (codename) => rigSets.has(codename) || fittedSets.has(codename) || armatureSets.has(codename)
      || [`still`, `plant`, `fitart`, `rigart`].some((scope) => stored(`${scope}:${codename}`));
    const ready = new Map(); // storage key -> { dataUrl, tex, imageAsset, failed }
    const restoring = new Set(); // codenames whose fit or rig is still being rebuilt
    const displays = new Set(); // dressed things that aren't lawn plants

    const prepare = (key) => {
      const dataUrl = stored(key);
      if (!dataUrl) {
        ready.delete(key);
        return Promise.resolve(null);
      }
      const have = ready.get(key);
      if (have?.dataUrl === dataUrl) return have.promise;
      const entry = { dataUrl, tex: null, imageAsset: null, failed: false, promise: null };
      entry.promise = imageFrom(dataUrl)
        .then((imageAsset) => {
          entry.imageAsset = imageAsset;
          entry.tex = textureFrom(imageAsset);
          bumpLook(key.split(`:`)[1]);
          return entry;
        })
        .catch((err) => {
          entry.failed = true;
          e.log.error(`[Textures] ${key} wouldn't load: ${err.message}`);
          return null;
        });
      ready.set(key, entry);
      return entry.promise;
    };
    const readyTex = (key) => {
      const entry = ready.get(key);
      return entry?.tex && entry.dataUrl === stored(key) ? entry.tex : null;
    };
    const readJson = (key) => {
      try {
        return JSON.parse(stored(key) ?? `null`);
      } catch (err) {
        return null;
      }
    };
    const boxesOf = (imageAsset) => {
      const source = imageAsset?.data ?? imageAsset?._data;
      if (!source || typeof source.width !== `number`) return null;
      try {
        return boxesInImage(source);
      } catch (err) {
        return null;
      }
    };

    // Fits and rigs are saved as the choices made in their windows, not as
    // atlases, so they are rebuilt from the picture once it has loaded.
    const restoreFit = (codename) => {
      const choice = readJson(`fit:${codename}`);
      if (!choice?.pairs || !stored(`fitart:${codename}`) || fittedSets.has(codename)) return;
      restoring.add(codename);
      prepare(`fitart:${codename}`)
        .then((entry) => {
          const boxes = entry && boxesOf(entry.imageAsset);
          if (!boxes?.length) return;
          fittedSets.set(codename, {
            atlas: null,
            dataUrl: entry.dataUrl,
            pairs: choice.pairs,
            boxes,
            size: { width: entry.imageAsset.width, height: entry.imageAsset.height },
            tex: entry.tex,
          });
          bumpLook(codename);
        })
        .finally(() => restoring.delete(codename));
    };
    const restoreRig = (codename) => {
      const choice = readJson(`rig:${codename}`);
      if (!choice?.layout?.length || !stored(`rigart:${codename}`) || rigSets.has(codename)) return;
      restoring.add(codename);
      prepare(`rigart:${codename}`)
        .then((entry) => {
          if (!entry) return;
          // Pieces saved since 0.9 carry their own boxes; older ones point
          // at a lump the sheet scan finds.
          const needsScan = choice.layout.some((piece) => !piece.box);
          const boxes = needsScan ? boxesOf(entry.imageAsset) ?? [] : [];
          const layout = choice.layout
            .map((piece, index) => ({ ...piece, box: piece.box ?? boxes[piece.boxIndex ?? index] }))
            .filter((piece) => piece.box);
          if (!layout.length) return;
          const imageSize = { width: entry.imageAsset.width, height: entry.imageAsset.height };
          const options = choice.options ?? {};
          // The skeleton is built on first wear, from the plant it goes on:
          // that is where the clip list comes from.
          rigSets.set(codename, {
            layout,
            dataUrl: entry.dataUrl,
            imageSize,
            options,
            json: null,
            atlasJson: buildRigAtlas(layout, imageSize, `gt_${codename}`),
            tex: entry.tex,
          });
          bumpLook(codename);
        })
        .finally(() => restoring.delete(codename));
    };

    const loadLooks = () => {
      for (const key of Object.keys(saved())) {
        const [scope, codename] = key.split(`:`);
        if (scope === `still` || scope === `plant`) prepare(key);
        if (scope === `fit`) restoreFit(codename);
        if (scope === `rig`) restoreRig(codename);
      }
    };

    // Everything this plant should wear, put on now. Anything whose picture
    // is still decoding is left for the next pass, and the plant is marked
    // done only once nothing is outstanding.
    const dressNow = (target) => {
      if (stopped || !target) return false;
      const codename = codenameOf(target);
      let pending = restoring.has(codename);
      const tex = (key) => {
        const found = readyTex(key);
        if (!found && stored(key) && !ready.get(key)?.failed) {
          pending = true;
          prepare(key);
        }
        return found;
      };
      try {
        const rig = rigSets.get(codename);
        const built = armatureSets.get(codename);
        const fit = fittedSets.get(codename);
        if (rig) {
          const sheet = rig.tex ?? tex(`rigart:${codename}`);
          if (sheet) {
            if (!rig.json) rig.json = buildRigJson(rig.layout, { name: `gt_${codename}`, ...rig.options, template: vanillaClips(target) });
            if (!rig.atlasJson) rig.atlasJson = buildRigAtlas(rig.layout, rig.imageSize, `gt_${codename}`);
            if (wearRig(target, rig.json, rig.atlasJson, sheet)) target.__gtRig = rig;
          }
        } else if (built) {
          wearArmature(target, built);
        } else if (fit) {
          const sheet = fit.tex ?? tex(`fitart:${codename}`);
          const atlas = sheet ? fittedAtlasFor(fit, target) : null;
          if (atlas && fitToRig(target, atlas, sheet)) target.__gtFitted = fit;
        } else if (!stored(`still:${codename}`)) {
          // A still would cover a repainted sheet anyway, so it wins.
          const sheet = tex(`plant:${codename}`);
          if (sheet && dressPlant(target, sheet)) stamped.add(target);
        }
        // A still image is for a plant with no moving art of its own. Laid
        // over a rig it hid the animation completely, so the plant looked
        // static; with a rig, fit or armature it stays saved but unused.
        const picture = rig || built || fit ? null : tex(`still:${codename}`);
        if (picture) still(target, picture, stillScales.get(codename));
      } catch (err) {
        e.log.error(`[Textures] Couldn't dress ${codename}: ${err.message}`);
      }
      if (!pending) target.__gtLook = stampOf(codename);
      return !pending;
    };

    // A lawn plant is dressed as the Plant, so dying and recycling clean it
    // up. Anything else is only its controller, which gets pointed at itself
    // so the same code reads it the same way.
    const targetOf = (anm) => {
      let plant = null;
      try {
        plant = PlantBase ? anm?.node?.getComponent?.(PlantBase) ?? null : null;
      } catch (err) {
        plant = null;
      }
      if (plant) return plant;
      if (!Object.prototype.hasOwnProperty.call(anm, `anmControl`)) {
        Object.defineProperty(anm, `anmControl`, { value: anm, configurable: true, writable: true });
      }
      displays.add(anm);
      return anm;
    };

    let arrivals = 0;
    if (AnimationController?.prototype?.readCostume) {
      e.unsafe.hooks.wrapMethod({
        target: AnimationController.prototype,
        methodName: `readCostume`,
        handler: ({ args, thisArg, callNext }) => {
          const result = callNext(...args);
          if (stopped || !thisArg?.node) return result;
          try {
            const target = targetOf(thisArg);
            // Displays are pooled by prefab, and a pack plant shares its
            // prefab with the vanilla one, so whatever this last showed
            // comes off before it is dressed as what it is now.
            undressPlant(target);
            dressNow(target);
            arrivals++;
          } catch (err) {
            e.log.error(`[Textures] Couldn't dress a plant as it arrived: ${err.message}`);
          }
          return result;
        },
      });
    } else {
      e.log.error(`[Textures] No AnimationController.readCostume: custom art goes on a moment after a plant appears, and not in the almanac.`);
    }

    if (AnimationController?.prototype?.update) {
      e.unsafe.hooks.wrapMethod({
        target: AnimationController.prototype,
        methodName: `update`,
        handler: ({ args, thisArg, callNext }) => {
          const result = callNext(...args);
          const db = thisArg?._db;
          if (db?.__gtSprite) tint(db);
          return result;
        },
      });
    }

    // The catch-up pass: anything that arrived before its picture was ready,
    // and everything once the choices change.
    const settle = () => {
      for (const shown of displays) {
        // A destroyed component has no node at all.
        if (!shown?.node || shown.node.isValid === false) {
          displays.delete(shown);
          continue;
        }
        refresh(shown);
      }
      if (!inLevel()) return;
      for (const plant of PlantPool?.pool?.() ?? []) {
        if (!plant || plant.dead) continue;
        refresh(plant);
      }
    };
    // Dressed again only if its own look moved on; a plant with nothing
    // saved and nothing on is never touched at all.
    const refresh = (target) => {
      const codename = codenameOf(target);
      if (target.__gtLook === stampOf(codename)) return;
      if (!isDressed(target) && !wantsLook(codename)) {
        target.__gtLook = stampOf(codename);
        return;
      }
      undressPlant(target);
      dressNow(target);
    };

    let settling = null;
    onStored = (key) => {
      const [scope] = key.split(`:`);
      if (!LOOK_SCOPES.has(scope)) return;
      if (scope === `still` || scope === `plant`) prepare(key);
      bumpLook(key.split(`:`)[1]);
      if (settling) return;
      settling = setTimeout(() => {
        settling = null;
        try {
          settle();
        } catch (err) {
          halt(err.message);
        }
      }, 0);
    };

    loadScales();
    loadPackets();
    loadLooks();
    // The folders take a moment to read. Whatever they hold goes on as soon
    // as they're in, and anything already on screen is dressed again.
    const afterFolders = () => {
      e.log.info(`[Textures] Textures folder: ${folderNote}.`);
      loadScales();
      loadPackets();
      loadLooks();
      version++;
      try {
        settle();
      } catch (err) {
        halt(err.message);
      }
    };
    const folderRead = readAll().then(afterFolders, (err) => e.log.error(`[Textures] Reading the textures folders failed: ${err?.message ?? err}`));

    doc.addEventListener(`keydown`, (ev) => {
      if (ev.ctrlKey && ev.shiftKey && (ev.key === `T` || ev.key === `t`)) {
        ev.preventDefault();
        togglePanel();
      }
      // The way out of a game that has stopped responding: this is a DOM
      // listener, so it still fires when nothing in the game does.
      if (ev.ctrlKey && ev.shiftKey && (ev.key === `X` || ev.key === `x`)) {
        ev.preventDefault();
        stopped = true;
        clear();
      }
    });

    // ==================================================================
    // Console handle
    // ==================================================================
    const clear = () => {
      let gone = 0;
      for (const key of Object.keys(saved())) {
        const [scope, id] = key.split(`:`);
        // Settings aren't art: where it's kept, the rig flip, the card size.
        if (scope === `option`) continue;
        undo(key, scope === `plant` ? id : `that sheet`);
        gone++;
      }
      armatureSets.clear();
      rigSets.clear();
      fittedSets.clear();
      sheetsDone.clear();
      originalImages.clear();
      routes = {};
      e.log.info(`[Textures] Forgot ${gone} override(s). Restart to see everything back to vanilla.`);
      drawPanel();
      return gone;
    };

    const api = {
      panel: togglePanel,
      clear,
      retry: () => {
        stopped = false;
        e.log.info(`[Textures] Putting textures back again.`);
      },
      plants: () => {
        const rows = plantRows();
        e.log.info(`[Textures] ${rows.length} kind(s) of plant on the lawn:`);
        for (const row of rows) {
          e.log.info(`  ${row.label} (${row.codename}) x${row.plants.length}: ${row.textures.map((t) => `${t.where} ${t.tex.width}x${t.tex.height}`).join(`, `)}`);
        }
        return rows.map((r) => r.codename);
      },
      textures: () => {
        const rows = allTextures();
        e.log.info(`[Textures] ${rows.length} texture(s) loaded.`);
        for (const row of rows.slice(0, 40)) {
          e.log.info(`  ${row.tex.width}x${row.tex.height}  ${row.uuid.slice(0, 12)}  ${row.users.join(`, `)}`);
        }
        return rows.length;
      },
      replace: (codename) => replace(`plant:${codename}`, codename),
      apply: (key, dataUrl) => applyKey(key, dataUrl).then((n) => {
        if (n) remember(key, dataUrl);
        return n;
      }),
      undo: (key) => undo(key, key),
      saved: () => Object.keys(saved()),
      routes: () => routes,
      armatures,
      fullArt: (codename) => dressFromSet(codename, codename),
      // The same thing without the file picker, for the console and the tests.
      wear: (codename, { skeleton, atlasJson, dataUrl }) => imageFrom(dataUrl).then((imageAsset) => {
        const built = buildArmature({ skeleton, atlasJson, imageAsset });
        const row = plantRows().find((r) => r.codename === codename);
        let done = 0;
        for (const plant of row?.plants ?? []) {
          const how = wearArmature(plant, built);
          if (how) {
            routes[`armature:${codename}`] = how;
            done++;
          }
        }
        if (done) {
          armatureSets.set(codename, built);
          bumpLook(codename);
        }
        return done;
      }),
      clips: (codename) => {
        const row = plantRows().find((r) => r.codename === codename);
        const db = row?.plants?.[0]?.db;
        const clips = clipsOf(db);
        e.log.info(`[Textures] ${codename}: ${clips.length ? clips.join(`, `) : `no clips found`}`);
        return clips;
      },
      remapped: () => clipMapped,
      // Everything modded on the lawn, and whose art it is borrowing.
      // The rig's own piece list, which is what a fit is pairing against.
      pieces: (codename) => {
        const row = plantRows().find((r) => r.codename === codename);
        const list = row ? rigPieces(row.plants[0]) : [];
        e.log.info(`[Textures] ${codename}: ${list.length} piece(s) in its atlas.`);
        for (const piece of list.slice(0, 40)) e.log.info(`  ${piece.name}  ${piece.width}x${piece.height} at ${piece.x},${piece.y}`);
        return list;
      },
      fit: (codename) => {
        const row = plantRows().find((r) => r.codename === codename);
        if (row) fitArt(row);
      },
      // Fit an atlas straight onto a plant, no picker, for the console and
      // the tests.
      applyFit: (codename, atlasJson, dataUrl) => imageFrom(dataUrl).then((imageAsset) => {
        const row = plantRows().find((r) => r.codename === codename);
        if (!row) return 0;
        const tex = textureFrom(imageAsset);
        let count = 0;
        for (const plant of row.plants) if (fitToRig(plant, atlasJson, tex)) count++;
        return count;
      }),
      // Building a rig, from the console or the editor.
      rigJson: buildRigJson,
      // Saved animations, as the animation maker's Saved panel keeps them.
      saveAnimation,
      animations: () => listAnimations().then((list) => list.map(({ record, path, key }) => ({
        name: record.name, codename: record.codename, saved: record.saved, pieces: record.layout.length, where: path ?? `local storage (${key})`,
      }))),
      rigAtlas: buildRigAtlas,
      applyRig,
      // Still images borrow the plant's material for its hit flash. If that
      // turns them invisible on some build, stillFlash(false) stops it.
      stillFlash: (on = true) => {
        remember(`option:stillflash`, on ? `on` : `off`);
        version++;
        return on;
      },
      // Read the saved looks again, after editing storage by hand.
      reload: () => {
        savedCache = null;
        return readAll().then(afterFolders);
      },
      // localStorage into the mod's textures folder, where it has no size
      // limit and travels with the mod.
      moveToFolder: () => moveToFolder().then((n) => {
        drawPanel();
        return n;
      }),
      folder: () => {
        e.log.info(`[Textures] ${folderNote}. Writing to: ${mainHome() ?? `nowhere, localStorage only`}${folderWritable === false ? ` (writes failed, using localStorage)` : ``}.`);
        return { own: ownFolder, home: mainHome(), choices: homeChoices.map((p) => p.name), plants: Object.fromEntries(plantHomes), writable: folderWritable, note: folderNote, files: packValues.size };
      },
      ready: () => folderRead,
      // Art from another pack's folder that was switched off here, back on.
      unhide: () => {
        loadLocal();
        const keys = Object.keys(savedCache).filter((key) => key.startsWith(OFF));
        for (const key of keys) dropLocal(key);
        loadScales();
        loadPackets();
        loadLooks();
        version++;
        drawPanel();
        return keys.length;
      },
      rigFlip: () => flipRigs(),
      // Pack several sheets into one picture, as the animation maker does.
      packSheets: (urls) => combineSheets(urls),
      // Says whether each of that plant's rigs is really moving, in the log.
      rigCheck: (codename) => {
        const row = plantRows().find((r) => r.codename === codename);
        for (const plant of row?.plants ?? []) checkRig(plant, true);
        return row?.plants?.map((plant) => rigHealth(plant)) ?? [];
      },
      // The animation maker on a picture, without the picker.
      animate: (codename, dataUrl) => {
        const row = plantRows().find((r) => r.codename === codename) ?? { codename, label: codename, plants: [] };
        if (dataUrl) openRig(row, dataUrl);
        else rigArt(row);
      },
      stats: () => {
        const out = { packets, cleaned, finished, arrivals, displays: displays.size, fits: fitCount, rigs: rigSets.size, routes };
        e.log.info(`[Textures] packets=${packets} cleaned=${cleaned} finished=${finished} arrivals=${arrivals} displays=${displays.size} fits=${fitCount} rigs=${rigSets.size}`);
        return out;
      },
      // The pure parts, so they can be checked without a game.
      boxesIn: detectBoxes,
      pairUp: autoPair,
      rewrite: rewriteAtlas,
      packet: (codename) => setPacket(codename, codename),
      // The packet editor, for any plant, on the lawn or not.
      packetEditor: (codename, label) => openPacketEditor(codename, label ?? codename),
      // Set a packet picture without the picker, for the console and tests.
      applyPacket: (codename, dataUrl) => imageFrom(dataUrl).then((imageAsset) => {
        packetTextures.set(codename, textureFrom(imageAsset));
        remember(`packet:${codename}`, dataUrl);
        return 1;
      }),
      rig: (codename) => {
        const row = plantRows().find((r) => r.codename === codename);
        if (row) rigArt(row);
      },
      packetScale: (codename, factor) => setPacketScale(codename, factor),
      packetOffset: (codename, x, y) => setPacketOffset(codename, x, y),
      stillOffset: (codename, x, y) => setStillOffset(codename, x, y),
      stillScale: (codename, tiles) => setStillScale(codename, tiles),
      modded: () => {
        const rows = plantRows().filter((r) => r.modded);
        for (const row of rows) {
          const shared = sharersOf(row.textures[0]?.tex);
          e.log.info(`[Textures] ${row.label} (${row.codename})${shared.vanilla.length ? ` borrows art from ${shared.vanilla.join(`, `)}` : ``}`);
        }
        return rows.map((r) => r.codename);
      },
    };
    try {
      globalThis.GreenhouseTextures = api;
    } catch (err) { /* the panel still works */ }

    e.log.info(`[Textures] Greenhouse Textures ${VERSION} active. Ctrl+Shift+T on the lawn, or GreenhouseTextures in the console.`);
  };

  // 0.17.0 went quiet on one machine: no line at all, not even an error.
  // So say so when startup throws, stack and all, instead of letting the
  // event swallow it.
  let started = false;
  const start = (how) => {
    if (started) return;
    started = true;
    try {
      boot();
    } catch (err) {
      e.log.error(`[Textures] Startup failed (${how}): ${err?.name ?? `Error`}: ${err?.message ?? err}`);
      for (const line of String(err?.stack ?? ``).split(`\n`).slice(1, 8)) {
        if (line.trim()) e.log.error(`[Textures]   ${line.trim()}`);
      }
    }
  };
  e.events.on(`engine:ready`, () => start(`engine:ready`));

  // And in case engine:ready went by before this pack was listening: once a
  // scene has been up a while, go anyway.
  const setupAt = Date.now();
  const LATE_MS = 20000;
  const wait = () => {
    if (started) return;
    let scene = null;
    try {
      scene = e.unsafe.engine.getCc()?.director?.getScene?.() ?? null;
    } catch (err) { /* not up yet */ }
    if (scene && Date.now() - setupAt >= LATE_MS) {
      e.log.warn?.(`[Textures] Never heard engine:ready, starting anyway.`);
      start(`late`);
      return;
    }
    if (Date.now() - setupAt < 120000) setTimeout(wait, 1000);
  };
  setTimeout(wait, 1000);
}

export { setup };
