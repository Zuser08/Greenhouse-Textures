# Greenhouse Textures (public beta)

Custom art for PvZ2 Gardenless, for a game whose mod format has no room for
any: repainted sheets, still images, art fitted to a plant's rig, rigs and
animations of your own, and whole seed packets. Works on every plant,
vanilla or modded, and any mod can ship art for it in a `textures/` folder.

This is a beta. Keep copies of anything you make that you'd miss: the
files are plain pngs and json, see "The textures folder".

## Using it

Press **Ctrl+Shift+T** while a level is running.

The panel opens on **Plants on the lawn**: one row per kind of plant in front
of you, with a thumbnail of the sheet it draws from. Click a thumbnail to see
the whole sheet. Then:

- **Save PNG** writes that sheet out.
- Repaint it in any editor. Same size, and everything stays where it is.
- **This plant** gives that plant your version and leaves everyone else alone.
- **Every user** repaints the sheet itself, so every plant drawing from it
  changes. Use that when you actually want Gatling Pea to change too.
- **Undo** puts the original back, there and then.

Plants have to be on the lawn to appear: their art is loaded with them, and
until then there is nothing to show or replace. **All textures** lists
everything the game currently has loaded, labelled with the plant using it
where that can be worked out.

## The textures folder

Art lives as files in a `textures/` folder inside a pack, named by the
plant's codename:

```
textures/
  sunflower.still.png     still image
  sunflower.packet.png    seed packet: the plant part
  sunflower.packetback.png  seed packet: its background
  sunflower.packetfront.png seed packet: its border
  sunflower.packet.json   the packet editor's layers
  sunflower.sheet.png     repainted sheet, this plant only
  sunflower.fit.png       art fitted to the rig, with sunflower.fit.json
  sunflower.rig.png       art for a rig of its own, with sunflower.rig.json
  looks.json              sizes and nudges for the plants in this folder
  saved/                  saved animations and packet designs
  removed/                whatever was taken off
```

`looks.json`:

```json
{
  "sunflower": { "stillScale": 1.4, "stillOffset": [0, 10], "packetScale": 1, "packetOffset": [0, 0] }
}
```

### Where new art is written

Not in this pack. Greenhouse Textures is code, and installing a new version
of it replaces its folder, so art kept there goes with the old version. New
art goes, in order, to:

1. **The pack that adds the plant.** A pack whose
   `jsons/objects/PlantTypes.json` lists the plant owns its art, so an
   animation made for a modded plant lands in that mod's `textures/` folder
   and ships with the mod. Nobody who installs it has to import anything.
2. **The home pack**, for everything else: vanilla plants, saved animations,
   packet designs, DragonBones exports. Pick it at the top of the panel
   (**Keep new art in**) from every pack that has a `textures/` folder. If
   only one pack has one, it's used without asking.
3. This pack's own folder, when no home pack is picked. The panel says so in
   orange, since a new version of this pack takes it away.
4. localStorage, only if no folder can be written.

The game's file access can't make folders, so a pack has to ship with a
`textures/` folder (and `textures/saved/`, `textures/removed/` inside it) for
art to go into it. A plant pack without one has its art kept in the home
pack instead. Once a home pack is picked, art left in this pack's folder is
moved over to it at startup.

**Making a home pack of your own:** any pack will do. The smallest is a
folder in `packs` with a `pack.json` (a uuid, a name, a version) and an
empty `textures/` folder with `saved/` and `removed/` in it.

**For mod makers:** make the animation or packet in the editor with your pack
installed and it's written into your pack's `textures/` folder. Zip the pack
with that folder in it. Update the pack by replacing it with a new zip that
still has the folder, or the art goes with the old one. Players install your
pack unzipped: a pack installed as a .zip has no folder to read.

The mod reads the `textures/` folder of **every** pack. Where the same file
is in more than one, the plant's own pack wins, then the home pack, then
this pack, and anything still in localStorage wins over all of them. Drop a
png in with the right name and it is on that plant at the next start (or
after `GreenhouseTextures.reload()`). **Undo** moves a file into `removed/`
beside it instead of deleting it, since it may be the only copy. Art from a
pack this mod doesn't write to is switched off here instead;
`GreenhouseTextures.unhide()` switches it all back on. The panic button
(Ctrl+Shift+X, **Turn everything off**) does switch shipped art off too.

How it gets at files: the game is a Tauri app, and its file plugin is allowed
to read and write inside the game's own app data folder, which is where
`gp-next/packs` lives. A pack installed as a .zip has no folder to read.

### localStorage

Before 0.8 everything went into the browser's localStorage, which holds about
5MB and belongs to one browser profile. It is still the fallback when the
folder can't be written. When anything is sitting in there, the panel header
shows **Move N to mod folder**, which writes it all out as files and clears it
from storage. `GreenhouseTextures.moveToFolder()` does the same, and
`GreenhouseTextures.folder()` says what was read, where new art goes, and
which plants belong to which pack.

## When the art goes on

As the plant is built, before it is drawn. Every plant the game shows goes
through `AnimationController.readCostume` the moment it exists: a plant going
into the ground, the one in your hand while you place it, the almanac, the
seed chooser, the store, the map. The mod dresses it right there, in the same
tick, so the first frame is already the custom art. There is no second of
vanilla plant first.

That only works if the picture is ready, so every saved picture is decoded
into a texture when the game starts and kept. Fits and rigs are saved as the
choices made in their windows, and are rebuilt from their picture at startup
too, so they come back after a restart instead of lasting one session.

Displays outside the lawn are pooled by prefab, and a pack plant shares its
prefab with the vanilla plant it borrows from. Whatever a display last wore
comes off before it is dressed as what it is now, so a vanilla plant's page
in the almanac is the vanilla plant even right after a modded plant's that
borrows it.

A still image also takes on the plant's colour every frame (dimmed for a
locked plant in the almanac, faded as a plant goes) and the plant's own
material, which is where the hit flash and the frozen and poisoned tints
live. If the material ever makes still images vanish on some build,
`GreenhouseTextures.stillFlash(false)` turns that part off.

## Taking one off again

**Undo** on the row. It is on the plant's own row and on the **Replaced** tab,
which is the list of everything you have changed. A repainted sheet gets the
image it had before, and a dressed plant gets its own atlas and material back,
so the plant goes back to normal on the spot rather than at the next restart.

The row's **Undo** takes off everything that plant wears. On the **Replaced**
tab each piece has its own: undoing a still image leaves the packet picture,
the fit and the rig alone, and the other way round.

To take everything off at once: **Turn everything off** in the panel header,
`GreenhouseTextures.clear()` in the console, or **Ctrl+Shift+X**. All three
undo every override and forget them.

Two things that can't be undone live, and say so in the log: an armature that
was swapped out for a "Full art" set before the mod knew what was there, and
anything applied in a session that has since been restarted, since only the
picture is saved, not the original. Both come back with a restart, because
nothing is written to the game's own files -- overrides live in local storage
and on the textures in memory.

## One armature per plant, like the game

Every look goes on the plant's own armature, the way the game dresses its
own plants: one display per plant, driven by the game's own animation
controller. A new sheet or a fit swaps only the art, so the plant's
skeleton, clips and attack events are untouched. A rig swaps the skeleton
too, and carries the plant's clips across: every clip the plant has, by the
same name, at the same length and loop count, with its frame events on the
same frames (Chomper's "chomp", Spikeweed's "attack", Laser Bean's "shoot").
The game plays the rig exactly as it would the original, and the plant
attacks on cue.

In the game the skeleton json is usually gone once it's been loaded, and
before 0.15 that left a rig with three stock clips and no events, so a
rigged Chomper never bit. The clips are now read off the loaded armature
itself, from the same arrays the runtime fires its events from. The first
time a plant's clips are read, the log says where from, e.g. `chomper: 16
clips read from its armature, events in Attack|AttackEmpty|...`.

The engine's rebuild makes a new armature but doesn't put it on the world
clock that moves armatures along; only its own setters and switching the
display on do that. Up to 0.15.0 every rebuild here left the plant on an
armature nothing advanced: frozen on its first frame, firing no events, so it
never attacked. That one fault was behind "adding a texture kills the plant",
the rig that "won't animate no matter what", and a pooled plant coming back
dead after a dressed one died. Since 0.15.1 a rebuilt armature is put on the
clock at once, and the `rig check` line says `clocked=true` when it is.

The swap happens as a plant arrives, before it does anything. If it happens
to a plant already on the lawn (after Build and wear), the clip it was
playing is started again, the same number of times, because the game waits
on some clips finishing before the plant can act.

0.13 and 0.14 tried the opposite: the plant's armature left alone and
hidden, and a second one drawn over it following along. That doubled the
work per plant and brought the game down to a few frames a second; it's
gone. The log now counts armature rebuilds every 10 seconds of a level
(`N armature rebuild(s) in the last 10s`). One per plant as it's planted is
normal; a steady stream means something is rebuilding in a loop.

Each kind of plant also has its own counter, and a plant is only re-dressed
when its own look changed; a plant with nothing saved is never touched.

Not every build hands mods the same engine classes. On one Mac, `getCc()`
had no `UIOpacity` and no `dragonBones`. A still image then switched the
plant's armature off rather than hiding it (no events, so no attacks). Both
are now also looked up by class name, and if the opacity component is
nowhere to be had, the opacity it would set is set directly.

## Plants that get eaten

Plants are pooled: the object that just got eaten comes back as the next
plant of any kind. A still image is a node parented to the plant and a hidden
armature is a flag on a component, so anything left behind haunts whatever is
planted next. Everything this mod puts on a plant comes off when that plant
is recycled, through `Plant.characterOnDisable`. The override itself is kept,
so the next plant of that kind is dressed again on the next pass.

Dying is not the same moment. `Plant.die` plays the death clip and only
removes the plant when that clip finishes, so a dead plant stays on screen
for a beat. The custom art stays on through it; taking it off at death is
what flashed the vanilla plant for a few frames. Under a still image the
death clip still plays, unseen, and the picture shrinks away over a quarter
second while it does. A rig built here has no death clip, so it would never
finish on its own: the mod removes that plant itself, death puff included. A plant carried off rather
than killed (sky fall, chi hole) keeps its art and is left to the game.

## If the game stops responding

Everything here touches live textures, and an engine that dislikes what it
was handed can take the render loop down with it, which looks like a game
that won't accept a click. The rules that keep that from happening:

- Nothing is touched outside a running level.
- A sheet no plant on the lawn is drawing from is never repainted, since that
  is how a menu or loading screen gets broken.
- An import is scaled to the size of the sheet it replaces, because handing
  the engine a differently sized image is the usual cause.
- One failure stops all of it for the session and says so in the log.

If it happens anyway: **Ctrl+Shift+X** forgets every override and stops the
mod. It is a keyboard listener on the page rather than anything in the game,
so it still works when the game itself does not. The panel has the same thing
as "Turn everything off", and `GreenhouseTextures.clear()` does it from the
console. Then restart. `GreenhouseTextures.retry()` turns it back on.

## If it doesn't start at all

The first line in the log (F9) should be `[Textures] <version> loaded,
waiting for the engine.` and a little later `Greenhouse Textures <version>
active`.

- No `loaded` line: GP-Next never ran the file. Run `gpNext.status().errors`
  in the console and it says why.
- `loaded` but `Startup failed`: the lines under it are the error and where it
  was thrown. Those are what's needed to fix it.
- `Never heard engine:ready, starting anyway`: the pack missed the start
  signal and went on its own after 20 seconds. It works, just late.

## Why it needs to work this way

GP-Next datapacks are JSON only, and there is no file API to read a PNG off
disk. But the game is Cocos running inside Electron, so there is a browser
underneath it, and the game already uses that itself: its custom-music feature
builds an `<input type="file">`, reads it, and hands the result to the asset
manager. A file picker, a canvas and localStorage are the whole toolkit.

Finding the art is the harder half. Cocos ships native assets under uuid
filenames, so nothing in the asset cache is called "GatlingPea" and searching
by name finds nothing at all. Plants know better: every plant carries `db`,
its DragonBones display, which holds the atlas it draws from. So the list is
built from the plants standing on the lawn, and each row points at a real
texture object rather than a guessed name.

## Still image

Dropping another plant's sheet onto an armature makes a mess, and the reason
is worth knowing: the armature's slots hold coordinates into the layout they
were built for, so each piece lands wherever that rectangle now happens to be.
It isn't a bad import, it's the wrong question being asked of the file.

**Still image** on a plant row is the short way round it. Pick a single
picture of the plant (a cropped png, not an atlas), and that plant hides its
armature and wears the picture instead, drawn about a tile and a half tall
with a slow breathing sway so it doesn't read as frozen. The plant keeps every
bit of its behavior; only the drawing changes. **Undo** puts the armature
back.

Once a plant has a still image, its row shows **still size** with - and +
buttons, in tiles tall (1.4 to start, 0.2 to 6). It redraws on the spot and
is remembered. `GreenhouseTextures.stillScale('sunflower', 2)` does the same
from the console.

Next to the size are **x** and **y** sliders, 80 either way, for nudging the
picture into place. They move it live without a redraw and are remembered too;
`stillOffset('sunflower', 10, -20)` from the console.

The picture goes where the armature was in the plant's draw order, right
beside its body, so whatever the plant draws under itself stays under it and
anything it draws on top stays on top.

The armature underneath is drawn at opacity 1 of 255 rather than switched
off or taken to zero. Plenty of plants attack from their own animation:
Laser Bean, and any modded plant built on it, fires on a "shoot" frame from a beam point that
rides a bone. A switched-off armature stops animating, so no shot. At zero
opacity the renderer skips it altogether, and bone-riding points only move
while it is drawn, so the beam fired from a frozen point and missed the lane.
At 1 it is drawn, every attached point keeps moving, and nothing shows.

A plant with moving art of its own (a rig from the animation maker, a fit,
or a full armature) doesn't wear its still image: laid over the top it hid
the animation completely. The still stays saved, and comes back if the rig
is taken off.

It does not animate, and it is not a substitute for the real thing below. It
is the difference between a plant that looks like itself and one that looks
broken.

## Fit to rig

The proper way round the layout problem, short of a converted skeleton.

An armature's atlas is a list of named rectangles: slot `leaf_1` draws
whatever sits at x=812, y=240, 96 by 64. The rig doesn't know what a leaf is,
only where to find one. **Fit to rig** tells it where its pieces moved to.

Pick your sheet and the fitter opens: the sheet on the left with every
separate lump of opaque pixels boxed, the rig's piece names listed on the
right. Click a name, click its piece in the picture, repeat. **Auto pair**
guesses by size first (biggest piece to biggest lump), which is usually most
of the work. **Apply** rewrites the atlas so the rig points at the new boxes.

What you get is the new art animating on the old skeleton. A modded plant
drawn on Electric Currant's rig moves like a currant, not like itself, but
every piece is in the right place and nothing flickers. For its own
animation you still need its own skeleton, below.

Notes worth knowing:

- Pieces are found by walking the alpha channel at quarter scale, so a lump
  has to be a few pixels across to count. Art on a flat opaque background
  comes out as one giant box.
- Anything left unpaired keeps pointing at the old sheet, which is what you
  want for pieces the new art doesn't have.
- The pairing is saved, so a second go starts where you left off.
- `GreenhouseTextures.pieces(codename)` prints the rig's piece list, and
  `fit(codename)` opens the fitter from the console.
- Apply says what it did in the log: how many pieces it paired and onto how
  many plants. DragonBones caches parsed atlases by the name inside them, so
  every fit is given its own name and uuid; without that the engine hands
  back the old rectangles and the fit appears to do nothing.
- The fit keeps the plant's own skeleton, so it moves and attacks exactly
  as the plant does.

## Animation maker

The way off the borrowed skeleton. Fitting art to a rig puts the pieces in
the right places but leaves them moving like the plant they came from; a rig
of your own moves like itself.

**Animate** on a plant row opens it (with the picker the first time, straight
back into your work after that). Two steps, as tabs along the top.

### Saving animations

**Saved** in the animation maker's header opens your saved animations. Name
the one that's open and press **Save**; **Open** on any in the list loads it
back into the editor, pieces, motion and sheet included, ready for **Build
and wear**. One made for another plant opens too.

They live apart from the plant's rig. Building again replaces a plant's rig
and taking it off removes it, but neither touches what's saved, and a rig is
saved by itself (as "<plant> removed <date>") before it's taken off. Each is
a file in `textures/saved`, one `.anim.json` with the sheet inside, so it can
be backed up or copied to another install. Where the folder can't be written
(a zipped install) they go to the game's local storage instead, which holds
a few sheets at most.

From the console: `GreenhouseTextures.animations()` lists them.

### More than one sprite sheet

A plant drawn across several sheets works: pick them all at once the first
time you press **Animate**, or press **Add sprite sheets** in either step
later. They're packed into one picture, each new sheet to the right of or
below the others (whichever keeps it squarer), with dashed outlines in step 1
showing where each sits. The first sheet stays at the top left, so every box
already cut keeps pointing at the right art, and every lump on the new sheets
gets a box of its own, ready to name. A rig draws from a single texture, which
is why they're combined rather than kept apart; the combined picture is what
gets saved as `<plant>.rig.png`. Together they can't go over 4096 pixels on a
side.

### 1. Cut out pieces

The picture, with a box round every lump of art it could find. Nothing else
is drawn on it.

- **Drag on an empty spot** to draw your own box. **Drag a box** to move it,
  **drag a corner** of the selected one to resize it.
- **Trim to fit** (or T) shrinks the selected box to the art inside it, so a
  rough box drawn by hand ends up tight.
- **Find pieces** adds a box for any lump that doesn't have one yet.
- Each piece gets a **name** in the list on the right, next to a picture of
  it. The names become the bone names, so `leaf`, `stem`, `head` rather than
  numbers.
- Scroll to zoom, right-drag to pan. Delete removes the selected box.

### 2. Build and animate

Everything after cutting happens here, on one stage. Under the stage is the
dock, laid out like the bottom of the Geometry Dash editor:

- **Clip:** a row of chips. **Layout** is the plant standing still, as built.
  Every other chip is a clip the plant plays (Idle, Attack, Death, and any of
  your own), with a count of its triggers.
- The **timeline**, when a clip is picked.
- **Edit layout:** or **Edit triggers:**, GD's Edit tab: arrows that move by
  the step you pick (1, 5 or 20), turns of 15 and 90 degrees either way,
  Smaller and Bigger, then Duplicate, Delete and Deselect. In the layout
  these change the layout; in a clip they change the picked trigger, or
  start one at the red line.

**Build and wear** is at the top right, in both steps. Nothing reaches the
lawn until it's pressed, and it shows a `*` while there are changes the
plant in the game doesn't have yet.

#### Layout

The pieces stood up on the ground line, not moving. Click a piece to pick it,
and the panel on the right sets it up:

- **Attached to**: hang it off another piece. A head attached to the stem
  rides the stem's motion and adds its own, which is what makes a plant bend
  instead of a stack of stickers wobbling. Moving or turning a piece takes
  everything attached to it along. The list shows the tree.
- **Loop**: the motion it runs in every clip, and **How much**. Sways side
  to side, bobs up and down, breathes in and out, squashes and stretches,
  wiggles, floats, bounces, shakes, spins round, flaps, nods, or holds
  still. **Loops** further down sets the overall **Sway**, **Speed** and
  **Style** (neighbours swinging opposite ways, or a wave up the plant).
- **Turn**, **Size**, **Stretch wide**, **Stretch tall**, **Mirror**, and
  **Layer** (send back, bring forward). Stretching sizes the picture only, so
  whatever is attached keeps its place.
- **Turns about**: the pivot. **Place by clicking**, then click exactly where
  the piece joins the one below; or Base, Middle, Top. The picture stays put
  when the pivot moves. Pivots at joints matter more than any other setting.
- **Hidden**: hidden in game until a Show trigger shows it (below).

**Whole plant.** **Size**, **Width** and **Height** scale the finished plant
as one, on the rig's root, without touching any piece's layout.

**Add, copy, delete.** **Add piece** takes you back to the picture to draw a
box round the new part. **Copy** duplicates the picked pieces: a copy uses
the same art, so one drawn leaf can be three leaves, each placed, turned and
sized on its own. **Delete** removes them; anything that hung off a deleted
piece moves up to what that piece hung off.

**Picking several.** Ctrl+click pieces on the stage or in the list (Ctrl+A
picks everything). Dragging or nudging moves them all, and the panel sets
them together: **Move together** puts their loops on one beat, **Mirror each
other** half a swing apart (a pair of arms), **Stop syncing** lets them go,
and **All loop**, **All by** and **Attach all to** set the same thing on
every one. Synced pieces carry a coloured dot in the list.

Drag a piece to move it, Shift+drag to turn it, drag the background to pan,
scroll to zoom. Keys: arrows nudge (Shift for 10), Q/E turn, +/- size, F
mirrors, [ and ] change layer, Tab picks the next piece, Ctrl+D copies,
Delete deletes, Ctrl+Z and Ctrl+Y undo and redo. **Just the art** in the
header hides the ground line, outlines and pivot dots.

#### Clips: triggers on a timeline

Pick a clip under the stage and the same stage animates that clip. The
layout can't be changed by accident while a clip is picked.

A clip is a list of **triggers**, like GD's: each starts on a frame, lasts
some frames, has an easing, and acts on one or more pieces.

- **Move** by so far right and up
- **Rotate** by so many degrees, about each piece's pivot
- **Scale** by so much (2 is twice as big)
- **Alpha** to an opacity, from wherever it was
- **Show** and **Hide** from that frame on
- **Picture**: the piece shows another piece's picture from that frame on,
  for blinks, mouths and anything that swaps

Move, Rotate and Scale add up the way GD's do: two Moves running at once move
by both. They also go on top of the piece's loop, so a leaf can keep swaying
while it's being flicked; untick **Loop plays** on a piece to have only its
triggers move it in that clip.

The quickest way in is to drag. **Drag a piece** and it gets a Move trigger
at the red line; **Shift+drag** gets a Rotate. A click on its own only picks
the piece. After a drag the red line jumps to where that trigger ends, so the
next drag starts from there: drag, drag, drag, and the motion builds up in
order. The arrow keys and the edit buttons under the stage do the same: the
first press starts a trigger at the red line, the next ones change it.
Dragging the piece a picked trigger acts on changes that trigger instead of
making another.

**Add a trigger** in the panel makes one of any kind at the red line for the
picked pieces. Picking a trigger (click its bar, or its line in the piece's
list) opens its panel:

- **On**: the pieces it acts on. **Use picked** points it at whatever is
  picked now. One trigger can move several pieces at once.
- **Starts at** and **Lasts**, in frames. 0 frames is instant.
- **Easing**: the GD list. None, Ease In Out, Ease In, Ease Out (these three
  take an **Ease rate**, 2 by default), Sine, Exponential, Elastic, Bounce
  and Back, each In, Out and In Out.
- The amounts for its kind.
- **Go to start**, **Go to end**, **Duplicate**, **Delete trigger**.

The **timeline** has a lane a piece, and each trigger is a bar from where it
starts to where it ends, coloured by kind (Move blue, Rotate orange, Scale
purple, Alpha grey, Show green, Hide red, Picture yellow). Bars that overlap
share the lane. Click a bar to pick it, drag it to move it in time, drag its
right end to make it longer or shorter. Click an empty spot to move the red
line and pick that lane's piece; double-click one to put a Move trigger
there. Above the lanes are the plant's own **game events**, such as
Chomper's "chomp": the game acts on those, so land the motion on them.
Scroll the lanes when there are many pieces.

**It won't loop smoothly.** A clip that loops starts over when it ends, so a
piece its triggers leave somewhere else jumps back. The panel says which
pieces, and **Add a return** eases them home over the last frames. (Show,
Hide and Picture put themselves back when a clip starts over.)

Each clip says in green when the game plays it, where that's known: Rand
clips are fidgets played now and then instead of Idle, AttackEmpty is a bite
at nothing, Chewing plays while a zombie is in a Chomper's mouth, and so on.
Clips the game doesn't time by events can have their length set; clips it
does keep theirs, or the plant would bite at the wrong moment.

**Clips of your own** are for things a plant does that the game has no
animation for. **New clip** makes one (tick **loops** for one that repeats
until it's stopped) and opens it; it goes into the skeleton under its name,
where anything that asks for it by name can play it. A plant pack that
plays clips of its own lists them here with an **Add** button for each (see
"For plant mod makers" below). Without the clip, nothing changes.

Also here: play, pause and speed; step a frame; onion skin (the pose a little
before and after, faintly); bones drawn from each piece's pivot to its
parent's; **Copy triggers to that clip** (stretched to its length); **Clear
this clip**; and **Export for DragonBones**, which writes `<plant>_ske.json`,
`<plant>_tex.json` and `<plant>_tex.png` into `textures/saved` to open in
DragonBones Pro.

Keys in a clip: Space plays, comma and full stop step a frame, Home and End
jump to the ends, arrows move (Shift for 10), Q and E rotate, + and - scale,
Delete deletes the picked trigger (never a piece), Ctrl+D duplicates it,
Ctrl+C and Ctrl+V copy it and paste it at the red line onto the picked
pieces, Esc lets go of it.

Everything bakes to a row a frame, so any easing the editor draws is one the
game plays: DragonBones itself only tweens in straight lines, so the curve is
written out frame by frame and the straight stretches are merged back down.
Instant triggers become DragonBones hold frames, so they jump on their frame
instead of sliding into it.

#### From the Geometry Dash editor

What was taken from it, on purpose: the bottom dock with an Edit tab of
arrows by a chosen step and fixed turns; triggers with a duration, an easing
and an ease rate, aimed at a group of pieces rather than keyed piece by
piece; Move, Rotate, Scale and Alpha adding up like GD's; Show and Hide as
toggles; the easing list; duration shown as a line along time; Duplicate,
Deselect, and a red line the triggers are placed at. None of GD's code or art
is in here; it's the way of working that was borrowed.

#### Before 0.18

The third step, **Animate**, is gone; its clips are the chips under the
stage. Keys made in it open as triggers, one for each change between two
keys, with the same easing, and the piece's loop switched off in that clip,
since keys used to replace it. It plays exactly as before. A piece set to the
old **My own keyframes** loop keeps it and it still plays, but new ones can't
be made: use a trigger in Idle instead.

What DragonBones Pro has that this doesn't: meshes and free-form deformation,
IK, skins, bounding boxes, animated draw order, and a curve editor for your
own easing curves.

### Showing and hiding pieces

**Hide** and **Show** beside each piece in the list switch it off in the
editor only, to get at whatever is behind it; the game still draws it, and
a switched-off piece can't be clicked. The **Hidden** box on a piece hides it
in game until a **Show** trigger shows it: a muzzle flash, a spit, a second
head. It's drawn faintly so you can place it and pick it. Any piece can be
hidden from a frame on with a **Hide** trigger. In the skeleton it's the slot
showing nothing, so it costs nothing while hidden.

### The animations it writes

The clip list comes from the plant itself. Its own skeleton lists every
animation the game plays on it, with their lengths and the frame events the
game listens for: Laser Bean fires its beam on a "shoot" event, a Peashooter
on its own, Chomper bites on another. The rig gets a clip of the same name
and length for each, with those events copied across, so a rigged plant
still attacks on cue, and one with a death clip dies like any other plant.
Idles and anything looping take your sway and speed; attacks lean back and
snap forward from the base with attached pieces following through; Plant
Food clips are a bigger, faster sway; death shrinks the plant away. If a
plant's skeleton can't be read, Idle, Shoot and Food stand in, and each clip
the game asks for is matched to the nearest name.

Those copied events are what make a rigged plant attack: the game listens
for them on the rig exactly as it would on the original. See "One armature
per plant, like the game".

One bone per piece, in its parent's space, sitting at the pivot; the picture
hangs off the bone with its size and mirror, so a child's position means
what it says. Everything is saved as you go (a draft in localStorage) and on
Build as `<plant>.rig.json` and `<plant>.rig.png` in the textures folder.

### Getting a good one

- Fewer pieces read better than more. A stem, two or three leaves and a head
  animate convincingly; twenty scattered fragments look like debris.
- Attach things. Leaves and head to the stem, petals to the head.
- Pivots at joints, always.
- Small sway. 2 to 4 looks alive; 15 looks like a flag.
- Overlap pieces slightly so a turn doesn't open a gap at the joint.

### If it doesn't move in game

First, size. The game draws every plant at 0.42 of its pixel size
(`CharacterScale`), and the editor draws it at full size, so motion that is
plain in the editor can be a pixel or two on the lawn. The dashed box behind
the plant in step 2 is one lawn tile, and **Game size** (in the header)
zooms to roughly what the lawn shows. New rigs start with a sway of 6 and
the moving presets travel about twice as far as before 0.11.1.

After **Build and wear** the editor checks the plant on the lawn a second
later and says, in the green box, whether its animation is moving, and if
not, where it's stuck, in a line to pass on.

If the rig still stands still, the log says why: a second after a rig first
goes on, a `rig check` line reports whether its animation clock is moving,
which clip it's on, the play speeds, the cache mode and how many bones it
has. `GreenhouseTextures.rigCheck('sunflower')` runs the same
check on demand.

DragonBones data is y-down, the same as the editor, so a rig goes across as
laid out. If a plant comes out upside down anyway, **Upside down in game?
Flip** rebuilds every rig mirrored top to bottom, and remembers it.

## Seed packets

### Packet editor

**Packet** on a plant row, or **Edit packet** on the panel's **Seed
packets** tab (every plant the game knows, planted or not), opens the packet
editor. It designs the whole seed packet, in three parts, each a stack of
layers:

- **Background**, under the plant: **Background** imports pictures of your
  own, stretched to the card; **Colour** adds a plain rounded one. The first
  background layer switches the game's own background off.
- **Plant**: **Plant pictures** imports as many as you like, with empty
  edges trimmed off (untick that under How it looks). **Its still**, **Its
  rig** (the rest pose) and **Its packet now** add what the plant has.
- **Border**, over the plant: **Border** imports a frame, stretched over the
  card. Draw it with a clear middle.

Under **The card**, the game's own parts: **Hide the game's background**,
**Hide the sun cost plate** and **Hide the family icon**. The sun cost number
always stays, since it changes in play.

The yellow line is the card's edge, measured off a real card: open the seed
chooser (or have packets in the bank) and press **Measure the card**. Until
then it's a guess. The dashed line round it is what gets saved: the card and
a margin of a fifth of its size all round, so art can hang over the edge
that far and nothing inside the card is ever cut off. The small picture
under How it looks shows the packet at about game size.

Click a layer to pick it (or its line in the list). Drag it to move it; it
snaps to the middle of the art box and of the card. Green corners size it,
the blue side handles stretch it wide, the round knob turns it (Shift for 15
degree steps). Scroll to zoom; drag the background or right-drag to pan.
Each layer's panel has **Part** (move it between background, plant and
border), **Fill the card**, **Fit the art box**, **Centre**, **Straighten**,
sliders for size, stretch, turn, position and opacity, **Mirror** and
**Shadow**; **Up** and **Down** order it within its part. Arrow keys nudge,
Ctrl+D copies, Delete removes, Ctrl+Z undoes.

With **Live** on, the real packets change as you work. Close without saving
and they go back to how they were.

**Save** puts it on that plant's packets and writes it where the rest of the
plant's look goes (the pack that adds the plant, or the home pack):
`<plant>.packetback.png`, `<plant>.packet.png` and `<plant>.packetfront.png`,
all three the same size and place, and the layers and card settings as
`<plant>.packet.json` so the editor opens on them next time.

**Saved** keeps designs the way animations are kept: **Save design** writes
the design, every picture inside, as a `.packetdesign.json` in
`textures/saved` of the home pack, and **Open** loads one back, on any
plant. `GreenhouseTextures.packetEditor('codename')` opens the editor from
the console.

### How a packet picture goes on

A packet is built by `cardGrouperPlant` on every card build, which the bank
and the seed chooser do constantly, so the pictures go on right after it
each time, and they're loaded at startup rather than waiting for a level.
They hang off the card as siblings of its plant art, in the card's own
space: the background just above the game's background, the plant picture
where the plant art is, the border just above that and under the sun cost
plate. A plant with a single picture from before 0.20 keeps it; its row
shows **packet size** and the **x** and **y** sliders, and
`packetScale(codename, 1.2)` and `packetOffset(codename, x, y)` work as
before.

The game's parts are hidden by switching off their display components
rather than their nodes. The almanac switches every child of a card on for
each frame the card is in view, which is what kept bringing the vanilla art
back underneath. The pictures take the colour of what they stand in for (the
plant picture the plant art's, background and border the background's), so
they grey out while recharging or unaffordable and dim in the chooser like
every other packet.

Cards are pooled the same way plants are, so a card that showed a custom
packet is rebuilt for some other plant a moment later. Taking the pictures
off is not enough: whatever was switched off under them has to come back, or
every card that object gets reused for comes up blank.

## Different art, not just a repaint

Repainting only works while the layout stays put, because the armature's
slots hold coordinates into the old sheet. Drop one plant's art onto another
plant's sheet and you get the right pixels in the wrong places.

Wearing genuinely different art means bringing its skeleton too. A DragonBones
set is three files:

- the skeleton json, which is the bones and the animations
- the atlas json, which says where each piece sits on the sheet
- the sheet itself, a png

**Full art** on a plant row takes all three at once (select them together in
the picker) and puts them on that plant. The game asks for clip names from the
plant whose slot it is using -- "Idle", "Shoot", "Food" -- and a converted
armature almost never uses those names, so names are matched loosely and
anything unmatched falls back to the armature's first clip instead of
freezing. `GreenhouseTextures.clips(codename)` lists what the new armature can
actually play, which is the list to name things after.

PvZ2's own art does not ship in this format: the originals are PAM/reanim
animations and have to be converted to DragonBones first. The atlas png on its
own is not enough, however tempting the filename looks.

Armature sets are far too big for local storage, so they last the session and
are put back on plants that spawn while it runs. Re-import after a restart.

## One plant, or everything

A pack plant borrows a vanilla plant's art, so a modded plant built on
Gatling Pea draws from Gatling Pea's sheet. Every row says
which it is with a **modded** or **vanilla** tag, modded ones first, and names
any vanilla plant sharing that sheet.

That gives two buttons:

- **This plant only** builds a new texture and hands it to that plant alone.
  The vanilla plant it borrows from keeps its art. This is the one to use for
  a modded plant.
- The second button repaints the sheet itself. When a vanilla plant is on it,
  the button is named after that plant ("Also Gatling Pea"), turns orange, and
  asks a second time before doing it.

`GreenhouseTextures.modded()` lists the modded plants on the lawn and whose
art each is borrowing.

Two routes are tried for one plant, because which one a build honors can't be
known from outside:

1. Give that plant's DragonBones display its own copy of the atlas, pointing
   at the new texture.
2. Set the texture on the material the plant already owns. Every plant builds
   one in `characterOnLoadForced` and assigns it as `customMaterial` every
   frame, so it has to be re-set rather than assumed to stay.

Whichever took is printed in the log and shown in the row. "via atlas" was
read back and confirmed. "via material (unverified)" means it was set but
can't be checked from here, because the batcher may bind the sheet's texture
over it at draw time: if the plant still looks vanilla after that, the atlas
route didn't work on your build and the sheet button is the fallback.

## Console

`GreenhouseTextures` in the devtools console:

- `plants()` lists the plants on the lawn and the art each is using
- `armatures(query)` searches the game's own asset paths, to see what art
  this build ships whether or not a plant uses it
- `wear(codename, {skeleton, atlasJson, dataUrl})` puts an armature on without
  the picker
- `clips(codename)` lists the animations that plant's armature can play
- `textures()` lists every loaded texture
- `replace(codename)` opens the picker for one plant
- `apply(key, dataUrl)` / `undo(key)` where key is `plant:<codename>` or
  `sheet:<uuid>`
- `stats()` counts what has been dressed, including `arrivals` (plants
  dressed as they were built) and `displays` (almanac, chooser and the like)
- `stillFlash(false)` stops still images borrowing the plant's material
- `reload()` reads the textures folders and saved looks again
- `folder()` says which folders were read and where new art is written
- `moveToFolder()` moves everything out of localStorage into the folder
- `unhide()` switches back on art from other packs that was taken off here
- `saved()`, `routes()`, `panel()`

## Original work

Everything in this pack was written for it. The code was checked against the
game's own bundle, Luxis Lib, the DragonBones runtime and the GP-Next docs,
looking for any run of 16 or more matching code tokens and any 10 matching
words of text. The only matches are the parts every mod has to share: the
shape of a GP-Next hook, plain `for` loops, and one `Math.atan2` angle. The
DragonBones file format is followed from its published spec, and the
game's own code is only read to see how it behaves, never copied in.

## Checks

```
node --check bundle.js
node check.mjs
node texture-test.mjs
```

`texture-test.mjs` runs the mod against a fake browser, plant pool and asset
cache: that plants are found through their armature, that dressing one plant
leaves the shared sheet alone, that the whole-sheet route does change it, that
overrides persist, and that a plant planted later gets dressed on the next
pass. It cannot say whether Cocos honors a repaint on the GPU; only your
machine can.

## Installation

1. Unzip it into a folder in GP-Next's `packs` folder, called
   `GreenhouseTextures`. The zip has `pack.json` at its top level, which is
   what GP-Next looks for.
2. Turn on experimental JS modding in GP-Next (it needs 1.4.2 or later) and
   reload patches.
3. In a level, press **Ctrl+Shift+T**. At the top of the panel, **Keep new
   art in** picks the pack your art is saved into (see "Where new art is
   written").

Where `packs` is:

- Windows: `%APPDATA%\com.pvzge.game\gp-next\packs`
- macOS: `~/Library/Application Support/com.pvzge.game/gp-next/packs`

The Patcher page in game has an Open Folder button that goes there.

Installed as a zip it still runs, but nothing inside a zip can be read or
written, so its art goes to localStorage. The same goes for any pack whose
art you want read: unzip it.

**Updating:** replace this pack's folder with the new version. Your art isn't
in it (unless no home pack was picked; the panel warns you when that's so).
If the new folder has a different name, delete the old one so only one copy
loads.

## For plant mod makers

- **Ship art with your plants.** Give your pack a `textures/` folder with
  `saved/` and `removed/` inside, install it unzipped, and make the art in
  game: anything for a plant your `PlantTypes.json` adds is written into your
  folder. Zip the pack with that folder in it. Players with Greenhouse
  Textures installed see your plants dressed; players without it see your
  plants as they are.
- **Clips for things your plants do.** If your code plays animations the
  game doesn't have (a heal, a reload), list them and the animation maker
  offers them under **Clips of your own**, with an Add button and a note of
  when they play:

  ```js
  globalThis.GreenhouseActs = {
    ...(globalThis.GreenhouseActs ?? {}),
    myplant: [
      { name: `Heal`, loops: false, length: 18, when: `she heals a plant`, by: `My Pack` },
    ],
  };
  ```

  `length` is in frames at 24 a second; `by` is the name shown ("My Pack
  plays this when..."). Your code plays the clip by name on the plant's
  armature, and should only do so when the clip exists, so plants without a
  custom rig carry on as before.
