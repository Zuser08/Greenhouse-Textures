Greenhouse Textures keeps no art here unless it has nowhere else: installing
a new version of this pack replaces this folder. New art goes into the
textures folder of the pack that adds the plant, or else into the home pack
picked at the top of the panel (Keep new art in). Once one is picked,
anything found here is moved over to it at startup.

See "The textures folder" in README.md for the file names.
