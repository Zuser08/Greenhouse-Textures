Art taken off in the panel ends up here. Move a file back up a folder to put it on again.
