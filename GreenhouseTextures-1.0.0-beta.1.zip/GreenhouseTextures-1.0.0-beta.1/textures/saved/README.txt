Saved animations (.anim.json) and packet designs (.packetdesign.json), one file each.

Each file holds the pieces, their motion and the sprite sheet, so it opens
again on its own from Saved in the animation maker. Nothing in the game
deletes these: building a new rig or taking one off leaves them alone, and a
rig is saved here by itself before it's taken off.

Copy them somewhere safe to back them up, or into another install's
textures/saved folder to move them.
